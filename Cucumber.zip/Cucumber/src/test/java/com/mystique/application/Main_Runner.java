package com.mystique.application;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.runner.JUnitCore;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.runtime.Env;

public class Main_Runner {
	static WebDriver bd = BrowserDriver.getCurrentDriver();
	int count = 0;

	public static String[] channelfeature = new String[5];
	public static String[] genadminfeature = new String[5];
	public static String[] programfeature = new String[5];
	public static String[] propertyfeature = new String[5];
	public static String[] ratefeature = new String[5];
	public static String[] restrictfeature = new String[5];
	public static String[] roomfeature = new String[5];
	public static String[] syncfeature = new String[5];
	public static String[] tktprgfeature = new String[5];
	public static String[] componentfeature = new String[5];
	public static String[] momentfeature = new String[5];

	static SimpleDateFormat sdf = new SimpleDateFormat("HH-mm-ss");
	static Calendar calendar = new GregorianCalendar();

	public static void main(String[] args) {
		String location = "./resources/";
		int loginflag = 0;

		int channelcount = 0;
		int programcount = 0;
		int gencount = 0;
		int ratecount = 0;
		int roomcount = 0;
		int synccount = 0;
		int tktcount = 0;
		int restcount = 0;
		int propcount = 0;
		int componentcount = 0;
		int momentcount = 0;
		int k = 0;
		String newname = "";

		JUnitCore jUnitRunner = new org.junit.runner.JUnitCore();

		long startTime = System.currentTimeMillis();

		try {

			FileInputStream file = new FileInputStream(new File(location + "Manager.xlsx"));

			// Get the workbook instance for XLS file
			XSSFWorkbook workbook = new XSSFWorkbook(file);

			// Get first sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(0);

			// Iterate through each rows from first sheet
			//long rows = sheet.getLastRowNum();
			long rows =41;
			System.out.println(rows);

			for (int i = 1; i <= rows; i++) {
				Row row=sheet.getRow(i);
				int col = row.getLastCellNum();
				// System.out.println(col);
				Cell cell = row.getCell(3);
				//String channel100 = row.getCell(1).getStringCellValue();
				//System.out.println("Channel value :" +channel100);
				//System.out.println(cell.getStringCellValue());

				if (cell.getStringCellValue().equals("YES")) {

					String channel = row.getCell(1).getStringCellValue();
					
					int channel1 = 0;
					if (channel.equals("Channel"))
						channel1 = 1;
					else if (channel.equals("General"))
						channel1 = 2;
					else if (channel.equals("Program"))
						channel1 = 3;
					else if (channel.equals("Property"))
						channel1 = 4;
					else if (channel.equals("Rate"))
						channel1 = 5;
					else if (channel.equals("Restriction"))
						channel1 = 6;
					else if (channel.equals("Room"))
						channel1 = 7;
					else if (channel.equals("Sync"))
						channel1 = 8;
					else if (channel.equals("Ticket"))
						channel1 = 9;
					else if (channel.equals("Component")) {
						channel1 = 10;
					}
					else if (channel.equals("Moment")) {
						channel1 = 11;
					}

					switch (channel1) {
					case 1:
						if (loginflag > 0) {
							for (int col1 = 6; col1 < col; col1++) {

								channelfeature[channelcount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								channelcount++;
							}

						} else {
							for (int col1 = 5; col1 < col; col1++) {
								channelfeature[channelcount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								channelcount++;
							}
						}
						loginflag++;

						// System.out.println(channelfeature.length);

						break;

					case 2:
						if (loginflag > 0) {
							for (int col1 = 6; col1 < col; col1++) {

								genadminfeature[gencount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								gencount++;
							}

						} else {
							for (int col1 = 5; col1 < col; col1++) {

								genadminfeature[gencount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								// System.out.println("The value of feature--"+genadminfeature[gencount]);
								gencount++;
							}
						}
						loginflag++;

						// System.out.println(genadminfeature.length);

						break;

					case 3:
						if (loginflag > 0) {
							for (int col1 = 6; col1 < col; col1++) {

								programfeature[programcount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								programcount++;
							}

						} else {
							for (int col1 = 5; col1 < col; col1++) {
								programfeature[programcount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								programcount++;
							}
						}
						loginflag++;

						// System.out.println(programfeature.length);

						break;

					case 4:
						if (loginflag > 0) {
							for (int col1 = 6; col1 < col; col1++) {

								propertyfeature[propcount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								propcount++;
							}

						} else {
							for (int col1 = 5; col1 < col; col1++) {
								propertyfeature[propcount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								propcount++;
							}
						}
						loginflag++;

						// System.out.println(propertyfeature.length);

						break;

					case 5:
						if (loginflag > 0) {
							for (int col1 = 6; col1 < col; col1++) {

								ratefeature[ratecount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								ratecount++;
							}

						} else {
							for (int col1 = 5; col1 < col; col1++) {
								ratefeature[ratecount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								ratecount++;
							}
						}
						loginflag++;

						// System.out.println(ratefeature.length);

						break;
					case 6:
						if (loginflag > 0) {
							for (int col1 = 6; col1 < col; col1++) {

								restrictfeature[restcount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								restcount++;
							}

						} else {
							for (int col1 = 5; col1 < col; col1++) {
								restrictfeature[restcount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								restcount++;
							}
						}
						loginflag++;

						// System.out.println(restrictfeature.length);

						break;
					case 7:
						if (loginflag > 0) {
							for (int col1 = 6; col1 < col; col1++) {

								roomfeature[roomcount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								roomcount++;
							}

						} else {
							for (int col1 = 5; col1 < col; col1++) {
								roomfeature[roomcount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								roomcount++;
							}
						}
						loginflag++;

						// System.out.println(roomfeature.length);

						break;

					case 8:
						if (loginflag > 0) {
							for (int col1 = 6; col1 < col; col1++) {

								syncfeature[synccount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								synccount++;
							}

						} else {
							for (int col1 = 5; col1 < col; col1++) { // System.out.println("The columns="+col);
								syncfeature[synccount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								synccount++;
							}
						}
						loginflag++;

						// System.out.println(syncfeature.length);

						break;

					case 9:
						if (loginflag > 0) {
							for (int col1 = 6; col1 < col; col1++) {

								tktprgfeature[tktcount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								tktcount++;
							}

						} else {
							for (int col1 = 5; col1 < col; col1++) {
								tktprgfeature[tktcount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								tktcount++;
							}
						}
						loginflag++;

						// System.out.println(tktprgfeature.length);

						break;
						
					case 10:
						if (loginflag > 0) {
							for (int col1 = 6; col1 < col; col1++) {

								componentfeature[componentcount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								componentcount++;
							}

						} else {
							for (int col1 = 5; col1 < col; col1++) {
								componentfeature[componentcount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								componentcount++;
							}
						}
						loginflag++;
						break;
					
					case 11:
						if (loginflag > 0) {
							for (int col1 = 6; col1 < col; col1++) {

								momentfeature[momentcount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								momentcount++;
							}

						} else {
							for (int col1 = 5; col1 < col; col1++) {
								momentfeature[momentcount] = row.getCell(4).getStringCellValue() + row.getCell(col1).getStringCellValue();
								momentcount++;
							}
						}
						loginflag++;
						break;

					}

					if (channelfeature[0] != null) {
						for (int j = 0; j < channelcount; j++) {
							// System.out.println(i);
							System.out.println(channelfeature[j]);
							System.setProperty("cucumber.options", channelfeature[j]);
							/**
							 * Newer version of cucumber does not support
							 * alteration of system runtime once set. This code
							 * below is to force runtime to change
							 * cucumber.options. <br/>
							 * TODO : This code must be removed once new design
							 * patterns are incorporated in the code base
							 */

							Env instance = Env.INSTANCE;
							try {
								final Method declaredMethod = instance.getClass().getDeclaredMethod("put", String.class, String.class);
								declaredMethod.setAccessible(true);
								declaredMethod.invoke(instance, "cucumber.options", channelfeature[j]);
							} catch (Exception e) {
								e.printStackTrace();
							}
							jUnitRunner.run(com.mystique.channelsteps.RunTests.class);
							//System.clearProperty("cucumber.options");
							/*
							 * k=channelfeature[j].lastIndexOf("/");
							 * newname=channelfeature[j].substring(k+1);
							 */
							rename_report("report_channelsteps.html", "report_channelsteps_" + j + ".html");
						}
					}
					if (genadminfeature[0] != null) {
						for (int j = 0; j < gencount; j++) {
							System.setProperty("cucumber.options", genadminfeature[j]);
							/**
							 * Newer version of cucumber does not support
							 * alteration of system runtime once set. This code
							 * below is to force runtime to change
							 * cucumber.options. <br/>
							 * TODO : This code must be removed once new design
							 * patterns are incorporated in the code base
							 */

							Env instance = Env.INSTANCE;
							try {
								final Method declaredMethod = instance.getClass().getDeclaredMethod("put", String.class, String.class);
								declaredMethod.setAccessible(true);
								declaredMethod.invoke(instance, "cucumber.options", genadminfeature[j]);
							} catch (Exception e) {
								e.printStackTrace();
							}

							jUnitRunner.run(com.mystique.generaladministration.RunTests.class);
							rename_report("report_generaladministration.html", "report_generaladministration_" + j + ".html");

						}
					}
					if (programfeature[0] != null) {
						for (int j = 0; j < programcount; j++) {
							System.out.println(programfeature[j]);
							System.setProperty("cucumber.options", programfeature[j]);
							/**
							 * Newer version of cucumber does not support
							 * alteration of system runtime once set. This code
							 * below is to force runtime to change
							 * cucumber.options. <br/>
							 * TODO : This code must be removed once new design
							 * patterns are incorporated in the code base
							 */

							Env instance = Env.INSTANCE;
							try {
								final Method declaredMethod = instance.getClass().getDeclaredMethod("put", String.class, String.class);
								declaredMethod.setAccessible(true);
								declaredMethod.invoke(instance, "cucumber.options", programfeature[j]);
							} catch (Exception e) {
								e.printStackTrace();
							}

							jUnitRunner.run(com.mystique.programsteps.RunTests.class);
							/*
							 * k=programfeature[j].lastIndexOf("/");
							 * newname=programfeature[j].substring(k+1);
							 */
							rename_report("report_programsteps.html", "report_programsteps_" + j + ".html");
						}

					}
					if (propertyfeature[0] != null) {
						for (int j = 0; j < propcount; j++) {
							System.out.println(propertyfeature[j]);
							System.setProperty("cucumber.options", propertyfeature[j]);
							/**
							 * Newer version of cucumber does not support
							 * alteration of system runtime once set. This code
							 * below is to force runtime to change
							 * cucumber.options. <br/>
							 * TODO : This code must be removed once new design
							 * patterns are incorporated in the code base
							 */

							Env instance = Env.INSTANCE;
							try {
								final Method declaredMethod = instance.getClass().getDeclaredMethod("put", String.class, String.class);
								declaredMethod.setAccessible(true);
								declaredMethod.invoke(instance, "cucumber.options", propertyfeature[j]);
							} catch (Exception e) {
								e.printStackTrace();
							}
							jUnitRunner.run(com.mystique.propertysteps.RunTests.class);
							/*
							 * k=propertyfeature[j].lastIndexOf("/");
							 * newname=propertyfeature[j].substring(k+1);
							 */
							rename_report("report_propertysteps.html", "report_propertysteps_" + j + ".html");
						}

					}
					if (ratefeature[0] != null) {
						for (int j = 0; j < ratecount; j++) {
							System.out.println(ratefeature[j]);
							System.setProperty("cucumber.options", ratefeature[j]);
							/**
							 * Newer version of cucumber does not support
							 * alteration of system runtime once set. This code
							 * below is to force runtime to change
							 * cucumber.options. <br/>
							 * TODO : This code must be removed once new design
							 * patterns are incorporated in the code base
							 */

							Env instance = Env.INSTANCE;
							try {
								final Method declaredMethod = instance.getClass().getDeclaredMethod("put", String.class, String.class);
								declaredMethod.setAccessible(true);
								declaredMethod.invoke(instance, "cucumber.options", ratefeature[j]);
							} catch (Exception e) {
								e.printStackTrace();
							}
							jUnitRunner.run(com.mystique.ratesteps.RunTests.class);
							/*
							 * k=ratefeature[j].lastIndexOf("/");
							 * newname=ratefeature[j].substring(k+1);
							 */
							rename_report("report_ratesteps.html", "report_ratesteps_" + j + ".html");
						}

					}
					if (restrictfeature[0] != null) {
						for (int j = 0; j < restcount; j++) {
							System.out.println(restrictfeature[j]);
							System.setProperty("cucumber.options", restrictfeature[j]);
							/**
							 * Newer version of cucumber does not support
							 * alteration of system runtime once set. This code
							 * below is to force runtime to change
							 * cucumber.options. <br/>
							 * TODO : This code must be removed once new design
							 * patterns are incorporated in the code base
							 */

							Env instance = Env.INSTANCE;
							try {
								final Method declaredMethod = instance.getClass().getDeclaredMethod("put", String.class, String.class);
								declaredMethod.setAccessible(true);
								declaredMethod.invoke(instance, "cucumber.options", restrictfeature[j]);
							} catch (Exception e) {
								e.printStackTrace();
							}
							jUnitRunner.run(com.mystique.restrictionsteps.RunTests.class);
							/*
							 * k=restrictfeature[j].lastIndexOf("/");
							 * newname=restrictfeature[j].substring(k+1);
							 */

							rename_report("report_ratesteps.html", "report_ratesteps_" + j + ".html");
							// jUnitRunner.run(com.mystique.restrictionsteps.RunTests.class);
						}

					}
					if (roomfeature[0] != null) {
						for (int j = 0; j < roomcount; j++) {
							System.out.println(roomfeature[j]);
							System.setProperty("cucumber.options", roomfeature[j]);
							/**
							 * Newer version of cucumber does not support
							 * alteration of system runtime once set. This code
							 * below is to force runtime to change
							 * cucumber.options. <br/>
							 * TODO : This code must be removed once new design
							 * patterns are incorporated in the code base
							 */

							Env instance = Env.INSTANCE;
							try {
								final Method declaredMethod = instance.getClass().getDeclaredMethod("put", String.class, String.class);
								declaredMethod.setAccessible(true);
								declaredMethod.invoke(instance, "cucumber.options", roomfeature[j]);
							} catch (Exception e) {
								e.printStackTrace();
							}
							jUnitRunner.run(com.mystique.roomsteps.RunTests.class);
							/*
							 * k=roomfeature[j].lastIndexOf("/");
							 * newname=roomfeature[j].substring(k+1);
							 */
							rename_report("report_roomsteps.html", "report_roomsteps_" + j + ".html");
						}

					}
					if (syncfeature[0] != null) {
						for (int j = 0; j < synccount; j++) {
							System.out.println(syncfeature[j]);
							System.setProperty("cucumber.options", syncfeature[j]);
							/**
							 * Newer version of cucumber does not support
							 * alteration of system runtime once set. This code
							 * below is to force runtime to change
							 * cucumber.options. <br/>
							 * TODO : This code must be removed once new design
							 * patterns are incorporated in the code base
							 */

							Env instance = Env.INSTANCE;
							try {
								final Method declaredMethod = instance.getClass().getDeclaredMethod("put", String.class, String.class);
								declaredMethod.setAccessible(true);
								declaredMethod.invoke(instance, "cucumber.options", syncfeature[j]);
							} catch (Exception e) {
								e.printStackTrace();
							}
							jUnitRunner.run(com.mystique.syncsteps.RunTests.class);
							/*
							 * k=syncfeature[j].lastIndexOf("/");
							 * newname=syncfeature[j].substring(k+1);
							 */
							rename_report("report_syncsteps.html", "report_syncsteps_" + j + ".html");
						}

					}
					if (tktprgfeature[0] != null) {
						for (int j = 0; j < tktcount; j++) {
							System.out.println(tktprgfeature[j]);
							System.setProperty("cucumber.options", tktprgfeature[j]);
							/**
							 * Newer version of cucumber does not support
							 * alteration of system runtime once set. This code
							 * below is to force runtime to change
							 * cucumber.options. <br/>
							 * TODO : This code must be removed once new design
							 * patterns are incorporated in the code base
							 */

							Env instance = Env.INSTANCE;
							try {
								final Method declaredMethod = instance.getClass().getDeclaredMethod("put", String.class, String.class);
								declaredMethod.setAccessible(true);
								declaredMethod.invoke(instance, "cucumber.options", tktprgfeature[j]);
							} catch (Exception e) {
								e.printStackTrace();
							}
							jUnitRunner.run(com.mystique.ticketprogramsteps.RunTests.class);
							/*
							 * k=tktprgfeature[j].lastIndexOf("/");
							 * newname=tktprgfeature[j].substring(k+1);
							 */
							rename_report("report_ticketsteps.html", "report_ticketsteps_" + j + ".html");
						}
					}
					if (componentfeature[0] != null) {
						for (int j = 0; j < componentcount; j++) {
							System.out.println(componentfeature[j]);
							System.setProperty("cucumber.options", componentfeature[j]);
							/**
							 * Newer version of cucumber does not support
							 * alteration of system runtime once set. This code
							 * below is to force runtime to change
							 * cucumber.options. <br/>
							 * TODO : This code must be removed once new design
							 * patterns are incorporated in the code base
							 */

							Env instance = Env.INSTANCE;
							try {
								final Method declaredMethod = instance.getClass().getDeclaredMethod("put", String.class, String.class);
								declaredMethod.setAccessible(true);
								declaredMethod.invoke(instance, "cucumber.options", componentfeature[j]);
							} catch (Exception e) {
								e.printStackTrace();
							}
							jUnitRunner.run(com.mystique.componentsteps.RunTests.class);
							/*
							 * k=tktprgfeature[j].lastIndexOf("/");
							 * newname=tktprgfeature[j].substring(k+1);
							 */
							rename_report("report_componentsteps.html", "report_componentsteps_" + j + ".html");
						}
					}
					
					if (momentfeature[0] != null) {
						for (int j = 0; j < momentcount; j++) {
							System.out.println(momentfeature[j]);
							System.setProperty("cucumber.options", momentfeature[j]);
							/**
							 * Newer version of cucumber does not support
							 * alteration of system runtime once set. This code
							 * below is to force runtime to change
							 * cucumber.options. <br/>
							 * TODO : This code must be removed once new design
							 * patterns are incorporated in the code base
							 */

							Env instance = Env.INSTANCE;
							try {
								final Method declaredMethod = instance.getClass().getDeclaredMethod("put", String.class, String.class);
								declaredMethod.setAccessible(true);
								declaredMethod.invoke(instance, "cucumber.options", momentfeature[j]);
							} catch (Exception e) {
								e.printStackTrace();
							}
							jUnitRunner.run(com.mystique.momentsteps.RunTests.class);
							/*
							 * k=tktprgfeature[j].lastIndexOf("/");
							 * newname=tktprgfeature[j].substring(k+1);
							 */
							rename_report("report_momentsteps.html", "report_momentsteps_" + j + ".html");
						}
					}

				}

				channelfeature[0] = null;
				channelcount = 0;
				genadminfeature[0] = null;
				gencount = 0;
				programfeature[0] = null;
				programcount = 0;
				propertyfeature[0] = null;
				propcount = 0;
				ratefeature[0] = null;
				ratecount = 0;
				restrictfeature[0] = null;
				restcount = 0;
				roomfeature[0] = null;
				roomcount = 0;
				syncfeature[0] = null;
				synccount = 0;
				tktprgfeature[0] = null;
				tktcount = 0;
				componentfeature[0] = null;
				componentcount = 0;
				momentfeature[0] = null;
				momentcount = 0;

			}

			System.out.println("");

			workbook.close();
			file.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		bd.quit();
		long endTime = System.currentTimeMillis();
		long diff = (endTime - startTime) / 1000;
		long mins = diff / 60;
		long hrs = mins / 60;
		long secs = diff % 60;
		if (hrs != 0)
			System.out.println("Total Time taken for Script=" + hrs + "hours " + mins + "minutes " + secs + "seconds");
		else
			System.out.println("Total Time taken for Script=" + mins + "minutes " + secs + "seconds");

	}

	static void rename_report(String name, String rename) {
		File name1 = new File("./target/" + name);
		File name2 = new File("./target/" + rename);
		// System.out.println(rename);

		/*
		 * if(name1.exists()) {System.out.println("Report found"); }
		 */
		if (name1.renameTo(name2)) {
			System.out.println("Report renamed");
		} else {
			System.out.println(" ");
		}

	}
	@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) bd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }

}
