package com.mystique.application;

import java.util.Properties;
import java.util.Set;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.UnreachableBrowserException;
import org.openqa.selenium.security.UserAndPassword;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mystique.utils.CommonUtils;
import com.mystique.utils.Constants;
import com.mystique.utils.CredentialsType;
import com.mystique.utils.User;
import com.mystique.view.LoginView;


public class BrowserDriver {
	private static WebDriver mDriver, mDriver2;
	private User user;
	private static Properties commonProperties;
	private static final Logger LOGGER = Logger.getLogger(BrowserDriver.class
			.getName());
	static CommonUtils Util=new CommonUtils();

	public synchronized static WebDriver getCurrentDriver() {
		if (mDriver == null) {
			try {
				// USE Firefox Version - 31.0 Stop autoupdate

				/*
				 * // SETUP for Jenkins LINUX job with Chrome
				 * System.setProperty("webdriver.chrome.driver",
				 * "D:\\MGM\\Softwares\\chromedriver_win32\\chromedriver.exe");
				 * mDriver = new ChromeDriver();
				 * //System.setProperty("webdriver.chrome.driver",
				 * "/usr/sbin/chromedriver");
				 * 
				 * // SETUP for Jenkins LINUX job with Firefox
				 * System.setProperty("webdriver.firefox.bin",
				 * "/usr/bin/firefox"); FirefoxBinary binary = new
				 * FirefoxBinary(new File("/usr/bin/firefox"));
				 * binary.setEnvironmentProperty("DISPLAY",":99"); mDriver = new
				 * FirefoxDriver(binary, null);
				 
				// Setup for Jenkins Windows job with Firefox
				System.setProperty("webdriver.firefox.bin",
						Constants.FIREFOX_PATH);
				System.setProperty("java.awt.headless", "false");
				FirefoxProfile firefoxProfile= new FirefoxProfile();
				firefoxProfile.setPreference("browser.download.folderList",2);
				firefoxProfile.setPreference("browser.download.manager.showWhenStarting", false);
				firefoxProfile.setPreference("browser.download.panel.shown", false);
				firefoxProfile.setPreference("browser.helperApps.neverAsk.saveToDisk", "text/csv,application/vnd.ms-excel");*/
				/*mDriver = new FirefoxDriver();
				mDriver = new FirefoxDriver();*/
				/*
				 * //Setup for Local run
				 * System.setProperty("webdriver.firefox.bin",
				 * "C:\\Program Files\\Mozilla Firefox\\firefox");
				 * System.setProperty("java.awt.headless", "false"); mDriver =
				 * new FirefoxDriver();
				 */
			    System.setProperty("webdriver.chrome.driver", "C:\\Soumen\\Softwares\\chromedriver.exe");  
			    mDriver = new ChromeDriver();

			} finally {
				Runtime.getRuntime().addShutdownHook(
						new Thread(new BrowserCleanup()));
			}
		}
		return mDriver;
	}

	public synchronized static WebDriver getCurrentDriver2() {
		if (mDriver2 == null) {
			try {
				System.setProperty("webdriver.chrome.driver", "C:\\Soumen\\Softwares\\chromedriver.exe");  
			    mDriver2 = new ChromeDriver();

			} finally {
				Runtime.getRuntime().addShutdownHook(
						new Thread(new BrowserCleanup2()));
			}
		}
		return mDriver2;
	}

	private static class BrowserCleanup implements Runnable {
		public void run() {
			LOGGER.info("Closing the browser");
			close();
		}
	}

	private static class BrowserCleanup2 implements Runnable {
		public void run() {
			LOGGER.info("Closing the browser");
			close2();
		}
	}

	public static void close() {
		try {
			getCurrentDriver().quit();
			mDriver = null;
			LOGGER.info("closing the browser");
		} catch (UnreachableBrowserException e) {
			LOGGER.info("cannot close browser: unreachable browser");
		}
	}

	public static void close2() {
		try {
			getCurrentDriver2().quit();
			mDriver = null;
			LOGGER.info("closing the browser");
		} catch (UnreachableBrowserException e) {
			LOGGER.info("cannot close browser: unreachable browser");
		}
	}

	static WebDriver bd = getCurrentDriver();
	public static void loadPage(String url) {
		LOGGER.info("Directing browser to:" + url);
		getCurrentDriver().get(url);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		getCurrentDriver().manage().window().maximize();

	}

	public static Properties getCommomProperties() {
		if (null == commonProperties) {
			commonProperties = CommonUtils.getConfigPath(Constants.COMMON_PATH);
		}
		return commonProperties;
	}

	public void given_I_navigate_to_the_mock_application() {

		if (System.getProperty("environment") == null) {
			BrowserDriver.loadPage(getCommomProperties().getProperty(
					Constants.MYSTIQUE_SERVER_URL));
			System.out.println(System.getProperty("environment"));
		} else {
			BrowserDriver.loadPage(System.getProperty("environment"));
			System.out.println(System.getProperty("environment"));
		}
		LoginView.isDisplayedCheck();
		
		
	}

	public void when_I_try_to_login(String credentialsType) {
		CredentialsType ct = CredentialsType
				.credentialsTypeForName(credentialsType);
		switch (ct) {
		case VALID:
			user = CommonUtils.createValidUser();
			break;
		case INVALID:
			// create an invalid user
			user = CommonUtils.createInvalidUser();
			break;
		}
		// try to login
		LoginView.login(user.getUsername(), user.getPassword());
	}

	public void when_I_try_to_loginOKTA() {
		Util.waitTimeElementVisibility(bd.findElement(By.xpath("//*[@id='input27']")));	
		
		bd.findElement(By.xpath("//*[@id='input27']")).click();
		bd.findElement(By.xpath("//*[@id='input27']")).clear();
		bd.findElement(By.xpath("//*[@id='input27']")).sendKeys("903404");
		Util.waitTimeElementVisibility(bd.findElement(By.xpath("//*[@id='input34']")));	
		bd.findElement(By.xpath("//*[@id='input34']")).click();
		bd.findElement(By.xpath("//*[@id='input34']")).clear();
		bd.findElement(By.xpath("//*[@id='input34']")).sendKeys("Test17test");
		Util.waitTimeElementVisibility(bd.findElement(By.xpath("//*[@id='form18']/div[2]/input")));	
		bd.findElement(By.xpath("//*[@id='form18']/div[2]/input")).click();
		WebDriverWait wait = new WebDriverWait(bd, 20);      
		Alert alert = wait.until(ExpectedConditions.alertIsPresent());     
		alert.authenticateUsing(new UserAndPassword("supadhyay","Welcome4"));
		String master=bd.getWindowHandle();
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Set<String> handles =bd.getWindowHandles();
		for(String handle:handles)
		{
			if(!handle.equals(master))
			{
				Actions action = new Actions(bd);
				action.sendKeys(Keys.ESCAPE);
			}
		}
		
		Util.waitTimeElementVisibility(bd.findElement(By.xpath("//*[@alt='Graphic Link Mystique_DEV']")));
		Assert.assertTrue("PASS, Graphic Link Mystique_DEV is present",bd.findElement(By.xpath("//*[@alt='Graphic Link Mystique_DEV']")).isDisplayed());
		bd.findElement(By.xpath("//*[@alt='Graphic Link Mystique_DEV']")).click();
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	public static WebElement waitForElement(WebElement elementToWaitFor) {
		return waitForElement(elementToWaitFor, null);
	}

	public static WebElement waitForElement(WebElement elementToWaitFor,
			Integer waitTimeInSeconds) {
		if (waitTimeInSeconds == null) {
			waitTimeInSeconds = 60;
		}

		WebDriverWait wait = new WebDriverWait(getCurrentDriver(),
				waitTimeInSeconds);
		return wait.until(ExpectedConditions.visibilityOf(elementToWaitFor));
	}
}
