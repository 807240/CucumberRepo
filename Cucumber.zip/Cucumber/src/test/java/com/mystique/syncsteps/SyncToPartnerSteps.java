package com.mystique.syncsteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueSyncView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SyncToPartnerSteps {
	
	private static final Logger LOGGER = Logger.getLogger(SyncToPartnerSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();
	
	@Given("^I click on the General Administration and sync to partners$")
	public void i_click_on_the_general_administration_and_sync_to_partners() {
		MystiqueSyncView.selectGeneralAdmin();
		MystiqueSyncView.hoverOnSyncTab();
		MystiqueSyncView.clickSyncToPartnerTab();
	}

	@When("^I provide valid input for Sync$")
	public void i_provide_valid_input_for_sync() {
		MystiqueSyncView.selectInputForSync();
		MystiqueSyncView.clickOnSync();
	}
	
	@Then("^I should see Synced successfully$")
	public void i_should_see_synced_successfully() {
		LOGGER.info("I should see Synced successfully");
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/

}
