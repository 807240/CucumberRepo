package com.mystique.channelsteps;
import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {
	private static final Logger LOGGER = Logger.getLogger(LoginSteps.class.getName());
	BrowserDriver bd = new BrowserDriver();
	static WebDriver wd=BrowserDriver.getCurrentDriver();
	

	@Given("^I navigate to Mystique Application$")
	public void I_navigate_to_Mystique_Application() {
		bd.given_I_navigate_to_the_mock_application();
	}

	@When("^I try to login with valid credentials$")
	public void I_try_to_login_with_valid_credentials() {
		bd.when_I_try_to_login("valid");
	}

	@Then("^I should see that i login successfully$")
	public void I_should_see_that_i_login_successfully() {
		LOGGER.info("Successfully Logged in");
	}
	
/*	OKTA Login functionality*/
	@Given("^I navigate to Mystique Application and am redierected to OKTA$")
	public void I_navigate_to_Mystique_Application_and_am_redierected_to_OKTA() {
		bd.given_I_navigate_to_the_mock_application();
		LOGGER.info("Redirected to OKTA-Preview");
	}

	@When("^I try to login with valid credentials and select Mystique$")
	public void I_try_to_login_with_valid_credentials_and_select_Mystique() {
		bd.when_I_try_to_loginOKTA();
		LOGGER.info("Redirecting to Mystique");
	}

	@Then("^I should see that i login successfully into Mystique$")
	public void I_should_see_that_i_login_successfully_into_Mystique() {
		try {
			Thread.sleep(15000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("Successfully Logged into Mystique");
	}
	@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }

	
}
