package com.mystique.channelsteps;

import java.awt.Color;
import java.util.Properties;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.utils.CommonUtils;
import com.mystique.utils.Constants;
import com.mystique.view.MystiqueChannelView;
import com.mystique.view.MystiqueProgramView;
import com.mystique.view.MystiqueRatesView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PartnerReportSteps {

	private static final Logger LOGGER = Logger.getLogger(PartnerReportSteps.class.getName()); 
	WebDriver wd= BrowserDriver.getCurrentDriver();
	
	@Given("^I provide all input data$")
	public void I_provide_all_input_data() throws Exception {
		MystiqueChannelView.selectPartnerReportMenu();
		LOGGER.info("*** Partner Report sub-menu select is complete ***");
		MystiqueChannelView.selectChannelDropdown();
		LOGGER.info("*** Channel select is complete ***");
		MystiqueChannelView.selectPropertyDropdown();
		LOGGER.info("*** Property select is complete ***");
		MystiqueChannelView.inputDate("03/30/2016","04/10/2016");
		LOGGER.info("*** From date select is complete ***");
	}
	
	@When("^I click on the search button$")
	public void I_click_on_the_search_button() throws Exception {
		
		MystiqueChannelView.clickSearchButton();
		Thread.sleep(20000);
		LOGGER.info("*** Search button is clicked ***");
	}
	
	@Then("^I should see the partner report information$")
	public void I_should_see_the_partner_report_information() {
		LOGGER.info("*** Validating Search Results and tooltip text ***");
		boolean isResultDisplayed = wd.findElements(By.xpath("//*[@id='1']/td[2]")).size()>0;
		boolean isToolTipDisplayed=wd.findElements(By.xpath("//*[@id='1']/td[8]")).size()>0;
		Assert.assertNotEquals(wd.findElements(By.xpath("//*[@id='1']/td[2]")).size(),0);
		Assert.assertNotEquals(wd.findElements(By.xpath("//*[@id='1']/td[8]")).size(),0);
		
		String color=wd.findElement(By.xpath("//*[@id='1']/td[2]")).getCssValue("color");
		
		if(isResultDisplayed && isToolTipDisplayed)
		{
			
			LOGGER.info("Test Passed");
			LOGGER.info("Color of field"+ color);
			LOGGER.info("Color of field required-"+ Color.decode("#f58782"));
		}
		else{
			LOGGER.info("Test Failed");
		}
	}
	
	
	@Given("^I search for report over particular filter criteria$")
	public void I_search_for_report_over_particular_filter_criteria() throws Exception
	{
		MystiqueChannelView.selectPartnerReportMenu();
		LOGGER.info("*** Partner Report sub-menu select is complete ***");
		MystiqueChannelView.selectChannelDropdown();
		LOGGER.info("*** Channel select is complete ***");
		MystiqueChannelView.selectPropertyDropdown();
		LOGGER.info("*** Property select is complete ***");
		MystiqueChannelView.inputDate("03/30/2016","04/10/2016");
		LOGGER.info("*** From date select is complete ***");
		MystiqueChannelView.clickSearchButton();
		Thread.sleep(20000);
		LOGGER.info("*** Search button is clicked ***");
	}
	
	@When("^I select a field where deviations exist$")
	public void I_select_a_field_where_deviations_exist() throws Exception {
		
		MystiqueChannelView.selectFieldWithDeviations();
		Thread.sleep(5000);
		LOGGER.info("*** Field with background -RED is selected ***");
	}
	
	@Then("^I should see the fields marked in red$")
	public void I_should_see_the_fields_marked_in_red() {
		LOGGER.info("*** Checking if deviations exist ***");
		MystiqueChannelView.checkIfDeviationsExist();
	}
	
	@When("^I select a field where deviations dont exist$")
	public void I_select_a_field_where_deviations_dont_exist() throws Exception {
		
		MystiqueChannelView.selectFieldWithoutDeviations();
		Thread.sleep(5000);
		LOGGER.info("*** Field with background -White is selected ***");
	}
	
	@Then("^I should see the fields marked in white$")
	public void I_should_see_the_fields_marked_in_white() {
		LOGGER.info("*** Checking if deviations exist ***");
		MystiqueChannelView.checkIfDeviationsDontExist();
	}
	
	
	@Given("^I navigate to the Partner Report page$")
	public void I_navigate_to_the_Export_Partner_Report_Link() {
		MystiqueChannelView.selectPartnerReportMenu();
		LOGGER.info("*** Partner Report sub-menu select is complete ***");
			
	}

	@When("^I provide filters and Click on Export$")
	public void I_provide_filters_and_Click_on_Export() throws Exception {
		
		MystiqueChannelView.selectChannelDropdown();
		LOGGER.info("*** Channel select is complete ***");
		MystiqueChannelView.selectPropertyDropdown();
		LOGGER.info("*** Property select is complete ***");
		MystiqueChannelView.inputDate("03/30/2016","04/10/2016");
		LOGGER.info("*** From date select is complete ***");
		MystiqueChannelView.clickSearchButton();
		Thread.sleep(20000);
		LOGGER.info("*** Search button is clicked ***");
				
	}

	@Then("^I should see the partner report exported$")
	public void I_should_see_the_partner_report_exported() { 
		
		

		LOGGER.info("Test Case Passed : The rates are exported");
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/

}
