package com.mystique.channelsteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueChannelView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;


public class ChannelNavigationSteps {
	private static final Logger LOGGER = Logger.getLogger(ChannelNavigationSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	@Given("^I click on the Drop Down to Select Channel$")
	public void I_click_on_the_Drop_Down_to_Select_Channel() {
		MystiqueChannelView.selectChannelAdmin();
	}

	@When("^I try to select Channel Administration$")
	public void I_try_to_select_Channel_Administration() {
		MystiqueChannelView.hoverOnChannelTab();
		
	}
	
	@Then("^I should see Channel related tabs$")
	public void I_should_see_Channel_related_tabs() {
		LOGGER.info("I am seeing Channel related tabs"); 
	}
	@When("^I try to select Partner Transaction Audit$")
	public void I_try_to_select_Partner_Transaction_Audit() {
		MystiqueChannelView.hoverOnChannelTab();
		MystiqueChannelView.SelectPartnerTransactionAudit();
		
	}
	@Then("^I should see Partner Transaction Audit$")
	public void I_should_see_Partner_Transaction_Audit() {
		LOGGER.info("I am seeing Channel related tabs"); 
	}
	
	@Given("^I check the existence of Property field$")
	public void I_check_the_existence_of_Property_field() {
		MystiqueChannelView.ValidatePropertyField();
		LOGGER.info("Property field exists...");
	}
	
	@When("^I try to filter property field$")
	public void I_try_to_filter_property_field() {
		
		
	}
	@Then("^I should able to filter property field$")
	public void I_should_able_to_filter_property_field() {
		
	}
	
	/* 11_sync_navigation.feature */
	@Given("^I click on the Drop Down to Select Channel1$")
	public void I_click_on_the_Drop_Down_to_Select_Channel1() {
		MystiqueChannelView.selectChannelAdmin();
	}

	@When("^I try to select Channel Administration1$")
	public void I_try_to_select_Channel_Administration1() {
		MystiqueChannelView.hoverOnSyncTab();
		
	}
	
	@Then("^I should see Sync related tabs$")
	public void I_should_see_Sync_related_tabs() {
		LOGGER.info("I am seeing Sync related tabs"); 
	}
	
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }
*/
	
}
