package com.mystique.channelsteps;

import java.util.Properties;
import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.programsteps.InternalProgramSteps;
import com.mystique.utils.CommonUtils;
import com.mystique.utils.Constants;
import com.mystique.view.MystiqueChannelView;
import com.mystique.view.MystiqueProgramView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ChannelMappingSteps {
	private static final Logger LOGGER = Logger.getLogger(ChannelMappingSteps.class.getName());
	public static final Properties channelProperties = CommonUtils.getConfigPath(Constants.CHANNEL_PATH);
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	@Given("^I click on Channel Mapping Drop Down to Edit all Mappings$")
	public void I_click_on_Channel_Mapping_Drop_Down_to_Edit_all_Mappings() {
		MystiqueProgramView.selectCampaignAdmin();
		MystiqueProgramView.selectARIAfromDropDown();
		MystiqueProgramView.hoverOnProgramTab();
		MystiqueProgramView.clickManageProgram();
		InternalProgramSteps.createNewProgramIfRequired(); 
		MystiqueChannelView.selectChannelAdmin();
		MystiqueChannelView.hoverOnChannelTab();
		MystiqueChannelView.clickOnManageChannel();
		MystiqueChannelView.filterChannelKey();
		MystiqueChannelView.filterPartnerChannelType();
		MystiqueChannelView.checkIfPartnerChannelAlreadyExists();
		MystiqueChannelView.createPartnerChannel();
		MystiqueChannelView.checkActive();
		MystiqueChannelView.selectPartnerName();
		MystiqueChannelView.provideChannelName();
		MystiqueChannelView.provideCorporateId();
		MystiqueChannelView.partnerChannelPropertyMapping();
		MystiqueChannelView.selectBillingType();
		// //MystiqueChannelView.filterManageProgram();
		// //MystiqueChannelView.checkManageProgram();
		MystiqueChannelView.clickOnSave();
		MystiqueChannelView.hoverOnChannelTab();
		MystiqueChannelView.clickOnChannelMapping();
	}

	@When("^I Edit and Add and Delete all Mappings$")
	public void I_Edit_and_Add_and_Delete_all_Mappings(){	
		MystiqueChannelView.channelKey();
        MystiqueChannelView.fetchValueDropdown();
		MystiqueChannelView.propertyName();
		//MystiqueChannelView.ratePlanMappingEditAddDelete();
		MystiqueChannelView.roomTypeMappingEditAddDelete();
		MystiqueChannelView.reservationTypeMappingEditAddDelete();
		MystiqueChannelView.specialRequestMappingEditAddDelete();
		MystiqueChannelView.paymentTypeMappingEditAddDelete();
		MystiqueChannelView.saveChannelMapping();
	}

	@Then("^I Save all Edited and Added and Deleted Channel Mappings$")
	public void I_Save_all_Edited_and_Added_and_Deleted_Channel_Mappings() throws InterruptedException {
		MystiqueChannelView.hoverOnChannelTab();
		MystiqueChannelView.clickOnManageChannel();
		MystiqueChannelView.filterChannelName();	
		MystiqueChannelView.deleteChannel();
		MystiqueChannelView.confirmAlertMessage();	
		LOGGER.info("I Save all Edited and Added and Deleted Channel Mappings"); 
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/


}
