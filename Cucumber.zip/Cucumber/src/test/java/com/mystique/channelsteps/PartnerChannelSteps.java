package com.mystique.channelsteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueChannelView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PartnerChannelSteps {
	private static final Logger LOGGER = Logger.getLogger(PartnerChannelSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	//Create Partner Channel
	@Given("^I click on Create link to provide invalid Partner Channel data$")
	public void I_click_on_Create_link_to_provide_invalid_Partner_Channel_data() {
		MystiqueChannelView.hoverOnChannelTab();
		MystiqueChannelView.clickOnManageChannel();
		MystiqueChannelView.filterChannelKey();
		MystiqueChannelView.filterPartnerChannelType();
		MystiqueChannelView.checkIfPartnerChannelAlreadyExists();
		MystiqueChannelView.createPartnerChannel();
	}

	@When("^I provide invalid data to Create Partner Channel$")
	public void I_provide_invalid_data_to_Create_Partner_Channel() {
		MystiqueChannelView.selectPartnerName();
		MystiqueChannelView.provideChannelName();
		MystiqueChannelView.provideCorporateId();
		MystiqueChannelView.partnerChannelPropertyMapping();
		MystiqueChannelView.selectBillingType();
		MystiqueChannelView.clickOnSave();
	}

	@Then("^I provide valid data for successful Partner Channel Creation$")
	public void I_provide_valid_data_for_successful_Partner_Channel_Creation() {
		LOGGER.info("I provide valid data for successful Partner Channel Creation"); 
	}
	//Edit Partner Channel

	@Given("^I click on Edit link to provide invalid Partner Channel data$")
	public void I_click_on_Edit_link_to_provide_invalid_Partner_Channel_data() {
		MystiqueChannelView.filterChannelKey();
		MystiqueChannelView.filterPartnerChannelType();
		MystiqueChannelView.clickEditPartnerChannel();
	}

	@When("^I provide invalid data to validate Partner Channel$")
	public void I_provide_invalid_data_to_validate_Partner_Channel() {
		MystiqueChannelView.provideCorporateId();
		MystiqueChannelView.selectBillingTypeEdit();
	}

	@Then("^I provide valid data for successful Partner Channel editing$")
	public void I_provide_valid_data_for_successful_Partner_Channel_editing() {
		MystiqueChannelView.clickOnSave();
		LOGGER.info("I provide valid data for successful Partner Channel editing"); 
	}

	//Delete Partner Channel

	@Given("^I click on PartnerDelete Channel link$")
	public void I_click_on_PartnerDelete_Channel_link() {
		MystiqueChannelView.filterChannelKey();
		MystiqueChannelView.filterPartnerChannelType();
	}

	@When("^I Accept Pop Up Message on Delete$")
	public void I_Accept_Pop_Up_Message_on_Delete() {
		MystiqueChannelView.deleteChannel();
		MystiqueChannelView.confirmAlertMessage();		 
	}

	@Then("^I should see Deleted PartnerChannel$")
	public void I_should_see_Deleted_PartnerChannel() {
		LOGGER.info("I should see Deleted PartnerChannel"); 
	}
	
/*	@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/


}