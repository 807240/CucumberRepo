package com.mystique.channelsteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueChannelView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class InternalChannelSteps {
	private static final Logger LOGGER = Logger.getLogger(InternalChannelSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();


	//Create Internal Channel
	@Given("^I click on Create link to provide invalid Internal Channel data$")
	public void I_click_on_Create_link_to_provide_invalid_Internal_Channel_data() {
		MystiqueChannelView.hoverOnChannelTab();
		MystiqueChannelView.clickOnManageChannel();
		MystiqueChannelView.filterChannelName();
		MystiqueChannelView.filterInternalChannelType();	
		MystiqueChannelView.checkIfChannelAlreadyExists();
		MystiqueChannelView.createInternalChannel();
	}

	@When("^I provide invalid data to Create Internal Channel$")
	public void I_provide_invalid_data_to_Create_Internal_Channel() {
		MystiqueChannelView.provideChannelName();
		MystiqueChannelView.clickOnSave();
	}

	@Then("^I provide valid data for successful Internal Channel Creation$")
	public void I_provide_valid_data_for_successful_Internal_Channel_Creation() {
		LOGGER.info("I provide valid data for successful Internal Channel Creation"); 
	}


	//Edit Internal Channel
	@Given("^I click on Edit link to provide invalid Internal Channel data$")
	public void I_click_on_Edit_link_to_provide_invalid_Internal_Channel_data() {
		MystiqueChannelView.filterChannelName();
		MystiqueChannelView.filterInternalChannelType();	
	}

	@When("^I provide invalid data to validate Internal Channel$")
	public void I_provide_invalid_data_to_validate_Internal_Channel() {
		MystiqueChannelView.clickEditInternalChannel();
	}

	@Then("^I provide valid data for successful Internal Channel editing$")
	public void I_provide_valid_data_for_successful_Internal_Channel_editing() {
		MystiqueChannelView.programTagInput();
		MystiqueChannelView.clickOnSave();
		LOGGER.info("I provide valid data for successful Internal Channel editing"); 
	}


	//Delete Internal Channel

	@Given("^I click on Delete InternalChannel link$")
	public void I_click_on_Delete_InternalChannel_link() {
		MystiqueChannelView.filterChannelName();
		MystiqueChannelView.filterInternalChannelType();

	}

	@When("^I Accept Pop Up Message$")
	public void I_Accept_Pop_Up_Message() {
		MystiqueChannelView.deleteChannel();
		MystiqueChannelView.confirmAlertMessage();	 
	}

	@Then("^I should see Deleted InternalChannel$")
	public void I_should_see_Deleted_InternalChannel() {
		LOGGER.info("I should see Deleted InternalChannel List"); 
	}
	
	/* 22_sync_channel.feature */
	
	@Given("^I navigate to partner rate sync$")
	public void I_navigate_to_partner_rate_sync() {
		MystiqueChannelView.hoverOnSyncTab();
	}

	@When("^I gave partner rate sync data$")
	public void I_gave_partner_rate_sync_data() {
			 MystiqueChannelView.partnerRateSync();
			 MystiqueChannelView.selectChannelDropdown();
			 MystiqueChannelView.selectPropertyDropdown();
			 MystiqueChannelView.setDateRange();
			 MystiqueChannelView.checkCheckboxes();
			 MystiqueChannelView.clickOnSyncButton();
			 
	}

	@Then("^I should see that i sync partner rate successfully$")
	public void I_should_see_that_i_sync_partner_rate_successfully() {
		LOGGER.info("I should see Success message"); 
	}
	
/*	@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/

}