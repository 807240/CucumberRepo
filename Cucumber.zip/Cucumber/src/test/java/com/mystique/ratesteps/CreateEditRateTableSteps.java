package com.mystique.ratesteps;

import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueRatesView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreateEditRateTableSteps {

	private static final Logger LOGGER = Logger.getLogger(CreateEditRateTableSteps.class.getName());
	WebDriver bd = new BrowserDriver().getCurrentDriver();
	
	/*
	 * Feature File: 12_create_rate_table.feature
	 * Scenario: Create Rate Table scenario
	 */
	@Given("^I select Manage Rate Table tab to Create Rate Table$")
	public void I_select_Manage_Rate_Table_tab_to_Create_Rate_Table() {
		MystiqueRatesView.manageRateTableTab();
		MystiqueRatesView.checkIfRatesExists();
		MystiqueRatesView.createRateTableLink();
	}

	@When("^I Create Rate Table by providing data$")
	public void I_Create_Rate_Table_by_providing_data() {

		MystiqueRatesView.provideRateTableName();
		MystiqueRatesView.rateDescription();
		MystiqueRatesView.rateShortDescription();
		MystiqueRatesView.categoryDropDown();
		MystiqueRatesView.selectRateTableFromDate();
		MystiqueRatesView.selectRateTableToDate();
		MystiqueRatesView.operaRateCategory();
		MystiqueRatesView.marketCode();
		MystiqueRatesView.packageComponent();
		//MystiqueRatesView.checkIfSyncRoomToOpera();
	}

	@Then("^I save created Rate Table successfully or cancel creation$")
	public void I_save_created_Rate_Table_successfully_or_cancel_creation() { 
	
		MystiqueRatesView.saveRateTable();	
		LOGGER.info("Create Rate Table Test Case PASSED:::::::::::::::::::::::::::::");
	}
	
	/*
	 * Feature File: 13_edit_rate_table.feature
	 * Scenario: Edit Rate Table scenario
	 */
	@Given("^I select Manage Rate Table tab to Edit Rate Table$")
	public void I_select_Manage_Rate_Table_tab_to_Edit_Rate_Table() {
		MystiqueRatesView.manageRateTableTab();
		MystiqueRatesView.filterRateTable();
		MystiqueRatesView.editRateTableLink();	
	}

	@When("^I edit Rate Table by providing data$")
	public void I_edit_Rate_Table_by_providing_data() {
		
//		MystiqueRatesView.editActiveFlag();
		MystiqueRatesView.rateTableDescriptionEdit();
		MystiqueRatesView.shortDescriptionEdit();
		MystiqueRatesView.selectRateTableFromDateEdit();
		MystiqueRatesView.selectRateTableToDateEdit();
		MystiqueRatesView.operaRateCategoryEdit();
		MystiqueRatesView.marketCodeEdit();				
	}

	@Then("^I save edited Rate Table successfully or cancel changes$")
	public void I_save_edited_Rate_Table_successfully_or_cancel_changes() { 
		
		MystiqueRatesView.saveRateTable();
		LOGGER.info("Edit Rate Table Test Case PASSED::::::::::::::::::::::::::::");
	}
	
	@Given("^I select Manage Rate Modifier tab on Rates Menu$")
	public void I_select_Manage_Rate_Modifier_tab_on_Rates_Menu() {
		MystiqueRatesView.manageRateModifierTab();
			
	}

	@When("^I provide Rate Table,Room and date fields and click Go$")
	public void I_provide_Rate_Table_Room_and_date_fields_and_click_Go() {
		
		MystiqueRatesView.provideDataForRateModifier();
		MystiqueRatesView.clickRateModifierGo();
	}

	@Then("^I should see the existing rate or rate modifier$")
	public void I_should_see_the_existing_rate_or_rate_modifier() { 
		
		MystiqueRatesView.checkExistingRates();

		LOGGER.info("View Rate Modifier Test Case PASSED::::::::::::::::::::::::::::");
	}
	
	@When("^I change the rate modifier for a room on a particular date$")
	public void I_change_the_rate_modifier_for_a_room_on_a_particular_date() {
		
		MystiqueRatesView.provideDataForRateModifier();
		MystiqueRatesView.clickRateModifierGo();
		MystiqueRatesView.newRateModifier();
		
	}

	@Then("^I should see the new rate reflected$")
	public void I_should_see_the_new_rate_reflected() { 
		
		if(bd.findElements(By.xpath("//p[contains(text(),'Record Submitted')]")).size()>0)
		{
			LOGGER.info("Create Rate Modifier Test Case PASSED::::::::::::::::::::::::::::");
		}
		else
		{
			LOGGER.info("Create Rate Modifier Test Case FAILED::::::::::::::::::::::::::::");
		}
		
	}
	
	@Given("^I navigate to the Export Rates Link$")
	public void I_navigate_to_the_Export_Rates_Link() {
		MystiqueRatesView.manageRateTableTab();
			
	}

	@When("^I provide filters and Click on Export$")
	public void I_provide_combination_of_RateTable_RoomType_and_DateRange_and_Click_on_Export() {
		
		MystiqueRatesView.clickOnExportRates();
		MystiqueRatesView.provideDataForExport();
		MystiqueRatesView.clickDownloadLink();
				
	}

	@Then("^I should see the rates exported$")
	public void I_should_see_the_rates_exported() { 

		LOGGER.info("Test Case Passed : The rates are exported");
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) bd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/
	
	@Given("^I land on the Dashboard post login and hover on the individual property hover menu$")
	public void I_land_on_the_Dashboard_post_login() {
		MystiqueRatesView.hoverOnDashboardPropertyMenu();
			
	}

	@When("^I select Rates/Restriction$")
	public void I_hover_on_the_individual_property_hover_menu_and_select_RatesRestriction() {
		
		MystiqueRatesView.selectPropertySubMenu();
				
	}

	@Then("^I should be redirected to the Property Administration page with the active Rate Tables displayed$")
	public void Property_Administration_with_active_Rate_Tables_Displayed() { 
		LOGGER.info("Checking if Active Rate Tables are displayed");
		
		MystiqueRatesView.checkRateTableDisplay();
		
	}
	
	@Given("^I land on the Property Administration page and hover on the rate table hover menu$")
	public void I_land_on_the_Property_Administration_page_and_hover_on_the_rate_table_hover_menu() {
		MystiqueRatesView.returnToHomeDashboard();
		MystiqueRatesView.hoverOnDashboardPropertyMenu();
		MystiqueRatesView.selectPropertySubMenu();
		MystiqueRatesView.checkRateTableDisplay();
		MystiqueRatesView.hoveronRateTable();
			
	}

	@When("^I select Edit Rates$")
	public void I_select_Edit_Rates() {
		
		MystiqueRatesView.selectEditRates();
				
	}

	@Then("^I should be redirected to the Change Rates page with the preselected RateTable as default$")
	public void I_should_be_redirected_to_the_Change_Rates_page_with_the_preselected_RateTable_as_default() { 
		LOGGER.info("Checking if Active Rate Tables are displayed");
		
		MystiqueRatesView.checkRateTableDisplayEditRates();
		
	}
	
	@When("^I select Manage Rate Modifier$")
	public void I_select_Manage_Rate_Modifier() {
		
		MystiqueRatesView.selectmngRateModifier();
				
	}

	@Then("^I should be redirected to the Manage Rate Modifier page with the preselected RateTable as default$")
	public void I_should_be_redirected_to_the_Manage_Rate_Modifier_page_with_the_preselected_RateTable_as_default() { 
		LOGGER.info("Checking if Active Rate Tables are displayed");
		
		MystiqueRatesView.checkRateTableDisplayMngRateModifier();
		
	}
	
	@When("^I select rate ImportExport$")
	public void I_select_rate_ImportExport() {
		
		MystiqueRatesView.selectRateImportExport();
				
	}

	@Then("^I should be redirected to the Rate ImportExport page with the preselected RateTable as default$")
	public void I_should_be_redirected_to_the_Rate_ImportExport_page_with_the_preselected_RateTable_as_default() { 
		LOGGER.info("Checking if Active Rate Tables are displayed");
		
		MystiqueRatesView.checkRateTableDisplayRateImportExport();
		
	}
	
	/*
	 * Feature File: 17_edit_rates.feature
	 * Scenario: Edit Rates inside Manage Rate Table scenario
	 */
	@Given("^I select Manage Rate Table tab to Edit Rates$")
	public void I_select_Manage_Rate_Table_tab_to_Edit_Rates() {
		MystiqueRatesView.manageRateTableTab();
		MystiqueRatesView.filterRateTable();
		MystiqueRatesView.editRatesLink();
	}
	
	@When("^I edit Rates by providing data$")
	public void I_edit_Rates_by_providing_data() {
		
		MystiqueRatesView.selectRoomType();
		MystiqueRatesView.selectDateRange();
		MystiqueRatesView.clickOnGoForRates();
		MystiqueRatesView.editDateRate();
	}

	@Then("^I save created Rates successfully$")
	public void I_save_created_Rates_successfully() { 
		LOGGER.info("clicking on submit now rates");
		MystiqueRatesView.submitNowRates();
		
		LOGGER.info("clicking on submit rates");
		MystiqueRatesView.submitRates();
		LOGGER.info("Edit Rates Test Case PASSED::::::::::::::::::::::::::::");
	}
	
	/*
	 * Feature File: 17_search_rate.feature
	 * Scenario: Search rates
	 */
	@Given("^I select Rate Search Query tab to search Rate Table$")
	public void I_select_Rate_Search_Query_tab_to_search_Rate_Table() {
		MystiqueRatesView.selectRateSearchQuery();
		MystiqueRatesView.selectSearchRoomType();
		MystiqueRatesView.selectChannelDropDown();
		MystiqueRatesView.stayDate();
	}
	@When("^I try to search with valid data for rates$")
	public void  I_try_to_search_with_valid_data_for_rates() {
		MystiqueRatesView.searchRate();
		MystiqueRatesView.availableRecords();
	}

	@Then("^I should see the available rates$")
	public void I_should_see_the_available_rates() { 
		LOGGER.info("I should see Rates List"); 
	}

}
