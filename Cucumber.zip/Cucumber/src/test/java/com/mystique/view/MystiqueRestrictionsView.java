package com.mystique.view;

import java.awt.AWTException;
import java.awt.Robot;
import java.util.Properties;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.MystiqueRestrictionsContainer;
import com.mystique.utils.CommonUtils;
import com.mystique.utils.Constants;

public class MystiqueRestrictionsView {
	
	
	public static final Properties restrictionProperties = CommonUtils.getConfigPath(Constants.RESTRICTION_PATH);
	static CommonUtils Util=new CommonUtils();
	
	private static final Logger LOGGER = Logger
			.getLogger(MystiqueRestrictionsView.class.getName());
	private static final MystiqueRestrictionsContainer restrictionsContainer = PageFactory
			.initElements(BrowserDriver.getCurrentDriver(),
					MystiqueRestrictionsContainer.class);
	static WebDriver bd = BrowserDriver.getCurrentDriver();
	static JavascriptExecutor executor = (JavascriptExecutor) bd;
	
	/*
	 * Manage Restrictions
	 */
	public static void hoverOnRestrictionsTab() {
		try{
			Actions action = new Actions(BrowserDriver.getCurrentDriver());		
			WebElement we =BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:menuPanel']/div/ul/li[9]/a/span[2]"));
			//WebElement we=restrictionsContainer.menuPanel.findElement(By.xpath("//*[@id='layoutForm:restrictions']/a/span[2]"));
			action.moveToElement(we).build().perform();
			try {
				Thread.sleep(6000);
			} catch (InterruptedException e) {
	
				e.printStackTrace();
			}
			/*restrictionsContainer.manageRestrictions.click();
			try {
				Thread.sleep(15000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
			LOGGER.info("Inside Restriction:");
		}catch(Exception e){
			/*BrowserDriver.getCurrentDriver().navigate().to("vmmystqapp02d:8180/mystique/propertyManagement-nav/restrictions.xhtml");
			LOGGER.info("Before Clicking on the Manage Restrictions");
			try {
				Thread.sleep(15000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}*/
		}
		
		/*Point coordinates = restrictionsContainer.restrictions
				.findElement(
						By.xpath("//*[@id='layoutForm:restrictions']/a/span[2]"))
				.getLocation();
		Robot robot = null;
		try {
			robot = new Robot();
		} catch (AWTException e1) {

			e1.printStackTrace();
		}
		robot.mouseMove(coordinates.getX() + 30, coordinates.getY() + 95);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("Before Clicking on the Manage Restrictions");
		robot.mouseMove(coordinates.getX() + 300, coordinates.getY() + 950);*/
		
	}
	
	public static void selectManageRestrictions() {
		
		try {
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:manageRescriction']")).size();
			Assert.assertTrue("Failed, Manage Restrictions element is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Manage Restrictions element is present",restrictionsContainer.manageRestrictions.isDisplayed());
			
			executor.executeScript("arguments[0].click()", restrictionsContainer.manageRestrictions);
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("Inside Restriction:");
	}
	
	public static void selectViewRestrictions() {
		
		try {
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:generateReport']/span")).size();
			Assert.assertTrue("Failed, View Restrictions element is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, View Restrictions element is present",restrictionsContainer.viewRestrictions.isDisplayed());
			executor.executeScript("arguments[0].click()", restrictionsContainer.viewRestrictions);
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("Inside View Restriction:");
	}
	
	
	public static void selectDateRange() {
		Util.waitTimeElementVisibility(restrictionsContainer.restriction_to);
		restrictionsContainer.restriction_to.clear();
		restrictionsContainer.restriction_to.sendKeys("03/24/2020");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(restrictionsContainer.restriction_from);
		restrictionsContainer.restriction_from.clear();
		restrictionsContainer.restriction_from.sendKeys("01/25/2020");
		LOGGER.info("Date Range is Selected");
		
	}
	
	//Soumen Bose
	public static void selectALLChannels(){
		try{
		Util.waitTimeElementVisibility(restrictionsContainer.selectAllChannel);
		executor.executeScript("arguments[0].click()", restrictionsContainer.selectAllChannel);
		Thread.sleep(10000);
		} catch(InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	
	//Soumen Bose
	public static void selectALLPrograms(){
		try{
			Util.waitTimeElementVisibility(restrictionsContainer.selectAllPrograms);
			executor.executeScript("arguments[0].click()", restrictionsContainer.selectAllPrograms);
			Thread.sleep(10000);
			} catch(InterruptedException e) {

				e.printStackTrace();
			}
		
	}
	
	
	public static void ClickSearchButton() {
		try {
			Util.waitTimeElementVisibility(restrictionsContainer.restriction_search);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:buttonSearch']")).size();
			Assert.assertTrue("Failed, Restriction search element is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Restriction search element is present",restrictionsContainer.restriction_search.isDisplayed());
			//restrictionsContainer.restriction_search.click();
			
			executor.executeScript("arguments[0].click()", restrictionsContainer.restriction_search);
			Thread.sleep(10000);
			((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	
	
	
	public static void selectChannelProgramRoomType() {
		
		restrictionsContainer.channel1.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		restrictionsContainer.programTagInput.sendKeys("TAG1");
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		restrictionsContainer.selectProgramTag.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.program1.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		/*restrictionsContainer.roomType1.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/

	}
	
	public static void viewRestrictionsByMonth() {
		restrictionsContainer.selectByMonth.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.monthDropDown.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.selectMonth.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.yearDropDown.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.selectYear.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void resetChannelProgramRoomType() {
		restrictionsContainer.channelReset.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.programReset.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.roomTypeReset.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void selectAllChannelProgramRoomType() {
		restrictionsContainer.selectAllChannel.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.selectAllProgram.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.selectAllRoomType.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void clickMonthGo() {
		restrictionsContainer.goButtonMonth.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void viewRestrictionsByTravelWindow() {
		executor.executeScript("arguments[0].click()", restrictionsContainer.selectByTravelWindow);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.travelWindowFrom.sendKeys(restrictionProperties.getProperty("restriction.travelWindowFrom"));
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		//restrictionsContainer.travelWindowTo.clear();
		for (int i = 0; i < 10;i++) {
			restrictionsContainer.travelWindowTo.sendKeys(Keys.BACK_SPACE);
		}
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
    	restrictionsContainer.travelWindowTo.sendKeys(restrictionProperties.getProperty("restriction.travelWindowTo"));
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.goButtonTravelWindow.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	
	public static void editRestrictionsByTravelWindow() {
		((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		executor.executeScript("arguments[0].click()",restrictionsContainer.ctaCheck2);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		
	}
	public static void selectSearchRestrictions() {
		executor.executeScript("arguments[0].click()",restrictionsContainer.searchRestrictions);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("Inside Restriction:");
		
	}

	
	
	
	public static void programResetToEditTheo() {
		restrictionsContainer.programReset.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void editRestrictionsTheo() {
		restrictionsContainer.theo1.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.theoTypeDropDown1.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.theoType1Option1.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.saveTheo1.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		/*BrowserDriver.getCurrentDriver().switchTo().alert().accept();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		restrictionsContainer.cancelTheo1.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.theo1.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.theoTypeDropDown1.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.theoType1Option2.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.theoType1Option2MinValue1.sendKeys("25.0");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.theoType1Option2MaxValue1.sendKeys("55.0");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.theoType1Option3.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.theoType1Option3Value1.sendKeys("45.0");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.theoType1Option4.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.theoType1Option4Value1.sendKeys("70.0");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.saveTheo1.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void allCheckForAll() {
		restrictionsContainer.allCloseCheck.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.allCtaCheck.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.allCtdCheck.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.allLossCheck.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.allLosValueDropDown.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.allLosValue.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void allClear() {
		restrictionsContainer.allClearCheck.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void editingComments() {
		restrictionsContainer.comments.clear();
		restrictionsContainer.comments.sendKeys(restrictionProperties.getProperty("restriction.comments"));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void reviewEditedRestrictions() {
		restrictionsContainer.reviewButton.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void backFromReview() {
		restrictionsContainer.backReviewed.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void saveReviewedRestrictions() {
		
		try {
			int intTest = bd.findElements(By.id("layoutForm:btnSchedule")).size();
			Assert.assertTrue("Failed, Save Reviewed element is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Save Reviewed element is present",restrictionsContainer.saveReviewed.isDisplayed());
			restrictionsContainer.saveReviewed.click();
			Thread.sleep(20000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}

	public static void addRestrictionDate() {
		
		try {
			
			restrictionsContainer.selectByRestrictionfromDate.clear();
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.selectByRestrictionfromDate.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.selectByRestrictionfromDate.sendKeys(restrictionProperties.getProperty("restriction.selectByRestrictionfromDate"));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.selectByRestrictionToDate.clear();;
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		restrictionsContainer.selectByRestrictionToDate.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		int intTest = bd.findElements(By.id("layoutForm:toDateRangeRestriction_input")).size();
		Assert.assertTrue("Failed, Restriction To Date element is not present",intTest > 0);
		
		//Assert.assertTrue("PASS, Restriction To Date element is present",restrictionsContainer.selectByRestrictionToDate.isDisplayed());
		restrictionsContainer.selectByRestrictionToDate.sendKeys(restrictionProperties.getProperty("restriction.selectByRestrictionToDate"));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public static void houseRestrictionsCheck() {
		restrictionsContainer.houseRestrictionsCheck.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public static void clickOnSearch() {
		
		try {
			int intTest = bd.findElements(By.id("layoutForm:buttonSearch")).size();
			Assert.assertTrue("Failed, Click on Search button is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Click on Search button is present",restrictionsContainer.clickonSearch.isDisplayed());
			executor.executeScript("arguments[0].click()", restrictionsContainer.clickonSearch);
			Thread.sleep(1000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}

	public static void programTagInputManage() {
		restrictionsContainer.programTagInput.sendKeys(restrictionProperties.getProperty("programTagrestriction.programTagInput"));
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		restrictionsContainer.programTagSelect1.click();
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		restrictionsContainer.programTagInput.sendKeys(restrictionProperties.getProperty("programTagrestriction.anotherprogramTagInput"));
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		restrictionsContainer.programTagSelect2.click();
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void programTagInputSearch() {
		restrictionsContainer.programTagInput.sendKeys(restrictionProperties.getProperty("programTagrestriction.programTagInput"));
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		restrictionsContainer.programTagSelect1.click();
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		restrictionsContainer.programTagInput.sendKeys(restrictionProperties.getProperty("programTagrestriction.anotherprogramTagInput"));
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		
		try {
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:programTags_panel']/ul/li[35]")).size();
			Assert.assertTrue("Failed, Program Tag element is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Program Tag element is present",restrictionsContainer.programTagSelect2.isDisplayed());
			restrictionsContainer.programTagSelect2.click();
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
}
