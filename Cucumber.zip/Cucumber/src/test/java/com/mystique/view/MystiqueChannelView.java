package com.mystique.view;

import java.awt.Color;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.MystiqueChannelContainer;
import com.mystique.utils.CommonUtils;
import com.mystique.utils.Constants;


public class MystiqueChannelView {

	public static final Properties channelProperties = CommonUtils.getConfigPath(Constants.CHANNEL_PATH);
	public static final Properties commonProperties = CommonUtils.getConfigPath(Constants.COMMON_PATH);
	
	private static final Logger LOGGER = Logger
			.getLogger(MystiqueChannelView.class.getName());
	private static final MystiqueChannelContainer channelContainer = PageFactory
			.initElements(BrowserDriver.getCurrentDriver(),
					MystiqueChannelContainer.class);
	
	static WebDriver bd = BrowserDriver.getCurrentDriver();
	static JavascriptExecutor executor = (JavascriptExecutor)bd; 
	static CommonUtils Util=new CommonUtils();
	
	/*START: Add - New step actions for new page Partner Sync*/
	
	/**
	 * Clicks the Partner Sync menu
	 */
	public static void selectPartnerReportMenu() {
		//Checks whether Channel menu is visible
		new WebDriverWait(bd, 40).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[@class='ui-menuitem-text' and contains(text(),'Channel')])[1]")));
		Actions action = new Actions(BrowserDriver.getCurrentDriver());
		WebElement we = bd.findElement(By.xpath("(//*[@class='ui-menuitem-text' and contains(text(),'Channel')])[1]"));
		//Hover on Channel menu
		action.moveToElement(we).build().perform();
		//Clicks on the Partner Report sub-menu
		//channelContainer.menuPartnerReport.click();
		executor.executeScript("arguments[0].click();",channelContainer.menuPartnerReport); 
		
	}
	
	/**
	 * Inputs the channel name - the value should be a user data
	 */
	public static void inputChannel(String channelName) throws Exception {
		//Waits for drop-down arrow to be visible
		Util.waitTimeElementVisibility(channelContainer.clickChannelSelect);
		//Clicks the drop-down to make the values visible
		channelContainer.clickChannelSelect.click();
		Thread.sleep(5000);
		//Selects the channel name from the drop-down list values
		//CommonUtils.fetchValueFromDropdown(String.valueOf(channelContainer.dropdownChannelSelect), channelName);
		CommonUtils.fetchValueFromDropdown("//*[@id='layoutForm:channel_panel']", channelName);
	}
	
	/**
	 * Inputs the property name - the value should be user data 
	 */
	public static void inputProperty(String propertylName) throws Exception {
		//Waits for drop-down arrow to be visible
		Util.waitTimeElementVisibility(channelContainer.clickPropertySelect);
		LOGGER.info("Property drop-down exists...");
		//Clicks the drop-down to make the values visible
		//if (channelContainer.clickPropertySelect.isEnabled()) {
			channelContainer.clickPropertySelect.click();
		//}
		LOGGER.info("Property drop-down clicked...");
		Thread.sleep(5000);
		//Selects the property name from the drop-down list values
		//CommonUtils.fetchValueFromDropdown(channelContainer.dropdownPropertySelect.toString(), propertylName);
		CommonUtils.fetchValueFromDropdown("//*[@id='layoutForm:property_panel']", propertylName);
	}
	
	/**
	 * Inputs from date - the value should be suer data in mm/dd/yyyy format
	 */
	public static void inputDate(String fromDateValue,String toDateValue) throws Exception {
		//Waits for from date field to be visible
		Util.waitTimeElementVisibility(channelContainer.fromDateSelect);
		//Inputs the from date
		channelContainer.fromDateSelect.sendKeys(fromDateValue);
		for (int i = 0; i < 10;i++) {
		  channelContainer.toDateSelect.sendKeys(Keys.BACK_SPACE);
		}
		channelContainer.toDateSelect.sendKeys(toDateValue);
		//Assert.assertEquals(channelContainer.toDateSelect.getText(),toDateValue);
	}
	
	/**
	 * Clicks the search button to start fetching data
	 */
	public static void clickSearchButton() throws Exception {
		try {
			//Waits for search button to be visible
			Util.waitTimeElementVisibility(channelContainer.buttonSearch);
			int intTest = bd.findElements(By.id("layoutForm:btnFetch")).size();
			Assert.assertTrue("Failed, Search button is not present",intTest > 0);
			//Assert.assertTrue("PASS, Search button is present",channelContainer.buttonSearch.isDisplayed());
			//Clicks on the search button
			channelContainer.buttonSearch.click();
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}  
		
	}
	
	public static void clickExportButton() throws Exception {
		try {
			//Waits for search button to be visible
			Util.waitTimeElementVisibility(channelContainer.buttonExport);
			int intTest = bd.findElements(By.id("layoutForm:btnExport")).size();
			Assert.assertTrue("Failed, Search button is not present",intTest > 0);
			//Assert.assertTrue("PASS, Search button is present",channelContainer.buttonSearch.isDisplayed());
			//Clicks on the search button
			channelContainer.buttonExport.click();
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}  
		
	}
	
	/*START: Select Channel from dropdown*/
	public static void selectChannelDropdown()  {
		try {
			Util.waitTimeElementVisibility(channelContainer.clickChannelSelect);
			channelContainer.clickChannelSelect.click();
			Thread.sleep(5000);
			channelContainer.dropdownChannelSelect.click();
			Thread.sleep(5000);
			
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	
	/*END: Select Channel from dropdown*/
	
	/*START: Select Property from dropdown*/
	public static void selectPropertyDropdown() {
		try {
			Util.waitTimeElementVisibility(channelContainer.clickPropertySelect);
			LOGGER.info("*** Clicking on Prop Dropdown ***");
			channelContainer.clickPropertySelect.click();
			LOGGER.info("*** Clicked on Prop Dropdown ***");
			Thread.sleep(5000);
			channelContainer.dropdownPropertySelect.click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	
	/*END: Select Property from dropdown*/

	/*END: Add - New step actions for new page Partner Sync*/
	
	public static void selectChannelAdmin(){
		
		try {
			Thread.sleep(12000);
			Util.waitTimeElementVisibility(channelContainer.channelAdminDropDown);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:applicationSelectMenu']/div[3]/span")).size();
			Assert.assertTrue("Failed, Channel Admin DropDown is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Channel Admin DropDown is present",channelContainer.channelAdminDropDown.isDisplayed());
			executor.executeScript("arguments[0].click();",channelContainer.channelAdminDropDown); 
			//channelContainer.channelAdminDropDown.click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("Clicking on Channel Administration drop down");
		Util.waitTimeElementVisibility(channelContainer.selectChannelAdmin); 
		channelContainer.selectChannelAdmin.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}  
	}

	
	public static void hoverOnChannelTab() {
		LOGGER.info("Inside select Channel:");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}		
		
		try {
			//Util.waitTimeElementVisibility(bd.findElement(By.xpath("(//*[@class='ui-menuitem-text' and contains(text(),'Channel')])[1]"))); 
			new WebDriverWait(bd,40).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[@class='ui-menuitem-text' and contains(text(),'Channel')])[1]")));
			Actions action = new Actions(BrowserDriver.getCurrentDriver());
			WebElement we =bd.findElement(By.xpath("(//*[@class='ui-menuitem-text' and contains(text(),'Channel')])[1]"));
			int intTest = bd.findElements(By.xpath("(//*[@class='ui-menuitem-text' and contains(text(),'Channel')])[1]")).size();
			Assert.assertTrue("Failed, Channel Tab is not present",intTest > 0);
			//Assert.assertTrue("PASS, Channel Tab is present",we.isDisplayed());
			action.moveToElement(we).build().perform();
			/*Point coordinates = channelContainer.channelMenu
					.findElement(
							By.xpath("//*[@id='layoutForm:menuPanel']/div/ul/li[2]/a/span[2]"))
					.getLocation();
			Robot robot = null;
			try {
				robot = new Robot();
			} catch (AWTException e1) {

				e1.printStackTrace();
			}
			robot.mouseMove(coordinates.getX() + 30, coordinates.getY() + 95);*/
			
			Thread.sleep(3000);
			
		} catch (InterruptedException e) {

			e.printStackTrace();
		}		
	}
	
	public static void hoverOnSyncTab() {
		LOGGER.info("Inside select Channel:");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}		
		
		try {
			new WebDriverWait(bd,40).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"layoutForm:menuBar\"]/ul/li[2]/a/span[2]")));
			Actions action = new Actions(BrowserDriver.getCurrentDriver());
			WebElement we =bd.findElement(By.xpath("//*[@id=\"layoutForm:menuBar\"]/ul/li[2]/a/span[2]"));
			int intTest = bd.findElements(By.xpath("//*[@id=\"layoutForm:menuBar\"]/ul/li[2]/a/span[2]")).size();
			Assert.assertTrue("Failed, Sync Tab is not present",intTest > 0);
			action.moveToElement(we).build().perform();
			
			Thread.sleep(3000);
			
		} catch (InterruptedException e) {

			e.printStackTrace();
		}		
	}
	
	public static void SelectPartnerTransactionAudit(){
		try {
			Thread.sleep(20000);
			new WebDriverWait(bd,40).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[@class='ui-menuitem-text' and contains(text(),'Partner Transaction Audit')])[1]")));
			Actions action = new Actions(BrowserDriver.getCurrentDriver());
			WebElement we =bd.findElement(By.xpath("(//*[@class='ui-menuitem-text' and contains(text(),'Partner Transaction Audit')])[1]"));
			int intTest = bd.findElements(By.xpath("(//*[@class='ui-menuitem-text' and contains(text(),'Partner Transaction Audit')])[1]")).size();
			Assert.assertTrue("Failed, Partner Transaction Audit is not present",intTest > 0);
			//Assert.assertTrue("PASS, Partner Transaction Audit is present",we.isDisplayed());
			action.moveToElement(we).click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void ValidatePropertyField(){
		try {
			Thread.sleep(10000);
			int intTest = bd.findElements(By.id("layoutForm:partnerTxnDataTable:propertyId")).size();
			Assert.assertTrue("Failed, Property Field is not present",intTest > 0);
			//Assert.assertTrue("PASS, Property Field is present",channelContainer.PropertyField.isDisplayed());
			Util.waitTimeElementVisibility(channelContainer.PropertyField);
			
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	public static void clickOnManageChannel(){

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(channelContainer.selectManageChannel);
		channelContainer.selectManageChannel.click();
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void popUpAlertMessage(){
		channelContainer.clickAlertOk.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void confirmAlertMessage(){
		
		try {
			Thread.sleep(6000);
			Util.waitTimeElementVisibility(channelContainer.confirmDialoge);
			int intTest = bd.findElements(By.xpath("//*[@id=\"layoutForm:j_idt69\"]")).size();
			Assert.assertTrue("Failed, Confirm Dialog is not present",intTest > 0);
			//Assert.assertTrue("PASS, Confirm Dialog is present",channelContainer.confirmDialoge.isDisplayed());
			channelContainer.confirmDialoge.click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	
	public static void filterChannelName(){
		Util.waitTimeElementVisibility(channelContainer.channelNameFilter);
		channelContainer.channelNameFilter.clear();
		/*try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.channelNameFilter);
		channelContainer.channelNameFilter.sendKeys(channelProperties.getProperty("channel.channelName"));
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) { 

			e.printStackTrace();
		}
	}
	
	public static void filterInternalChannelType(){
				
		try {
			Util.waitTimeElementVisibility(channelContainer.channelTypeFilter);
			channelContainer.channelTypeFilter.clear();
			/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
			Util.waitTimeElementVisibility(channelContainer.channelTypeFilter);
			
			channelContainer.channelTypeFilter.sendKeys(channelProperties.getProperty("channel.channelTypeFilter"));
			//Assert.assertEquals(channelContainer.channelTypeFilter.getText(),channelProperties.getProperty("channel.channelTypeFilter"));
			Thread.sleep(15000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void clickEditInternalChannel(){
		
		try {
			Util.waitTimeElementVisibility(channelContainer.editInternalChannelLink);
			
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:channelDataTable_data']/tr[1]/td[6]/a")).size();
			Assert.assertTrue("Failed, Edit Internal Channel Link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Edit Internal Channel Link is present",channelContainer.editInternalChannelLink.isDisplayed());
			channelContainer.editInternalChannelLink.click();
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}


	
	public static void clickOnSave(){
		
		try {
			((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("window.scrollTo(0, document.body.scrollHeight)");
			Util.waitTimeElementVisibility(channelContainer.saveEditedChannel);
			int intTest = bd.findElements(By.id("layoutForm:btnSave")).size();
			Assert.assertTrue("Failed, Save Edited Channel button is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Save Edited Channel button is present",channelContainer.saveEditedChannel.isDisplayed());
			channelContainer.saveEditedChannel.click();
			Thread.sleep(35000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	
	public static void provideChannelName(){
		Util.waitTimeElementVisibility(channelContainer.channelName);
		channelContainer.channelName.sendKeys(channelProperties.getProperty("channel.channelName"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
		
			e.printStackTrace();
		}*/
	}

	
	public static void programTagInput(){
		Util.waitTimeElementVisibility(channelContainer.programTagInput);
		channelContainer.programTagInput.sendKeys(commonProperties.getProperty("common.programTagInput"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.selectInternalProgramTag);
		channelContainer.selectInternalProgramTag.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	
	
	/*
	 * Edit Partner Channel
	 */

	public static void filterChannelKey(){
		
		
		Util.waitTimeElementVisibility(channelContainer.channelKeyFilter);
		channelContainer.channelKeyFilter.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	
		channelContainer.channelKeyFilter.sendKeys(channelProperties.getProperty("channel.partnerChannelKeyFilter"));
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void filterPartnerChannelType(){
		Util.waitTimeElementVisibility(channelContainer.channelTypeFilter);
		channelContainer.channelTypeFilter.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.channelTypeFilter);
		int intTest = bd.findElements(By.id("layoutForm:channelDataTable:channelType:filter")).size();
		Assert.assertTrue("Failed, Channel Type Filter is not present",intTest > 0);
		
		//Assert.assertTrue("PASS, Channel Type Filter is present",channelContainer.channelTypeFilter.isDisplayed());
		channelContainer.channelTypeFilter.sendKeys(channelProperties.getProperty("channel.channelTypeFilterPartner"));
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void clickEditPartnerChannel(){
		
		try {
			Util.waitTimeElementVisibility(channelContainer.editPartnerChannelLink);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:channelDataTable_data']/tr[1]/td[6]/a")).size();
			Assert.assertTrue("Failed, Edit Partner Channel Link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Edit Partner Channel Link is present",channelContainer.editPartnerChannelLink.isDisplayed());
			channelContainer.editPartnerChannelLink.click();
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	
	public static void checkActive() {
		
		try
		{
			Thread.sleep(5000);
			Util.waitTimeElementVisibility(channelContainer.checkActive);
			channelContainer.checkActive.click();
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		
	}
	public static void filterManageProgram(){
		Util.waitTimeElementVisibility(channelContainer.filterManageProgram);
		channelContainer.filterManageProgram.click();
		/*try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.filterManageProgram);
		channelContainer.filterManageProgram.sendKeys(channelProperties.getProperty("channel.programIdNew"));
		/*try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	
	public static void checkManageProgram(){
		Util.waitTimeElementVisibility(channelContainer.checkManageProgram);
		channelContainer.checkManageProgram.click();
		/*try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	
	public static void selectPartnerName(){
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(channelContainer.partnerName);
		channelContainer.partnerName.sendKeys(channelProperties.getProperty("channel.partnerName"));
		/*try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void provideCorporateId(){
		Util.waitTimeElementVisibility(channelContainer.corporateId);
		channelContainer.corporateId.clear();
	/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.corporateId);
		channelContainer.corporateId.sendKeys(commonProperties.getProperty("common.corporateID"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.selectCorporateId);
		channelContainer.selectCorporateId.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		
	}
	
	
	/*
	 * property mapping partner channel
	 */
	
	public static void partnerChannelPropertyMapping(){
		Util.waitTimeElementVisibility(channelContainer.partnerChannelAddNewProperty);
		//channelContainer.partnerChannelAddNewProperty.click();
		executor.executeScript("arguments[0].click();",channelContainer.partnerChannelAddNewProperty); 
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.partnerChannelOperaPropertyDropDown);
    	//channelContainer.partnerChannelOperaPropertyDropDown.click();
    	executor.executeScript("arguments[0].click();",channelContainer.partnerChannelOperaPropertyDropDown); 
		
    	/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	*/
		//String channelKey=channelProperties.getProperty("channel.setProperty");
		//CommonUtils.fetchValueFromDropdown(Constants.CHANNEL_PROPERTY_XPATH, channelKey);
    	Util.waitTimeElementVisibility(channelContainer.selectoOeraPropertyCode);
    	//channelContainer.selectoOeraPropertyCode.click();
    	executor.executeScript("arguments[0].click();",channelContainer.selectoOeraPropertyCode); 
		
		Util.waitTimeElementVisibility(channelContainer.partnerChannelCodeProperty);
		channelContainer.partnerChannelCodeProperty.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.partnerChannelCodeProperty);
		channelContainer.partnerChannelCodeProperty.sendKeys(commonProperties.getProperty("common.partnerChannelCodeProperty"));
	/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.partnerChannelSaveProperty);
		//channelContainer.partnerChannelSaveProperty.click();
		executor.executeScript("arguments[0].click();",channelContainer.partnerChannelSaveProperty); 
		
		try {
			Thread.sleep(7000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	/*
	 * 
	 */
	public static void selectBillingType(){
		((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Util.waitTimeElementVisibility(channelContainer.billingTypeDropDown);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		//channelContainer.billingTypeDropDown.click();
		executor.executeScript("arguments[0].click();",channelContainer.billingTypeDropDown); 
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(channelContainer.selectBillingType);
		//channelContainer.selectBillingType.click();
		executor.executeScript("arguments[0].click();",channelContainer.selectBillingType); 
		
		/*try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
		public static void selectBillingTypeEdit(){
			
			try {
				((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("window.scrollTo(0, document.body.scrollHeight)");
				Util.waitTimeElementVisibility(channelContainer.billingTypeDropDown);
				//channelContainer.billingTypeDropDown.click();
				executor.executeScript("arguments[0].click();",channelContainer.billingTypeDropDown); 
				
				/*try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {

					e.printStackTrace();
				}*/
				int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:billingType1_panel']/div[1]/ul/li[4]")).size();
				Assert.assertTrue("Failed, Billing Type Edit element is not present",intTest > 0);
				
				//Assert.assertTrue("PASS, Billing Type Edit element is present",channelContainer.selectBillingTypeEdit.isDisplayed());
				channelContainer.selectBillingTypeEdit.click();
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
		}
	
		
    public static void	checkIfChannelAlreadyExists(){
    	try{
			WebElement select = BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:channelDataTable_data']/tr"));
			List<WebElement> options = select.findElements(By.tagName("td"));
	        if(options.size()>1)
	        {
	        	MystiqueChannelView.deleteChannel();
	    		MystiqueChannelView.confirmAlertMessage();	 
							
	        }	
		}catch(Exception e){
			e.printStackTrace();
		}
    	
    }

	
	public static void createInternalChannel(){
		try {
			Thread.sleep(5000);
			Util.waitTimeElementVisibility(channelContainer.createChannel);
			channelContainer.createChannel.click();
			/*try {
				Thread.sleep(15000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
			Util.waitTimeElementVisibility(channelContainer.channelTypeDropDown);
			channelContainer.channelTypeDropDown.click();
			/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
			Util.waitTimeElementVisibility(channelContainer.selectInternalChannelType);
			
			/*int intTest = bd.findElements(By.id("(//*[contains(text(),'Internal')])[2]")).size();
			Assert.assertTrue("Failed, Internal Channel Type is not present",intTest > 0);*/
			
			//Assert.assertTrue("PASS, Internal Channel Type is present",channelContainer.selectInternalChannelType.isDisplayed());
			channelContainer.selectInternalChannelType.click();
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void createPartnerChannel(){
		try {
			Thread.sleep(5000);
			Util.waitTimeElementVisibility(channelContainer.createPartnerChannel);
			executor.executeScript("arguments[0].click();",channelContainer.createPartnerChannel);
			/*try {
				Thread.sleep(20000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
			Util.waitTimeElementVisibility(channelContainer.channelTypeDropDown);
			executor.executeScript("arguments[0].click();",channelContainer.channelTypeDropDown);
			/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
			Util.waitTimeElementVisibility(channelContainer.selectPartnerChannelType);
			
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:channelType_panel']/div/ul/li[3]")).size();
			Assert.assertTrue("Failed, Channel Type panel link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Channel Type panel link is present",channelContainer.selectPartnerChannelType.isDisplayed());
			executor.executeScript("arguments[0].click();",channelContainer.selectPartnerChannelType);
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		/*try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	/*
	 * Channel Mapping
	 */
	
	public static void clickOnChannelMapping(){
	
		
		try {
			Util.waitTimeElementVisibility(channelContainer.selectChannelMapping);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:channelMapping']/span")).size();
			Assert.assertTrue("Failed, Channel Mapping is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Channel Mapping is present",channelContainer.selectChannelMapping.isDisplayed());
			executor.executeScript("arguments[0].click();",channelContainer.selectChannelMapping);
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	
	
	public static void roomTypeMappingEditAddDelete(){
		
		try
		{
			Thread.sleep(3000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(channelContainer.addNewRoom);
		executor.executeScript("arguments[0].click();",channelContainer.addNewRoom);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(channelContainer.cancelRoomNew);
		channelContainer.cancelRoomNew.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(channelContainer.addNewRoom);
		channelContainer.addNewRoom.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(channelContainer.saveRoomNew);
		channelContainer.saveRoomNew.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.clickAlertOk);
		channelContainer.clickAlertOk.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.roomCodeNew);
		channelContainer.roomCodeNew.sendKeys(channelProperties.getProperty("channel.roomCodeNew"));
		/*try {
			Thread.sleep(30000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.selectRoomCodeNew);
		channelContainer.selectRoomCodeNew.click();
	/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.partnerRoomCodeNew);
		channelContainer.partnerRoomCodeNew.sendKeys(commonProperties.getProperty("common.partnerRoomCodeNew"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.saveRoomNew);
		channelContainer.saveRoomNew.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.roomTypeMappingEdit0);
		channelContainer.roomTypeMappingEdit0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.roomTypeCancel0);
		channelContainer.roomTypeCancel0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.roomTypeMappingEdit0);
		channelContainer.roomTypeMappingEdit0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.roomType0);
		channelContainer.roomType0.clear();
		Util.waitTimeElementVisibility(channelContainer.roomType0);
		channelContainer.roomType0.sendKeys(channelProperties.getProperty("channel.roomType0"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.partnerRoomType0);
		channelContainer.partnerRoomType0.clear();
		channelContainer.partnerRoomType0.sendKeys(channelProperties.getProperty("channel.partnerRoomType0"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.roomTypeSave0);
		channelContainer.roomTypeSave0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.deleteRoomType1);
		channelContainer.deleteRoomType1.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		BrowserDriver.getCurrentDriver().switchTo().alert().accept();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	
	public static void reservationTypeMappingEditAddDelete(){
		Util.waitTimeElementVisibility(channelContainer.addNewReservation);
		channelContainer.addNewReservation.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.cancelReservationNew);
		channelContainer.cancelReservationNew.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.addNewReservation);
		channelContainer.addNewReservation.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.saveReservationNew);
		channelContainer.saveReservationNew.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.clickAlertOk);
		channelContainer.clickAlertOk.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.reservationTypeNew);
		channelContainer.reservationTypeNew.sendKeys(channelProperties.getProperty("channel.reservationTypeNew"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.selectReservationTypeNew);
		channelContainer.selectReservationTypeNew.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.partnerReservationCodeNew);
		channelContainer.partnerReservationCodeNew.sendKeys(channelProperties.getProperty("channel.partnerReservationCodeNew"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.saveReservationNew);
		channelContainer.saveReservationNew.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.reservationMappingEdit0);
		channelContainer.reservationMappingEdit0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.reservationCancel0);
		channelContainer.reservationCancel0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.reservationMappingEdit0);
		channelContainer.reservationMappingEdit0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.reservationType0);
		channelContainer.reservationType0.clear();
		channelContainer.reservationType0.sendKeys(channelProperties.getProperty("channel.reservationType0"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.partnerReservationCode0);
		channelContainer.partnerReservationCode0.clear();
		channelContainer.partnerReservationCode0.sendKeys(channelProperties.getProperty("channel.partnerReservationCode0"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.reservationSave0);
		channelContainer.reservationSave0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.deleteReservation1);
		channelContainer.deleteReservation1.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		BrowserDriver.getCurrentDriver().switchTo().alert().accept();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	
	public static void specialRequestMappingEditAddDelete(){
		Util.waitTimeElementVisibility(channelContainer.addNewSpecialRequest);
		channelContainer.addNewSpecialRequest.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.cancelSpecialRequestNew);
		channelContainer.cancelSpecialRequestNew.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.addNewSpecialRequest);
		channelContainer.addNewSpecialRequest.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.saveSpecialRequestNew);
		channelContainer.saveSpecialRequestNew.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.clickAlertOk);
		channelContainer.clickAlertOk.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.specialReqCodeNew);
		channelContainer.specialReqCodeNew.sendKeys(channelProperties.getProperty("channel.specialReqCodeNew"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.selectspecialReqCodeNew);
		channelContainer.selectspecialReqCodeNew.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.partnerSpecialReqCodeNew);
		channelContainer.partnerSpecialReqCodeNew.sendKeys(channelProperties.getProperty("channel.partnerSpecialReqCodeNew"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.saveSpecialRequestNew);
		channelContainer.saveSpecialRequestNew.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.requestMappingEdit0);
		channelContainer.requestMappingEdit0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.requestCancel0);
		channelContainer.requestCancel0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.requestMappingEdit0);
		channelContainer.requestMappingEdit0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.requestCode0);
		channelContainer.requestCode0.clear();
		Util.waitTimeElementVisibility(channelContainer.requestCode0);
		channelContainer.requestCode0.sendKeys(channelProperties.getProperty("channel.requestCode0"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.partnerRequestCode0);
		channelContainer.partnerRequestCode0.clear();
		Util.waitTimeElementVisibility(channelContainer.partnerRequestCode0);
		channelContainer.partnerRequestCode0.sendKeys(channelProperties.getProperty("channel.partnerRequestCode0"));
	/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.requestSave0);
		channelContainer.requestSave0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.deleteRequest1);
		channelContainer.deleteRequest1.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		BrowserDriver.getCurrentDriver().switchTo().alert().accept();
		try {
			Thread.sleep(7000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	
	public static void paymentTypeMappingEditAddDelete(){
		
		try
		{
			Thread.sleep(2000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Util.waitTimeElementVisibility(channelContainer.addNewPaymentType);
		channelContainer.addNewPaymentType.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.cancelPaymentTypeNew);
		channelContainer.cancelPaymentTypeNew.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.addNewPaymentType);
		channelContainer.addNewPaymentType.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.savePaymentTypeNew);
		channelContainer.savePaymentTypeNew.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.clickAlertOk);
		channelContainer.clickAlertOk.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.paymentTypeCodeNewDropDown);
		channelContainer.paymentTypeCodeNewDropDown.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.selectPaymentTypeCodeNew);
		channelContainer.selectPaymentTypeCodeNew.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.partnerPaymentTypeCodeNew);
		channelContainer.partnerPaymentTypeCodeNew.sendKeys(channelProperties.getProperty("channel.partnerPaymentTypeCodeNew"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.savePaymentTypeNew);
		channelContainer.savePaymentTypeNew.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.paymentTypeEdit0);
		channelContainer.paymentTypeEdit0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.paymentTypeCancel0);
		channelContainer.paymentTypeCancel0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.paymentTypeEdit0);
		channelContainer.paymentTypeEdit0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.paymentTypeCode0DropDown);
		channelContainer.paymentTypeCode0DropDown.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.selectPaymentTypeCode0);
		channelContainer.selectPaymentTypeCode0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		
		channelContainer.partnerPaymentTypeCode0.clear();
		Util.waitTimeElementVisibility(channelContainer.partnerPaymentTypeCode0);
		channelContainer.partnerPaymentTypeCode0.sendKeys(channelProperties.getProperty("channel.partnerPaymentTypeCode0"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.paymentTypetSave0);
		channelContainer.paymentTypetSave0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.deletePaymentType1);
		channelContainer.deletePaymentType1.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		BrowserDriver.getCurrentDriver().switchTo().alert().accept();
		try {
			Thread.sleep(7000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	public static void channelKey(){
		Util.waitTimeElementVisibility(channelContainer.channelKeyDropDown);
		channelContainer.channelKeyDropDown.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	
	public static void fetchValueDropdown(){
		
		String channelKey=channelProperties.getProperty("channel.partnerChannelKeyFilter");
		CommonUtils.fetchValueFromDropdown(Constants.EXTERNAL_CHANNEL_KEY_XPATH, channelKey);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public static void propertyName(){
		Util.waitTimeElementVisibility(channelContainer.propertyNameDropDown);
		channelContainer.propertyNameDropDown.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(channelContainer.selectPropertyName);
		channelContainer.selectPropertyName.click();
	/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	
	public static void ratePlanMappingEditAddDelete(){
			try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
	
			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(channelContainer.addNewRateCode);
		channelContainer.addNewRateCode.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(channelContainer.cancelRateCodeNew);
		channelContainer.cancelRateCodeNew.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(channelContainer.addNewRateCode);
		channelContainer.addNewRateCode.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(channelContainer.programIdNew);
		channelContainer.programIdNew.sendKeys("cucumber");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(channelContainer.selectProgramIdNew);
		channelContainer.selectProgramIdNew.click();
	    try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(channelContainer.partnerRateCodeNew);
		channelContainer.partnerRateCodeNew.clear();
		channelContainer.partnerRateCodeNew.sendKeys(channelProperties.getProperty("channel.partnerRateCodeNew"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.saveRateCodeNew);
		channelContainer.saveRateCodeNew.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
//		Util.waitTimeElementVisibility(channelContainer.clickAlertOk);
//		channelContainer.clickAlertOk.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
//		Util.waitTimeElementVisibility(channelContainer.partnerRateCodeNew);
//		channelContainer.partnerRateCodeNew.sendKeys(channelProperties.getProperty("channel.partnerRateCodeNew"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
//		Util.waitTimeElementVisibility(channelContainer.saveRateCodeNew);
//		channelContainer.saveRateCodeNew.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		/*channelContainer.ratePlanEdit0.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		channelContainer.ratePlanCancel0.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		channelContainer.ratePlanEdit0.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		channelContainer.programName0.clear();
		channelContainer.programName0.sendKeys(channelProperties.getProperty("channel.programName0"));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		channelContainer.selectProgramName0.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		channelContainer.partnerRatePlanCode0.clear();
		channelContainer.partnerRatePlanCode0.sendKeys(channelProperties.getProperty("channel.partnerRatePlanCode0"));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		channelContainer.ratePlanSave0.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(channelContainer.deleteRatePlan1);
		channelContainer.deleteRatePlan1.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		BrowserDriver.getCurrentDriver().switchTo().alert().accept();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}		
	}
	
	public static void saveChannelMapping(){
		
		try {
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(channelContainer.saveChannelMapping);
			int intTest = bd.findElements(By.id("layoutForm:btnSave")).size();
			Assert.assertTrue("Failed, Save Channel Mapping is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Save Channel Mapping is present",channelContainer.saveChannelMapping.isDisplayed());
			channelContainer.saveChannelMapping.click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void deleteChannel(){
		Util.waitTimeElementVisibility(channelContainer.deleteChannel);
		channelContainer.deleteChannel.click();
		try {
			Thread.sleep(25000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	
	}

	public static void checkIfPartnerChannelAlreadyExists() {
		try{
			WebElement select = BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:channelDataTable_data']/tr"));
			List<WebElement> options = select.findElements(By.tagName("td"));
	        if(options.size()>1)
	        {
	        	MystiqueChannelView.deleteChannel();
	    		MystiqueChannelView.confirmAlertMessage();	 
							
	        }	
		}catch(Exception e){
			e.printStackTrace();
		}	
	}
	
	public static void selectFieldWithDeviations(){
		Util.waitTimeElementVisibility(channelContainer.PCS_Aurora_Deviation);
		channelContainer.PCS_Aurora_Deviation.click();
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	
	}
	
	public static void selectFieldWithoutDeviations(){
		Util.waitTimeElementVisibility(channelContainer.no_PCS_Aurora_Deviation);
		channelContainer.no_PCS_Aurora_Deviation.click();
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	
	}
	
	public static void checkIfDeviationsExist(){
		Util.waitTimeElementVisibility(channelContainer.PCS_Aurora_Deviation);
		String text=channelContainer.PCS_Aurora_Deviation.getText();
		String[] Stream=text.split("\\|");
		LOGGER.info("The data recieved from Aurora="+ Stream[0]);
		LOGGER.info("The data recieved from PCS="+ Stream[1]);
		Assert.assertNotEquals("Test FAILED-Data from PCS and Aurora matches",Stream[0],Stream[1]);
		LOGGER.info("Test PASSED-Deviations exist in data from PCS and Aurora");
	}
	
	
	public static void checkIfDeviationsDontExist(){
		Util.waitTimeElementVisibility(channelContainer.no_PCS_Aurora_Deviation);
		String text=channelContainer.no_PCS_Aurora_Deviation.getText();
		String[] Stream=text.split("\\|");
		LOGGER.info("The data recieved from Aurora="+ Stream[0]);
		LOGGER.info("The data recieved from PCS="+ Stream[1]);
		Assert.assertEquals("Test FAILED-Data from PCS and Aurora don't match",Stream[0],Stream[1]);
		LOGGER.info("Test PASSED-Deviations don't exist in data from PCS and Aurora");
	}
	
	public static int toHex(Color col)
	{
		String as = pad(Integer.toHexString(col.getAlpha()));
		String rs = pad(Integer.toHexString(col.getRed()));
		String gs = pad(Integer.toHexString(col.getGreen()));
		String bs = pad(Integer.toHexString(col.getBlue()));
		String hex="0x" + as + rs + gs + bs;
		return Integer.parseInt(hex, 16);
		
	}
	
	public static String pad(String s)
	{
	return (s.length()==1)? "0" +s:s;	
	}
	
	
	public static void partnerRateSync() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	
		Util.waitTimeElementVisibility(channelContainer.partnerRateSync);
		channelContainer.partnerRateSync.click();
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	
		
	}

	public static void setDateRange() {
		try
		{
			Thread.sleep(2000);
			Util.waitTimeElementVisibility(channelContainer.fromdate_input);
			channelContainer.fromdate_input.sendKeys("03/18/2015");
			Util.waitTimeElementVisibility(channelContainer.todate_input);
			for (int i = 0; i < 10;i++) {
				channelContainer.todate_input.sendKeys(Keys.BACK_SPACE);
				}
			Thread.sleep(2000);
			channelContainer.todate_input.sendKeys("03/31/2015");
			
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		
	}

	public static void checkCheckboxes() {
		try
		{
			Thread.sleep(2000);
			Util.waitTimeElementVisibility(channelContainer.rateCheckbox);
			channelContainer.rateCheckbox.click();
			Util.waitTimeElementVisibility(channelContainer.restrictionsCheckbox);
			channelContainer.restrictionsCheckbox.click();
			
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		
	}

	public static void clickOnSyncButton() {
		Util.waitTimeElementVisibility(channelContainer.syncButton);
		channelContainer.syncButton.click();
		try
		{
			Thread.sleep(5000);
		}
		catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		Util.waitTimeElementVisibility(channelContainer.syncAlertButton);
		channelContainer.syncAlertButton.click();
		try
		{
			Thread.sleep(5000);
		}
		catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
}


