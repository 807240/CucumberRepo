package com.mystique.view;

import java.util.logging.Logger;

import org.openqa.selenium.support.PageFactory;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.LoginContainer;


public class LoginView {
	private static final Logger LOGGER = Logger.getLogger(LoginView.class.getName());
	private static final LoginContainer loginContainer = PageFactory.initElements(BrowserDriver.getCurrentDriver(), LoginContainer.class);
	public static void isDisplayedCheck(){
		LOGGER.info("Checking login page is displayed");
	}
	public static void login(String username, String password){
		LOGGER.info("Logging in with username:" + username);
		loginContainer.usernameInput.sendKeys(username);
		loginContainer.passwordInput.sendKeys(password);
		loginContainer.submitButton.click();
		LOGGER.info("Login submitted");
	}

}
