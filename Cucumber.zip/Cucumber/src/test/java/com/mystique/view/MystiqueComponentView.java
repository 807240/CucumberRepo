package com.mystique.view;

import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.MystiqueComponentContainer;
import com.mystique.containers.MystiqueDashboardContainer;
import com.mystique.containers.MystiqueRoomContainer;
import com.mystique.utils.CommonUtils;
import com.mystique.utils.Constants;

public class MystiqueComponentView {
	
	private static final Logger LOGGER = Logger.getLogger(MystiqueComponentView.class.getName());
	
	private static final MystiqueComponentContainer componentContainer = PageFactory.initElements(BrowserDriver.getCurrentDriver(),MystiqueComponentContainer.class);
	
	public static final Properties componentProperties = CommonUtils.getConfigPath(Constants.COMPONENT_PATH);

	static WebDriver bd = BrowserDriver.getCurrentDriver();
	static JavascriptExecutor executor = (JavascriptExecutor) bd;
	static CommonUtils Util=new CommonUtils();
	
	public static void selectComponentTab() {
		LOGGER.info("Inside select component:");
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Actions action = new Actions(BrowserDriver.getCurrentDriver());
		WebElement we =BrowserDriver.getCurrentDriver().findElement(By.xpath("(//span[@class='ui-menuitem-text' and contains(text(),'Components')])[1]"));
		//*[@id="layoutForm:menuBar"]/ul/li[4]/a/span[2]
		Util.waitTimeElementVisibility(we);
		action.moveToElement(we).build().perform();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		try {
			Util.waitTimeElementVisibility(componentContainer.manageComponentTab);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:manageComponents']")).size();
			Assert.assertTrue("Failed, Manage Rooms Tab is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Manage Rooms Tab is present",roomContainer.manageRoomsTab.isDisplayed());
			componentContainer.manageComponentTab.click();
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
	
	public static void filterComponent() {
		
		try {
			Util.waitTimeElementVisibility(componentContainer.filterComponentInput);
			componentContainer.filterComponentInput.clear();
			Util.waitTimeElementVisibility(componentContainer.filterComponentInput);
			componentContainer.filterComponentInput.sendKeys(componentProperties.getProperty(Constants.FILTER_COMPONENT_NAME));
			LOGGER.info("filtered in component:");
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void clickOnEditLink() {
		try {
			Util.waitTimeElementVisibility(componentContainer.editLink);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:componentTable:0:editButton']")).size();
			Assert.assertTrue("Failed, Edit Link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Edit Link is present",roomContainer.editLink.isDisplayed());
			componentContainer.editLink.click();
			LOGGER.info("Clicked on Edit component:");
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
	
	public static void clickOnActiveFlag(){
		try {
			Thread.sleep(2000);
			Util.waitTimeElementVisibility(componentContainer.isActive_checkbox);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:activeFlag']/div[2]")).size();
			Assert.assertTrue("Failed, active checkbox not present",intTest > 0);
			
			boolean componentActive = componentContainer.isActive_checkbox.isSelected();
			if(componentActive == false){
				componentContainer.isActive_checkbox.click();
			}
			LOGGER.info("Clicked on activeflag");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void populateLearnMoreDescription() {
		
//		BrowserDriver.getCurrentDriver().switchTo().frame(BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:learnMoreDescription_iframe']")));
//		((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML=''");
		Util.waitTimeElementVisibility(componentContainer.showSource);
		componentContainer.showSource.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		componentContainer.textareaLearnMoreDescription.clear();
		componentContainer.textareaLearnMoreDescription.sendKeys("learnMoreDescription test cucumber");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		componentContainer.showSource.click();
//		((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML='learnMoreDescription test cucumber'");
//		BrowserDriver.getCurrentDriver().switchTo().defaultContent();
		
	}
	
	public static void populateShortDescription() {
		
		Util.waitTimeElementVisibility(componentContainer.shortDescriptionComponent);
		componentContainer.shortDescriptionComponent.clear();
		componentContainer.shortDescriptionComponent.sendKeys("test cucumber");
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void clickOnAvailableIce(){
		try {
			Util.waitTimeElementVisibility(componentContainer.isAvailableInICE);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:availableInIce']/div[2]")).size();
			Assert.assertTrue("Failed, Show in ICE checkbox not present",intTest > 0);
			
			boolean componentActive = componentContainer.isAvailableInICE.isSelected();
			if(componentActive == false){
				executor.executeScript("arguments[0].click()", componentContainer.isAvailableInICE);
			}
			Thread.sleep(3000);
			LOGGER.info("Clicked on AvailableInICE");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void clickSaveComponentButton() {
		
		try {
			Thread.sleep(5000);
			((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("window.scrollTo(0, document.body.scrollHeight)");
			Util.waitTimeElementVisibility(componentContainer.saveComponentBtn);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:saveButton']")).size();
			Assert.assertTrue("Failed, Save button is not present",intTest > 0);
			
			LOGGER.info("clicking on the save button on Component page");
			componentContainer.saveComponentBtn.click();
			Thread.sleep(5000);
			
			Util.waitTimeElementVisibility(componentContainer.saveDialogbox);
			int savetest = bd.findElements(By.xpath("//*[@id=\"layoutForm:messages_container\"]")).size();
			Assert.assertTrue("Failed, Save button is not present",savetest > 0);
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}




	
	
	
