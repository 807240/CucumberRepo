package com.mystique.view;

import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.MystiqueRoomContainer;
import com.mystique.roomsteps.RoomDualPropertyMasterSecondaryMapping;
import com.mystique.utils.CommonUtils;
import com.mystique.utils.Constants;

public class MystiqueRoomView {

	private static final Logger LOGGER = Logger.getLogger(MystiqueRoomView.class.getName());
	
	private static final MystiqueRoomContainer roomContainer = PageFactory.initElements(BrowserDriver.getCurrentDriver(), MystiqueRoomContainer.class);
	
	public static final Properties roomProperties = CommonUtils.getConfigPath(Constants.ROOM_PATH);

	static WebDriver bd = BrowserDriver.getCurrentDriver();
	static JavascriptExecutor executor = (JavascriptExecutor) bd;
	static CommonUtils Util=new CommonUtils();
	
	public static void selectRoomTab() {
		LOGGER.info("Inside select Rooms:");
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Actions action = new Actions(BrowserDriver.getCurrentDriver());
		WebElement we =BrowserDriver.getCurrentDriver().findElement(By.xpath("(//span[@class='ui-menuitem-text' and contains(text(),'Rooms')])[1]"));
		Util.waitTimeElementVisibility(we);
		action.moveToElement(we).build().perform();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		try {
			Util.waitTimeElementVisibility(roomContainer.manageRoomsTab);
			int intTest = bd.findElements(By.id("layoutForm:manageRoom")).size();
			Assert.assertTrue("Failed, Manage Rooms Tab is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Manage Rooms Tab is present",roomContainer.manageRoomsTab.isDisplayed());
			roomContainer.manageRoomsTab.click();
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

	public static void filterRoom() {
		
		try {
			Util.waitTimeElementVisibility(roomContainer.filterRoomInput);
			roomContainer.filterRoomInput.clear();
			Util.waitTimeElementVisibility(roomContainer.filterRoomInput);
			roomContainer.filterRoomInput.sendKeys(roomProperties.getProperty(Constants.FILTER_ROOM_NAME));
			//Assert.assertEquals(roomContainer.filterRoomResult.getText(),roomProperties.getProperty(Constants.FILTER_ROOM_NAME));
			Thread.sleep(20000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void filterRoomByStatusAndAssociationType() {
		Util.waitTimeElementVisibility(roomContainer.filterRoomStatus);
		Select statusSelect= new Select(roomContainer.filterRoomStatus);
		statusSelect.selectByVisibleText("Disable");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Select associationType=new Select(roomContainer.filterAssociationStatus);
		associationType.selectByVisibleText("NONE");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		RoomDualPropertyMasterSecondaryMapping.room_name= bd.findElement(By.xpath("//*[@id='layoutForm:dataTable_data']/tr[1]/td[1]")).getText();
	}
	
	public static void clickOnEditLink() {
		
		try {
			Util.waitTimeElementVisibility(roomContainer.editLink);
			int intTest = bd.findElements(By.id("layoutForm:dataTable:0:editButton")).size();
			Assert.assertTrue("Failed, Edit Link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Edit Link is present",roomContainer.editLink.isDisplayed());
			roomContainer.editLink.click();
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("Clicked on Edit room:");
	}
	
	public static void ChangeRoomStatusActive() {
		try {
			Thread.sleep(10000);
			Util.waitTimeElementVisibility(roomContainer.changeActive);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:activeFlag']/tbody/tr/td[1]/div/div[2]")).size();
			Assert.assertTrue("Failed, Change Active element is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Change Active element is present",roomContainer.changeActive.isDisplayed());
			roomContainer.changeActive.click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		/*try {
			Thread.sleep(30000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		LOGGER.info("Changed Room Status to ACtive");
	}
	
	public static void ChangeRoomStatusInactive() {
		
		try {
			Util.waitTimeElementVisibility(roomContainer.changeInactive);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:activeFlag']/tbody/tr/td[3]/div/div[2]")).size();
			Assert.assertTrue("Failed, Change Inactive element is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Change Inactive element is present",roomContainer.changeInactive.isDisplayed());
			roomContainer.changeInactive.click();
			Thread.sleep(30000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("Changed Room Status to Inactive");
	}
	
	public static void ClickNextRoomEdit() {
		Util.waitTimeElementVisibility(roomContainer.clickNext);
		roomContainer.clickNext.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("On the Deafult Spread page");
	}

	public static void validateRoomListPage() {
		String roomListTitle = roomContainer.roomLibrary.getText();
		if ("Room Library".equalsIgnoreCase(roomListTitle)) {
			LOGGER.info("Room List Page loaded properly");
		} else {
			LOGGER.info("Room List Page not loaded properly");
		}

	}

	
	/*
	 * Valid Room Page Values
	 */
	public static void populateRoomData() {
		/*Util.waitTimeElementVisibility(roomContainer.expandAll);
		roomContainer.expandAll.click();*/
		
		
		
		Util.waitTimeElementVisibility(roomContainer.isActive);
		roomContainer.isActive.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		/*roomContainer.roomShortDescription.sendKeys("Short Description");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		roomContainer.roomLongDescription.sendKeys("Long description");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		/*roomContainer.selectAttribute.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		roomContainer.activateAttribute.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		/*Util.waitTimeElementVisibility(roomContainer.connectedRoomDropDown);
		roomContainer.connectedRoomDropDown.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(roomContainer.selectConnetedRoom);
		roomContainer.selectConnetedRoom.click();*/
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(roomContainer.collapseProgram);
		roomContainer.collapseProgram.click();
		
		Util.waitTimeElementVisibility(roomContainer.collapseChannel);
		roomContainer.collapseChannel.click();
		
		Util.waitTimeElementVisibility(roomContainer.collapseRoomConfig);
		roomContainer.collapseRoomConfig.click();
		
		Util.waitTimeElementVisibility(roomContainer.collapseBasicSetting);
		roomContainer.collapseBasicSetting.click();
		
		Util.waitTimeElementVisibility(roomContainer.collapseRateSetting);
		roomContainer.collapseRateSetting.click();
		
		Util.waitTimeElementVisibility(roomContainer.collapseFeeTable);
		roomContainer.collapseFeeTable.click();
		/*roomContainer.selectProgram.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		roomContainer.activateProgram.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		roomContainer.selectChannel.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		roomContainer.activateChannel.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.rateFloor);
		roomContainer.rateFloor.clear();
		
		Util.waitTimeElementVisibility(roomContainer.rateFloor);
		roomContainer.rateFloor.sendKeys(roomProperties.getProperty(Constants.ROOM_RATE_FLOOR));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.rateCeiling);
		roomContainer.rateCeiling.clear();
		Util.waitTimeElementVisibility(roomContainer.rateCeiling);
		roomContainer.rateCeiling.sendKeys(roomProperties.getProperty(Constants.ROOM_RATE_CEILING));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.extraGuestCharge);
		roomContainer.extraGuestCharge.clear();
		roomContainer.extraGuestCharge.sendKeys(roomProperties.getProperty(Constants.ROOM_EXTRA_GUEST_CHARGE));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.extraGuestChangeThreshold);
		roomContainer.extraGuestChangeThreshold.clear();
		Util.waitTimeElementVisibility(roomContainer.extraGuestChangeThreshold);
		roomContainer.extraGuestChangeThreshold.sendKeys(roomProperties.getProperty(Constants.ROOM_EXTRA_GUEST_CHARGE_THRESHOLD));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.resortFee);
		roomContainer.resortFee.clear();
		Util.waitTimeElementVisibility(roomContainer.resortFee);
		roomContainer.resortFee.sendKeys(roomProperties.getProperty(Constants.ROOM_RESORT_FEE));
		try {
			Thread.sleep(8000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}
	
	public static void addDefaultRateSpread() {
		roomContainer.addSeason0.click();
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void addAnotherDefaultRateSpread() {
		Util.waitTimeElementVisibility(roomContainer.addAnotherSeason);
		roomContainer.addAnotherSeason.click();
		/*try {
			Thread.sleep(30000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}

	public static void defaultRateSpreadData() {
		Util.waitTimeElementVisibility(roomContainer.seasonStartDate0);
		roomContainer.seasonStartDate0.clear();
		Util.waitTimeElementVisibility(roomContainer.seasonStartDate0);
		roomContainer.seasonStartDate0.sendKeys(roomProperties.getProperty(Constants.ROOM_SEASON_START_DATE_0));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.seasonStartDate0);
		roomContainer.seasonEndDate0.clear();
		Util.waitTimeElementVisibility(roomContainer.seasonStartDate0);
		roomContainer.seasonEndDate0.sendKeys(roomProperties.getProperty(Constants.ROOM_SEASON_END_DATE_0));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.selectRadioAmt0);
		roomContainer.selectRadioAmt0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.amountValue0);
		roomContainer.amountValue0.clear();
		Util.waitTimeElementVisibility(roomContainer.amountValue0);
		roomContainer.amountValue0.sendKeys(roomProperties.getProperty(Constants.ROOM_AMOUNT_VALUE_0));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/

	}

	public static void clickSaveRoomButton() {
		
		try {
			Util.waitTimeElementVisibility(roomContainer.saveButton);
			int intTest = bd.findElements(By.id("layoutForm:submitButton")).size();
			Assert.assertTrue("Failed, Save Button is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Save Button is present",roomContainer.saveButton.isDisplayed());
			executor.executeScript("arguments[0].click()", roomContainer.saveButton);
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	
	/*
	 * Rooms validation scenarios  
	 */
	public static void selectRoomTabAfterDeletion() {
		LOGGER.info("Inside select Rooms:");
		
		Actions action = new Actions(BrowserDriver.getCurrentDriver());
		WebElement we = BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:menuPanel']/div/ul/li[3]/a/span[2]"));
		action.moveToElement(we).build().perform();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}
	
	public static void clickNextOnRoomConfigPage() {
		
		try {
			((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("window.scrollTo(0, document.body.scrollHeight)");
			Util.waitTimeElementVisibility(roomContainer.roomNextButton);
			int intTest = bd.findElements(By.id("layoutForm:next")).size();
			Assert.assertTrue("Failed, Room Next Button is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Room Next Button is present",roomContainer.roomNextButton.isDisplayed());
			roomContainer.roomNextButton.click();
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	/*
	 * Room Activation Scenario
	 */
	public static void shortDescriptionMandatoryClear() {
		
		BrowserDriver.getCurrentDriver().switchTo().frame(BrowserDriver.getCurrentDriver().findElement(By.id("layoutForm:shortDescription_iframe")));
		((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML='test auto'");
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		BrowserDriver.getCurrentDriver().switchTo().defaultContent();
     }
	
	public static void shortDescriptionMandatory() {
		
		BrowserDriver.getCurrentDriver().switchTo().frame(BrowserDriver.getCurrentDriver().findElement(By.id("layoutForm:shortDescription_iframe"))); //any locator
	    ((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML='"+ roomProperties.getProperty(Constants.ROOM_SHORT_DESCRIPTION) +"'");
	    
	    try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	    
	    BrowserDriver.getCurrentDriver().switchTo().defaultContent();
		
	}
	
	public static void clickNextButton() {
		roomContainer.clickNext.click();	
	}
	
	public static void clickSubmitButton() {
		try {
			int intTest = bd.findElements(By.id("layoutForm:submitButton")).size();
			Assert.assertTrue("Failed, Submit button is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Submit button is present",roomContainer.clickSubmit.isDisplayed());
			roomContainer.clickSubmit.click();	
			Thread.sleep(1000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	
	
	public static void longDescriptionMandatoryClear() {
		
		BrowserDriver.getCurrentDriver().switchTo().frame("layoutForm:description_iframe");
		((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML='©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™ ©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™ ©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™ ©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™ ©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™ ©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™ ©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™'");
		//roomContainer.roomLongDescription.clear();
		try {
			Thread.sleep(25000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		BrowserDriver.getCurrentDriver().switchTo().defaultContent();
		
	}
	public static void longDescriptionMandatory() {
		/*BrowserDriver.getCurrentDriver().switchTo().frame(BrowserDriver.getCurrentDriver().findElement(By.id("layoutForm:description_iframe"))); //any locator
	    ((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML='Long Description'");*/
		
		BrowserDriver.getCurrentDriver().switchTo().frame("layoutForm:description_iframe"); //any locator
	    ((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML='"+ roomProperties.getProperty(Constants.ROOM_LONG_DESCRIPTION) +"'");
	    
	   // BrowserDriver.getCurrentDriver().switchTo().defaultContent();
		//BrowserDriver.getCurrentDriver().switchTo().frame(roomContainer.roomLongDescription);
		//roomContainer.roomLongDescription.sendKeys("Long description");
		try {
			Thread.sleep(25000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		BrowserDriver.getCurrentDriver().switchTo().defaultContent();
		/*roomContainer.roomLongDescription.clear();
		roomContainer.roomLongDescription.sendKeys("Long description");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	public static void agentSendToCustomerTextClear() {
		
		BrowserDriver.getCurrentDriver().switchTo().frame("layoutForm:agentSendToCustomerText_iframe"); //any locator
	    ((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML='©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™ ©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™ ©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™ ©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™ ©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™ ©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™ ©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™'");
	    
		try {
			Thread.sleep(25000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		BrowserDriver.getCurrentDriver().switchTo().defaultContent();
	}
	public static void agentSendToCustomerTextMandatory() {
		
		BrowserDriver.getCurrentDriver().switchTo().frame("layoutForm:agentSendToCustomerText_iframe"); //any locator
	    ((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML='customer text feild mandatory successful'");
		
		try {
			Thread.sleep(25000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	/*
	 * Day Coverage validation on Default Rate Spread 
	 */
	public static void daysWithoutDayCoverage() {
		Util.waitTimeElementVisibility(roomContainer.seasonStartDate0);
		roomContainer.seasonStartDate0.clear();
		Util.waitTimeElementVisibility(roomContainer.seasonStartDate0);
		roomContainer.seasonStartDate0.sendKeys(roomProperties.getProperty(Constants.ROOM_SEASON_START_DATE_0));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.seasonEndDate0);
		roomContainer.seasonEndDate0.clear();
		Util.waitTimeElementVisibility(roomContainer.seasonEndDate0);
		roomContainer.seasonEndDate0.sendKeys(roomProperties.getProperty(Constants.ROOM_SEASON_END_DATE_0));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		roomContainer.selectSunday0.click();
		roomContainer.selectTuesday0.click();
		roomContainer.selectThursday0.click();
		roomContainer.selectFriday0.click();
		roomContainer.selectSaturday0.click();

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		//Util.waitTimeElementVisibility(roomContainer.selectRadioAmt0);
		Actions radio_click= new Actions(bd);
		/*radio_click.moveToElement(roomContainer.selectRadioAmt0).sendKeys(Keys.SPACE).build().perform();*/
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		radio_click.moveToElement(roomContainer.selectRadioAmt0).click().build().perform();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.amountValue0);
		roomContainer.amountValue0.clear();
		Util.waitTimeElementVisibility(roomContainer.amountValue0);
		roomContainer.amountValue0.sendKeys(roomProperties.getProperty(Constants.ROOM_AMOUNT_VALUE_0));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/

	}
	public static void dateRangeWithoutDayCoverage() {
		Util.waitTimeElementVisibility(roomContainer.seasonStartDate0);
		roomContainer.seasonStartDate0.clear();
		Util.waitTimeElementVisibility(roomContainer.seasonStartDate0);
		roomContainer.seasonStartDate0.sendKeys(roomProperties.getProperty(Constants.ROOM_SEASON_START_DATE_1));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.seasonEndDate0);
		roomContainer.seasonEndDate0.clear();
		Util.waitTimeElementVisibility(roomContainer.seasonEndDate0);
		roomContainer.seasonEndDate0.sendKeys(roomProperties.getProperty(Constants.ROOM_SEASON_END_DATE_1));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		roomContainer.selectSunday0.click();
		roomContainer.selectTuesday0.click();
		roomContainer.selectThursday0.click();
		roomContainer.selectFriday0.click();
		roomContainer.selectSaturday0.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(roomContainer.amountValue0);
		roomContainer.amountValue0.clear();
		Util.waitTimeElementVisibility(roomContainer.amountValue0);
		roomContainer.amountValue0.sendKeys(roomProperties.getProperty(Constants.ROOM_AMOUNT_VALUE_0));
		
		/*roomContainer.selectRadioAmt1.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		roomContainer.amountValue1.sendKeys("63.00");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/		
	}
		
	public static void popUpAlertAccept(){
		//BrowserDriver.getCurrentDriver().switchTo().alert().accept();
		Util.waitTimeElementVisibility(roomContainer.clickAlertOk);
		roomContainer.clickAlertOk.click();
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	public static void popUpAlertDismiss(){
		//BrowserDriver.getCurrentDriver().switchTo().alert().dismiss();
		Util.waitTimeElementVisibility(roomContainer.clickAlertNo);
		roomContainer.clickAlertNo.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	public static void popUpAlertAcceptMessage(){
		//BrowserDriver.getCurrentDriver().switchTo().alert().accept();
		
		try {
			Util.waitTimeElementVisibility(roomContainer.clickAlertOkMessage);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:alertDialogVal']/div[3]/div/button/span")).size();
			Assert.assertTrue("Failed, Alert Ok Message is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Alert Ok Message is present",roomContainer.clickAlertOkMessage.isDisplayed());
			roomContainer.clickAlertOkMessage.click();
			Thread.sleep(20000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	/*
	 * Default Rate Spread Amount and Base Room Type Validation
	 */
	public static void amountValidation() {
		Util.waitTimeElementVisibility(roomContainer.seasonStartDate0);
		roomContainer.seasonStartDate0.clear();
		Util.waitTimeElementVisibility(roomContainer.seasonStartDate0);
		roomContainer.seasonStartDate0.sendKeys(roomProperties.getProperty(Constants.ROOM_SEASON_START_DATE_0));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.seasonEndDate0);
		roomContainer.seasonEndDate0.clear();
		Util.waitTimeElementVisibility(roomContainer.seasonEndDate0);
		roomContainer.seasonEndDate0.sendKeys(roomProperties.getProperty(Constants.ROOM_SEASON_END_DATE_0));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.selectRadioAmt0);
		roomContainer.selectRadioAmt0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.amountValue0);
		roomContainer.amountValue0.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}		*/
	}
	
	public static void baseRoomTypeValidation() {
		Util.waitTimeElementVisibility(roomContainer.seasonStartDate0);
		roomContainer.seasonStartDate0.clear();
		Util.waitTimeElementVisibility(roomContainer.seasonStartDate0);
		roomContainer.seasonStartDate0.sendKeys(roomProperties.getProperty(Constants.ROOM_SEASON_START_DATE_0));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		roomContainer.seasonEndDate0.clear();
		roomContainer.seasonEndDate0.sendKeys(roomProperties.getProperty(Constants.ROOM_SEASON_END_DATE_0));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		/*roomContainer.selectSunday1.click();
		roomContainer.selectMonday1.click();
		roomContainer.selectTuesday1.click();
		roomContainer.selectWednesday1.click();
		roomContainer.selectThursday1.click();
		roomContainer.selectFriday1.click();
		roomContainer.selectSaturday1.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		roomContainer.selectRadioSpread0.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		roomContainer.selectPercentRadio0.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		roomContainer.percentValue0.clear();
		roomContainer.percentValue0.sendKeys();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}
	
	
	/*
	 * Add Delete Season
	 */
	public static void addSeasonProvideData() {
		Util.waitTimeElementVisibility(roomContainer.seasonStartDate0);
		roomContainer.seasonStartDate0.clear();
		Util.waitTimeElementVisibility(roomContainer.seasonStartDate0);
		roomContainer.seasonStartDate0.sendKeys("01/01");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.seasonEndDate0);
		roomContainer.seasonEndDate0.clear();
		Util.waitTimeElementVisibility(roomContainer.seasonEndDate0);
		roomContainer.seasonEndDate0.sendKeys("06/30");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.selectRadioAmt0);
		roomContainer.selectRadioAmt0.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.amountValue0);
		roomContainer.amountValue0.clear();
		Util.waitTimeElementVisibility(roomContainer.amountValue0);
		roomContainer.amountValue0.sendKeys("13000");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.seasonStartDate1);
		roomContainer.seasonStartDate1.clear();
		roomContainer.seasonStartDate1.sendKeys("07/01");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.seasonEndDate1);
		roomContainer.seasonEndDate1.clear();
		roomContainer.seasonEndDate1.sendKeys("12/31");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		/*roomContainer.selectSunday0.click();
		roomContainer.selectMonday0.click();
		roomContainer.selectTuesday0.click();
		roomContainer.selectWednesday0.click();
		roomContainer.selectThursday0.click();
		roomContainer.selectFriday0.click();
		roomContainer.selectSaturday0.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		/*roomContainer.spreadNameValue1.sendKeys("Summer Season");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		/*roomContainer.selectSunday1.click();
		roomContainer.selectMonday1.click();
		roomContainer.selectTuesday1.click();
		roomContainer.selectWednesday1.click();
		roomContainer.selectThursday1.click();
		roomContainer.selectFriday1.click();
		roomContainer.selectSaturday1.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		
		
		Util.waitTimeElementVisibility(roomContainer.selectRadioSpread1);
		roomContainer.selectRadioSpread1.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.baseRoomTypeDropDown1);
		roomContainer.baseRoomTypeDropDown1.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		
		
		
		
		Util.waitTimeElementVisibility(roomContainer.selectBaseRoomType1);
		roomContainer.selectBaseRoomType1.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.selectPercentRadio1);
		roomContainer.selectPercentRadio1.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.percentValue1);
		roomContainer.percentValue1.clear();
		roomContainer.percentValue1.sendKeys(roomProperties.getProperty(Constants.ROOM_PERCENT_VALUE_1));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		
		
	}
	
	public static void deleteSeason(){
		Util.waitTimeElementVisibility(roomContainer.deleteSeason0);
		roomContainer.deleteSeason0.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	
	}
	
	public static void checkIFSeasonExists(){
		try{
			WebElement select = BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:seasonalSpread1']/table/tbody/tr[5]/td"));
			List<WebElement> options = select.findElements(By.tagName("input"));
	        if(options.size()>1)
	        {
	        	deleteSeason(); 				
	        }	
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	

	
	
	public static void deleteSeason1(){
		Util.waitTimeElementVisibility(roomContainer.deleteSeason1);
		roomContainer.deleteSeason1.click();
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	
	}
	
	public static void addSpread(){
		Util.waitTimeElementVisibility(roomContainer.addSpread);
		roomContainer.addSpread.click();
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	
	}
	
	
	
	public static void saveAfterDeleteData() {
		Util.waitTimeElementVisibility(roomContainer.seasonStartDate0);
		roomContainer.seasonStartDate0.clear();
		Util.waitTimeElementVisibility(roomContainer.seasonStartDate0);
		roomContainer.seasonStartDate0.sendKeys(roomProperties.getProperty(Constants.ROOM_SEASON_START_DATE_0));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(roomContainer.seasonEndDate0);
		roomContainer.seasonEndDate0.clear();
		Util.waitTimeElementVisibility(roomContainer.seasonEndDate0);
		roomContainer.seasonEndDate0.sendKeys(roomProperties.getProperty(Constants.ROOM_SEASON_END_DATE_0));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		
	}
	
	public static void clickOnBack(){
		roomContainer.backButton.click();
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	
	public static void roomSync(){
		
		try {
			Util.waitTimeElementVisibility(roomContainer.syncRoom);
			int intTest = bd.findElements(By.id("layoutForm:syncOperaButton")).size();
			Assert.assertTrue("Failed, Sync Room element is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Sync Room element is present",roomContainer.syncRoom.isDisplayed());
			roomContainer.syncRoom.click();
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void checkThePseudoBox() {
		try {
			WebDriver wd= BrowserDriver.getCurrentDriver();
			roomContainer.editLink.click();
			Thread.sleep(3000);
			boolean isPseudoChkd = wd.findElements(By.xpath("//*[@id='layoutForm:pseudo']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size()>0;
			if(isPseudoChkd)
			{
				Thread.sleep(3000);
				roomContainer.roomNxtButton.click();
			}
			else
			{
				roomContainer.pseudocheckbox.click();
				Thread.sleep(3000);
				roomContainer.roomNxtButton.click();
			}
			Thread.sleep(3000);
			roomContainer.roomSubmitButton.click();
			Thread.sleep(8000);
			boolean isRoomInactive = wd.findElements(By.xpath("//*[@id='layoutForm:j_idt90']/span")).size()>0;
			Assert.assertNotEquals(wd.findElements(By.xpath("//*[@id='layoutForm:j_idt90']/span")).size(),0);
			if(isRoomInactive)
			{
				wd.findElement(By.xpath("//*[@id='layoutForm:j_idt90']/span")).click();
				Thread.sleep(10000);
			}
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void unCheckThePseudoBox() {
		try {
			WebDriver wd= BrowserDriver.getCurrentDriver();
			roomContainer.editLink.click();
			Thread.sleep(3000);
			boolean isPseudoChkd = wd.findElements(By.xpath("//*[@id='layoutForm:pseudo']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size()>0;
			if(isPseudoChkd)
			{
				roomContainer.pseudocheckbox.click();
				Thread.sleep(3000);
				roomContainer.roomNxtButton.click();
				
			}
			else
			{
				Thread.sleep(3000);
				roomContainer.roomNxtButton.click();
			}
			Thread.sleep(3000);
			roomContainer.roomSubmitButton.click();
			Thread.sleep(8000);
			boolean isRoomInactive = wd.findElements(By.xpath("//*[@id='layoutForm:j_idt90']/span")).size()>0;
			Assert.assertNotEquals(wd.findElements(By.xpath("//*[@id='layoutForm:j_idt90']/span")).size(),0);
			if(isRoomInactive)
			{
				wd.findElement(By.xpath("//*[@id='layoutForm:j_idt90']/span")).click();
				Thread.sleep(10000);
			}
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void clickOnActiveFlag(){
		Util.waitTimeElementVisibility(roomContainer.isActive);
		roomContainer.isActive.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		
	}
	
	public static void openRoomFeature() {
		try {
			int intTest = bd.findElements(By.id("layoutForm:dataTable:0:editButton")).size();
			Assert.assertTrue("Failed, Edit Room link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Edit Room link is present",roomContainer.editRoomlink.isDisplayed());
			roomContainer.editRoomlink.click();
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

}
