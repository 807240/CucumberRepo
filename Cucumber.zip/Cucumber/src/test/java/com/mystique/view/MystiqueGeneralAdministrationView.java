package com.mystique.view;

import java.util.ArrayList;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.MystiqueGenAdminContainer;
import com.mystique.generaladministration.UserLibraryListSteps;
import com.mystique.utils.CommonUtils;

public class MystiqueGeneralAdministrationView {
	private static final Logger LOGGER = Logger
			.getLogger(UserLibraryListSteps.class.getName());
	static CommonUtils Util = new CommonUtils();
	
	
	private static final MystiqueGenAdminContainer genAdminContainer = PageFactory
			.initElements(BrowserDriver.getCurrentDriver(),
					MystiqueGenAdminContainer.class);


	static Integer totalcount;
	static Integer activecount;
	static Integer inactivecount;

	BrowserDriver bd = new BrowserDriver();
	static WebDriver wd = BrowserDriver.getCurrentDriver();
	static JavascriptExecutor executor = (JavascriptExecutor) wd; 

	public static int totalUserCalc() {
		try {
			Util.waitTimeElementVisibility( wd.findElement(By.xpath("//*[@id='layoutForm:dataTable_paginator_top']/select")));
			 Select dropdown = new Select(wd.findElement(By.xpath("//*[@id='layoutForm:dataTable_paginator_top']/select")));
			 dropdown.selectByValue("100");
			 System.out.println("Selected 100 per page display mode");
			 Thread.sleep(10000);
			 Select Filter = new Select(wd.findElement(By.xpath("//*[@id='layoutForm:dataTable:userActiveColumn:filter']")));
			 Filter.selectByVisibleText("All");
			 Thread.sleep(5000);
			 //Util.waitTimeElementVisibility( wd.findElement(By.xpath("(//*[@class='ui-icon ui-icon-seek-end'])[1]")));
			// wd.findElement(By.xpath("(//*[@class='ui-icon ui-icon-seek-end'])[1]")).click();
			 executor.executeScript("arguments[0].click()", wd.findElement(By.xpath("(//*[@class='ui-icon ui-icon-seek-end'])[1]")));
			 Thread.sleep(5000);
			 //new WebDriverWait(wd, 60).until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(@id,':editButton')])[1]")));
			 Thread.sleep(10000);
			 String count=wd.findElement(By.xpath( " (//*[@class='ui-paginator-page ui-state-default ui-corner-all ui-state-active'])[1]")).getText();
			 Integer count1=Integer.parseInt(count);
			 //System.out.println(count1-1);
			 totalcount=(count1-1)*100 + wd.findElements(By.xpath("//*[@class='dataTableLinkActive']")).size();
			 //System.out.println(wd.findElements(By.xpath("//*[@class='dataTableLinkActive']")).size());
			 //System.out.println(totalcount);
			 LOGGER.info("Total number of Users="+totalcount);

		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		return totalcount;
	}

	public static int activeUserCalc() {

		try {
			Util.waitTimeElementVisibility(wd.findElement(By
					.xpath("//*[@id='layoutForm:dataTable_paginator_top']/select")));
			Select dropdown = new Select(
					wd.findElement(By
							.xpath("//*[@id='layoutForm:dataTable_paginator_top']/select")));
			dropdown.selectByValue("100");
			System.out.println("Selected 100 per page display mode");
			Thread.sleep(10000);
			Select Filter = new Select(
					wd.findElement(By
							.xpath("//*[@id='layoutForm:dataTable:userActiveColumn:filter']")));
			Filter.selectByVisibleText("Active");
			Thread.sleep(3000);
			// Util.waitTimeElementVisibility(
			// wd.findElement(By.xpath("(//*[@class='ui-icon ui-icon-seek-end'])[1]")));
//			wd.findElement(
//					By.xpath("(//*[@class='ui-icon ui-icon-seek-end'])[1]"))
//					.click();
			executor.executeScript("arguments[0].click()", wd.findElement(
					By.xpath("(//*[@class='ui-icon ui-icon-seek-end'])[1]")));
			Thread.sleep(3000);
			// Util.waitTimeElementVisibility(
			// wd.findElement(By.xpath("(//*[contains(@id,':editButton')])[1]")));
			String countactiv = wd
					.findElement(
							By.xpath("(//*[@class='ui-paginator-page ui-state-default ui-corner-all ui-state-active'])[1]"))
					.getText();
			Integer countactiv1 = Integer.parseInt(countactiv);
			// System.out.println("countactiv1="+countactiv1);
			activecount = (countactiv1 - 1)
					* 100
					+ wd.findElements(
							By.xpath("//*[@class='dataTableLinkActive' and contains(text(),'Active')]"))
							.size();
			// System.out.println("countactiv2="+wd.findElements(By.xpath("//*[@class='dataTableLinkActive' and contains(text(),'Active')]")).size());
			// System.out.println(activecount);
			Assert.assertNotEquals(wd.findElements(By.xpath("//*[@class='dataTableLinkActive' and contains(text(),'Active')]")).size(),0);
			
			LOGGER.info("Total number of Active Users=" + activecount);

		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		return activecount;
	}

	public static int inactiveUserCalc() {

		try {
			Util.waitTimeElementVisibility(wd.findElement(By
					.xpath("//*[@id='layoutForm:dataTable_paginator_top']/select")));
			Select dropdown = new Select(
					wd.findElement(By
							.xpath("//*[@id='layoutForm:dataTable_paginator_top']/select")));
			dropdown.selectByValue("100");
			System.out.println("Selected 100 per page display mode");
			Thread.sleep(10000);
			Select Filter = new Select(
					wd.findElement(By
							.xpath("//*[@id='layoutForm:dataTable:userActiveColumn:filter']")));
			Filter.selectByVisibleText("Inactive");
			Thread.sleep(9000);
			// Util.waitTimeElementVisibility(
			// wd.findElement(By.xpath("(//*[contains(@id,':editButton')])[1]")));
//			wd.findElement(
//					By.xpath("(//*[@class='ui-icon ui-icon-seek-end'])[1]"))
//					.click();
			
			executor.executeScript("arguments[0].click()", wd.findElement(
					By.xpath("(//*[@class='ui-icon ui-icon-seek-end'])[1]")));
			Thread.sleep(9000);
			// new WebDriverWait(wd,
			// 60).until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(@id,':editButton')])[1]")));
			String countinactiv = wd
					.findElement(
							By.xpath(" (//*[@class='ui-paginator-page ui-state-default ui-corner-all ui-state-active'])[1]"))
					.getText();
			Integer countinactiv1 = Integer.parseInt(countinactiv);
			inactivecount = (countinactiv1 - 1)
					* 100
					+ wd.findElements(
							By.xpath("//*[@class='dataTableLinkActive' and contains(text(),'Inactive')]"))
							.size();
			// System.out.println(inactivecount);
			Assert.assertNotEquals(wd.findElements(By.xpath("//*[@class='dataTableLinkActive' and contains(text(),'Inactive')]")).size(),0);
			
			LOGGER.info("Total number of Inactive Users=" + inactivecount);
			Thread.sleep(9000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		return inactivecount;
	}
	
	public static void hoverOnOperaData()
	{
		try {
			Util.waitTimeElementVisibility(genAdminContainer.operaDataHover);
			LOGGER.info("Hovering on Opera Data Menu");
			Actions action = new Actions(wd);
			WebElement we = genAdminContainer.operaDataHover;
			//Hover on Channel menu
			action.moveToElement(we).build().perform();
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}	

	
	public static void selectStaticData()
	{
		try {
			Util.waitTimeElementVisibility(genAdminContainer.operaMenuStaticData);
			genAdminContainer.operaMenuStaticData.click();
			LOGGER.info("Clicked on Static Data sub menu item");
			Thread.sleep(5000);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}	
	
	public static void verifyStaticDataPage()
	{
		try {
			Util.waitTimeElementVisibility(genAdminContainer.operaStaticDataPage);
			Assert.assertTrue("FAIL, Static pages is not displayed",genAdminContainer.operaStaticDataPage.isDisplayed());
			LOGGER.info("PASS,Static data page is displayed");
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	public static void selectDynamicData()
	{
		try {
			Util.waitTimeElementVisibility(genAdminContainer.operaMenuDynamicData);
			
			executor.executeScript("arguments[0].click()", genAdminContainer.operaMenuDynamicData);
			LOGGER.info("Clicked on Dynamic Data sub menu item");
			Thread.sleep(5000);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}	
	
	public static void verifyDynamicDataPage()
	{
		try {
			Util.waitTimeElementVisibility(genAdminContainer.operaDynamicDataPage);
			Assert.assertTrue("FAIL, Dynamic pages is not displayed",genAdminContainer.operaDynamicDataPage.isDisplayed());
			LOGGER.info("PASS,Dynamic data page is displayed");
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}	

//for Alert area code	
	public static void clickOnAlertAreaCode()
	{
		try {
			Util.waitTimeElementVisibility(genAdminContainer.AlertAreaCode);
			executor.executeScript("arguments[0].click()", genAdminContainer.AlertAreaCode);
			//genAdminContainer.AlertAreaCode.click();
			LOGGER.info("Clicked on Alert area codes for Static data");
			Thread.sleep(5000);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}	
	
	
	
public static void selectPropertyforAlertArea() {
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		Util.waitTimeElementVisibility(genAdminContainer.AlertAreaCodePropertydropdown);
		LOGGER.info("Before Clicking on the Property Drop Down for Area Alert Code:");
		//genAdminContainer.AlertAreaCodePropertydropdown.click();
		executor.executeScript("arguments[0].click()", genAdminContainer.AlertAreaCodePropertydropdown);
		Util.waitTimeElementVisibility(genAdminContainer.AlertAreaCodePropertyBellagio);
		//genAdminContainer.AlertAreaCodePropertyBellagio.click();
		executor.executeScript("arguments[0].click()", genAdminContainer.AlertAreaCodePropertyBellagio);
        }	
public static void verifyAlertAreaData() {
	
	try {
		//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertAreaCode);
		Thread.sleep(5000);
		Assert.assertTrue("FAIL, Static page Data is not displayed for Area Alert Code",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Alert Area Codes were found')]")).size()<=0);
		LOGGER.info("Pass,Static page Data is displayed for Area Alert Code");
		
		
	}catch(Exception e){
		e.printStackTrace();
	}
   }


//for alert codes

public static void clickOnAlertCodes()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.AlertCodes);
		//genAdminContainer.AlertCodes.click();
		executor.executeScript("arguments[0].click()", genAdminContainer.AlertCodes);
		LOGGER.info("Clicked on Alert codes for Static data");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void selectPropertyforAlertCodes() {
	
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
	Util.waitTimeElementVisibility(genAdminContainer.AlertCodesPropertydropdown);
	LOGGER.info("Before Clicking on the Property Drop Down for Area Alert Code:");
	executor.executeScript("arguments[0].click()", genAdminContainer.AlertCodesPropertydropdown);
	//genAdminContainer.AlertCodesPropertydropdown.click();
	Util.waitTimeElementVisibility(genAdminContainer.AlertCodesPropertyBellagio);
	executor.executeScript("arguments[0].click()", genAdminContainer.AlertCodesPropertyBellagio);
	//genAdminContainer.AlertCodesPropertyBellagio.click();
    }	
public static void verifyAlertCodesData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Static page Data is not displayed for Alert Codes",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Alert Codes were found')]")).size()<=0);
	LOGGER.info("Pass,Static page Data is displayed for Area Alert Code");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}

//for country codes

public static void clickOnCountryCodestab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.CountryCodes);
		genAdminContainer.CountryCodes.click();
		LOGGER.info("Clicked on Country codes for Static data");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void verifyCountryCodesData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Static page Data is not displayed for Country Code",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Country Codes were found')]")).size()<=0);
	LOGGER.info("Pass,Static page Data is displayed for Country Codes");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}


//for Reservation Types

public static void clickOnRevervationTypestab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.ReservationTypes);
		executor.executeScript("arguments[0].click()", genAdminContainer.ReservationTypes);
		//genAdminContainer.ReservationTypes.click();
		LOGGER.info("Clicked on Reservation Types for Static data");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void selectPropertyforRevervationTypes() {
	
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
	Util.waitTimeElementVisibility(genAdminContainer.ReservationTypesPropertydropdown);
	LOGGER.info("Before Clicking on the Property Drop Down for Reservation Types:");
	//genAdminContainer.ReservationTypesPropertydropdown.click();
	executor.executeScript("arguments[0].click()", genAdminContainer.ReservationTypesPropertydropdown);
	Util.waitTimeElementVisibility(genAdminContainer.ReservationTypesPropertyBellagio);
	//genAdminContainer.ReservationTypesPropertyBellagio.click();
	executor.executeScript("arguments[0].click()", genAdminContainer.ReservationTypesPropertyBellagio);
    }	
public static void verifyReservationTypesData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Static page Data is not displayed for Reservation Types",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Reservation Types were found')]")).size()<=0);
	LOGGER.info("Pass,Static page Data is displayed for Reservation Types Code");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}

//for Deposit Rules

public static void clickOnDepositRulestab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.DepositRules);
		executor.executeScript("arguments[0].click()", genAdminContainer.DepositRules);
		//genAdminContainer.DepositRules.click();
		LOGGER.info("Clicked on Deposit Rules for Static data");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void selectPropertyforDepositRules() {
	
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
	Util.waitTimeElementVisibility(genAdminContainer.DepositRulesPropertydropdown);
	LOGGER.info("Before Clicking on the Property Drop Down for Deposit Rules :");
	executor.executeScript("arguments[0].click()", genAdminContainer.DepositRulesPropertydropdown);
	//genAdminContainer.DepositRulesPropertydropdown.click();
	Util.waitTimeElementVisibility(genAdminContainer.DepositRulesPropertyBellagio);
	executor.executeScript("arguments[0].click()", genAdminContainer.DepositRulesPropertyBellagio);
	//genAdminContainer.DepositRulesPropertyBellagio.click();
  }	
public static void verifyDepositRulesData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Static page Data is not displayed for Deposit Rules ",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Deposit Rules were found')]")).size()<=0);
	LOGGER.info("Pass,Static page Data is displayed for Deposit Rules ");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}

//for Cancellation Rules

public static void clickOnCancellationRulestab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.CancellationRules);
		executor.executeScript("arguments[0].click()", genAdminContainer.CancellationRules);
		//genAdminContainer.CancellationRules.click();
		LOGGER.info("Clicked on Cancellation Rules for Static data");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void selectPropertyforCancellationRules() {
	
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
	Util.waitTimeElementVisibility(genAdminContainer.CancellationRulesPropertydropdown);
	LOGGER.info("Before Clicking on the Property Drop Down for Cancellation Rules :");
	executor.executeScript("arguments[0].click()", genAdminContainer.CancellationRulesPropertydropdown);
	//genAdminContainer.CancellationRulesPropertydropdown.click();
	Util.waitTimeElementVisibility(genAdminContainer.CancellationRulesPropertyBellagio);
	executor.executeScript("arguments[0].click()", genAdminContainer.CancellationRulesPropertyBellagio);
	//genAdminContainer.CancellationRulesPropertyBellagio.click();
}	
public static void verifyCancellationRulesData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Static page Data is not displayed for Cancellation Rules ",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Cancellation Rules were found')]")).size()<=0);
	LOGGER.info("Pass,Static page Data is displayed for Cancellation Rules ");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}

//for Opera Rate Category Rules

public static void clickOnOperaRateCategorytab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.OperaRateCategory);
		executor.executeScript("arguments[0].click()", genAdminContainer.OperaRateCategory);
		//genAdminContainer.OperaRateCategory.click();
		LOGGER.info("Clicked on Opera Rate Category for Static data");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void selectPropertyforOperaRateCategory() {
	
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
	Util.waitTimeElementVisibility(genAdminContainer.OperaRateCategoryPropertydropdown);
	LOGGER.info("Before Clicking on the Property Drop Down for Opera Rate Category:");
	executor.executeScript("arguments[0].click()", genAdminContainer.OperaRateCategoryPropertydropdown);
	//genAdminContainer.OperaRateCategoryPropertydropdown.click();
	Util.waitTimeElementVisibility(genAdminContainer.OperaRateCategoryPropertyBellagio);
	executor.executeScript("arguments[0].click()", genAdminContainer.OperaRateCategoryPropertyBellagio);
	//genAdminContainer.OperaRateCategoryPropertyBellagio.click();
}	
public static void verifyOperaRateCategoryData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Static page Data is not displayed for Opera Rate Category ",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Opera Rate Category were found')]")).size()<=0);
	LOGGER.info("Pass,Static page Data is displayed for Opera Rate Category ");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}


//for Player Tier

public static void clickOnPlayerTiertab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.PlayerTier);
		
		executor.executeScript("arguments[0].click()", genAdminContainer.PlayerTier);
		//genAdminContainer.PlayerTier.click();
		LOGGER.info("Clicked on Player Tier for Static data");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void verifyPlayerTierData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Static page Data is not displayed for Player Tier",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Player Tier were found')]")).size()<=0);
	LOGGER.info("Pass,Static page Data is displayed for Player Tier");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}

//for Promotion Group

public static void clickOnPromotionGrouptab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.PromotionGroup);
		
		executor.executeScript("arguments[0].click()", genAdminContainer.PromotionGroup);
		//genAdminContainer.PromotionGroup.click();
		LOGGER.info("Clicked on Promotion Group for Static Data ");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void selectPropertyforPromotionGroup() {
	
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
	Util.waitTimeElementVisibility(genAdminContainer.PromotionGroupPropertydropdown);
	LOGGER.info("Before Clicking on the Property Drop Down for Promotion Group:");
	
	executor.executeScript("arguments[0].click()", genAdminContainer.PromotionGroupPropertydropdown);
	//genAdminContainer.PromotionGroupPropertydropdown.click();
	Util.waitTimeElementVisibility(genAdminContainer.PromotionGroupPropertyBellagio);
	executor.executeScript("arguments[0].click()", genAdminContainer.PromotionGroupPropertyBellagio);
	//genAdminContainer.PromotionGroupPropertyBellagio.click();
}	
public static void verifyPromotionGroupData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Static page Data is not displayed for Promotion Group ",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Promotion Group were found')]")).size()<=0);
	LOGGER.info("Pass,Static page Data is displayed for Promotion Group ");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}


//for Transaction Codes

public static void clickOnTraceAndDepartmentCodestab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.TracedepartmentCodes);
		executor.executeScript("arguments[0].click()", genAdminContainer.TracedepartmentCodes);
		//genAdminContainer.TransactionCodes.click();
		LOGGER.info("Clicked on Transaction Codes for Transaction Codes ");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void selectPropertyforTraceDepartmentCodes() {
	
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
	Util.waitTimeElementVisibility(genAdminContainer.TraceanddepartmentCodesPropertydropdown);
	LOGGER.info("Before Clicking on the Property Drop Down for Transaction Codes:");
	executor.executeScript("arguments[0].click()", genAdminContainer.TraceanddepartmentCodesPropertydropdown);
	//genAdminContainer.TransactionCodesPropertydropdown.click();
	Util.waitTimeElementVisibility(genAdminContainer.TraceanddepartmentCodesPropertyBellagio);
	executor.executeScript("arguments[0].click()", genAdminContainer.TraceanddepartmentCodesPropertyBellagio);
	//genAdminContainer.TransactionCodesPropertyBellagio.click();
}	
public static void verifyTraceDepartmentCodesData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Static page Data is not displayed for Trace and Department Codes ",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Trace and department Codes were found')]")).size()<=0);
	LOGGER.info("Pass,Static page Data is displayed for Trace Department Codes ");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}

//for Turnaway Codes

public static void clickOnTurnawayCodestab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.TurnawayCodes);
		genAdminContainer.TurnawayCodes.click();
		LOGGER.info("Clicked on Turnaway Codes for Static data");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void verifyTurnawayCodesData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Static page Data is not displayed for Turnaway Codes",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Turnaway Codes were found')]")).size()<=0);
	LOGGER.info("Pass,Static page Data is displayed for Turnaway Codes");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}


//Routing Authorizers

public static void clickOnRoutingAuthorizersTab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.operaDynamicDataPage);
		executor.executeScript("arguments[0].click()", genAdminContainer.operaDynamicDataPage);
		//genAdminContainer.TransactionCodes.click();
		LOGGER.info("Clicked on Routing Authorizers for Routing Authorizers ");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void selectPropertyforRoutingAuthorizers() {
	
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
	Util.waitTimeElementVisibility(genAdminContainer.AuthorizersPropertydropdown);
	LOGGER.info("Before Clicking on the Property Drop Down for Routing Authorizers:");
	executor.executeScript("arguments[0].click()", genAdminContainer.AuthorizersPropertydropdown);
	Util.waitTimeElementVisibility(genAdminContainer.AuthorizersPropertyBellagio);
	executor.executeScript("arguments[0].click()", genAdminContainer.AuthorizersPropertyBellagio);
}	


public static void verifyRoutingAuthorizersData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Dynamic page Data is not displayed for Routing Authorizers ",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Routing Authorizers data were found')]")).size()<=0);
	LOGGER.info("Pass,Dynamic page Data is displayed for Routing Authorizers ");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}





//Routing Codes

public static void clickOnRoutingCodesTab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.RoutingCode);
		executor.executeScript("arguments[0].click()", genAdminContainer.RoutingCode);
		//genAdminContainer.TransactionCodes.click();
		LOGGER.info("Clicked on Routing Codes for Routing Codes ");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void selectPropertyforRoutingCodes() {
	
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
	Util.waitTimeElementVisibility(genAdminContainer.RoutingCodePropertydropdown);
	LOGGER.info("Before Clicking on the Property Drop Down for Routing Codes:");
	executor.executeScript("arguments[0].click()", genAdminContainer.RoutingCodePropertydropdown);
	Util.waitTimeElementVisibility(genAdminContainer.RoutingCodePropertyBellagio);
	executor.executeScript("arguments[0].click()", genAdminContainer.RoutingCodePropertyBellagio);
}	


public static void verifyRoutingCodesData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Dynamic page Data is not displayed for Routing Codes ",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Routing Codes were found')]")).size()<=0);
	LOGGER.info("Pass,Dynamic page Data is displayed for Routing Codes ");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}


//for cancellation codes

public static void clickOnCancellationCodestab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.CancellationCode);
		executor.executeScript("arguments[0].click()", genAdminContainer.CancellationCode);
		LOGGER.info("Clicked on Cancellation codes for Dynamic data");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void verifyCancellationCodesData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Dynamic page Data is not displayed for Cacellation Code",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Cacellation Codes were found')]")).size()<=0);
	LOGGER.info("Pass,Static page Data is displayed for Cancellation Codes");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}


//For Promo codes

public static void clickOnPromoCodestab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.PromoCode);
		executor.executeScript("arguments[0].click()", genAdminContainer.PromoCode);
		LOGGER.info("Clicked on Promo codes for Dynamic data");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void verifyPromoCodesData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Dynamic page Data is not displayed for Promo Code",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Promo Codes were found')]")).size()<=0);
	LOGGER.info("Pass,Static page Data is displayed for Promo Codes");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}


//For Zip codes

public static void clickOnZipCodestab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.ZipCode);
		executor.executeScript("arguments[0].click()", genAdminContainer.ZipCode);
		LOGGER.info("Clicked on Zip Code for Dynamic data");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void verifyZipCodesData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Dynamic page Data is not displayed for Zip Code",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Zip Code were found')]")).size()<=0);
	LOGGER.info("Pass,Static page Data is displayed for Zip Code");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}




//For Travel Agents

public static void clickOnTravelAgentstab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.TravelAgent);
		executor.executeScript("arguments[0].click()", genAdminContainer.TravelAgent);
		LOGGER.info("Clicked on Promo codes for Travel Agent data");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void verifyTravelAgentsData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Dynamic page Data is not displayed for Travel Agent",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Travel Agent were found')]")).size()<=0);
	LOGGER.info("Pass,Static page Data is displayed for Travel Agent");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}




//For Company Profiles

public static void clickOnCompanyProfilestab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.CompanyProfiles);
		executor.executeScript("arguments[0].click()", genAdminContainer.CompanyProfiles);
		LOGGER.info("Clicked on Promo codes for Company Profiles");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void verifyCompanyProfilesData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Dynamic page Data is not displayed for Company Profiles",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Promo Codes were found')]")).size()<=0);
	LOGGER.info("Pass,Static page Data is displayed for Company Profiles");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}


//Market Codes

public static void clickOnMarketCodesTab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.MarketCode);
		executor.executeScript("arguments[0].click()", genAdminContainer.MarketCode);
		//genAdminContainer.TransactionCodes.click();
		LOGGER.info("Clicked on Routing Codes for Market Code ");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void selectPropertyforMarketCodes() {
	
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
	Util.waitTimeElementVisibility(genAdminContainer.MarketCodePropertydropdown);
	LOGGER.info("Before Clicking on the Property Drop Down for Routing Codes:");
	executor.executeScript("arguments[0].click()", genAdminContainer.MarketCodePropertydropdown);
	Util.waitTimeElementVisibility(genAdminContainer.MarketCodePropertyBellagio);
	executor.executeScript("arguments[0].click()", genAdminContainer.MarketCodePropertyBellagio);
}	


public static void verifyMarketCodesData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Dynamic page Data is not displayed for Market Code ",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Market Code were found')]")).size()<=0);
	LOGGER.info("Pass,Dynamic page Data is displayed for Market Code");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}



//Source Codes

public static void clickOnSourceCodesTab()
{
	try {
		Util.waitTimeElementVisibility(genAdminContainer.SourceCode);
		executor.executeScript("arguments[0].click()", genAdminContainer.SourceCode);
		//genAdminContainer.TransactionCodes.click();
		LOGGER.info("Clicked on Routing Codes for Source Code");
		Thread.sleep(5000);
		
	}catch(Exception e){
		e.printStackTrace();
	}
	
}	

public static void selectPropertyforSourceCodes() {
	
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
	Util.waitTimeElementVisibility(genAdminContainer.SourceCodePropertydropdown);
	LOGGER.info("Before Clicking on the Property Drop Down for Routing Codes:");
	executor.executeScript("arguments[0].click()", genAdminContainer.SourceCodePropertydropdown);
	Util.waitTimeElementVisibility(genAdminContainer.SourceCodePropertyBellagio);
	executor.executeScript("arguments[0].click()", genAdminContainer.SourceCodePropertyBellagio);
}	


public static void verifySourceCodesData() {

try {
	//Util.waitTimeElementVisibility(genAdminContainer.NodataAlertCodes);
	Thread.sleep(5000);
	Assert.assertTrue("FAIL, Dynamic page Data is not displayed for Source Code",BrowserDriver.getCurrentDriver().findElements(By.xpath("//*[contains(text(),'No Source Code were found')]")).size()<=0);
	LOGGER.info("Pass,Dynamic page Data is displayed for Source Code");
	
	
}catch(Exception e){
	e.printStackTrace();
}
}


public static int totalShowCategoryCalc() {
	try {
		Util.waitTimeElementVisibility( wd.findElement(By.xpath("//*[@id='layoutForm:dataTable_paginator_top']/select")));
		 Select dropdown = new Select(wd.findElement(By.xpath("//*[@id='layoutForm:dataTable_paginator_top']/select")));
		 dropdown.selectByValue("100");
		 System.out.println("Selected 100 per page display mode");
		 Thread.sleep(10000);
		 //Select Filter = new Select(wd.findElement(By.xpath("//*[@id='layoutForm:dataTable:userActiveColumn:filter']")));
		 //Filter.selectByVisibleText("All");
		 //Thread.sleep(5000);
		 //Util.waitTimeElementVisibility( wd.findElement(By.xpath("(//*[@class='ui-icon ui-icon-seek-end'])[1]")));
		// wd.findElement(By.xpath("(//*[@class='ui-icon ui-icon-seek-end'])[1]")).click();
		 executor.executeScript("arguments[0].click()", wd.findElement(By.xpath("(//*[@class='ui-icon ui-icon-seek-end'])[1]")));
		 Thread.sleep(5000);
		 //new WebDriverWait(wd, 60).until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(@id,':editButton')])[1]")));
		 Thread.sleep(10000);
		 //String count=wd.findElement(By.xpath( " (//*[@class='ui-paginator-page ui-state-default ui-corner-all ui-state-active'])[1]")).getText();
		 //Integer count1=Integer.parseInt(count);
		 //System.out.println(count1-1);
		 //totalcount= wd.findElements(By.xpath("//*[@id=\"layoutForm:dataTable:showCategoryDTODispColumnDesc\"]")).size();
		 //List<WebElement> rows = driver.findElements(By.xpath("//table[@class='table table-condensed table-hover event-list']/tbody/tr"));
		 WebElement TogetRows = wd.findElement(By.xpath("//*[@id='layoutForm:dataTable_data']"));
		
		 ArrayList<WebElement> TotalRowsList = (ArrayList<WebElement>) TogetRows.findElements(By.tagName("tr"));
		 
		 totalcount =TotalRowsList.size();
		 
		 //System.out.println(wd.findElements(By.xpath("//*[@class='dataTableLinkActive']")).size());
		 //System.out.println(totalcount);
		 LOGGER.info("Total number of Shows Category="+totalcount);

	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	return totalcount;
}


public static int totalRestaurantCalc() {
	try {
		Util.waitTimeElementVisibility( wd.findElement(By.xpath("//*[@id='layoutForm:dataTable_paginator_top']/select")));
		 Select dropdown = new Select(wd.findElement(By.xpath("//*[@id='layoutForm:dataTable_paginator_top']/select")));
		 dropdown.selectByValue("100");
		 System.out.println("Selected 100 per page display mode");
		 Thread.sleep(10000);
		 //Select Filter = new Select(wd.findElement(By.xpath("//*[@id='layoutForm:dataTable:userActiveColumn:filter']")));
		 //Filter.selectByVisibleText("All");
		 //Thread.sleep(5000);
		 //Util.waitTimeElementVisibility( wd.findElement(By.xpath("(//*[@class='ui-icon ui-icon-seek-end'])[1]")));
		// wd.findElement(By.xpath("(//*[@class='ui-icon ui-icon-seek-end'])[1]")).click();
		 executor.executeScript("arguments[0].click()", wd.findElement(By.xpath("(//*[@class='ui-icon ui-icon-seek-end'])[1]")));
		 Thread.sleep(5000);
		 //new WebDriverWait(wd, 60).until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(@id,':editButton')])[1]")));
		 Thread.sleep(10000);
		 //String count=wd.findElement(By.xpath( " (//*[@class='ui-paginator-page ui-state-default ui-corner-all ui-state-active'])[1]")).getText();
		 //Integer count1=Integer.parseInt(count);
		 //System.out.println(count1-1);
		 //totalcount= wd.findElements(By.xpath("//*[@id=\"layoutForm:dataTable:showCategoryDTODispColumnDesc\"]")).size();
		 //List<WebElement> rows = driver.findElements(By.xpath("//table[@class='table table-condensed table-hover event-list']/tbody/tr"));
		 WebElement TogetRows = wd.findElement(By.xpath("//*[@id='layoutForm:dataTable_data']"));
		
		 ArrayList<WebElement> TotalRowsList = (ArrayList<WebElement>) TogetRows.findElements(By.tagName("tr"));
		 
		 totalcount =TotalRowsList.size();
		 
		 //System.out.println(wd.findElements(By.xpath("//*[@class='dataTableLinkActive']")).size());
		 //System.out.println(totalcount);
		 LOGGER.info("Total number of Restaurant="+totalcount);

	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	return totalcount;
}


}
