package com.mystique.view;

import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.MystiquePropertyContainer;
import com.mystique.utils.CommonUtils;

public class MystiquePropertyView {
	
	private static final Logger LOGGER = Logger
			.getLogger(MystiqueProgramView.class.getName());
	private static final MystiquePropertyContainer propertyContainer = PageFactory
			.initElements(BrowserDriver.getCurrentDriver(),
					MystiquePropertyContainer.class);
	static WebDriver bd = BrowserDriver.getCurrentDriver();
	static JavascriptExecutor executor = (JavascriptExecutor) bd; 
	static CommonUtils Util=new CommonUtils();
	
	
	public static void hoverOnPropertyTab() {
		LOGGER.info("Inside select Property:");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	
		Actions action = new Actions(BrowserDriver.getCurrentDriver());
		WebElement we =BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:menuPanel']/div/ul/li[2]/a/span[2]"));
		action.moveToElement(we).build().perform();
		/*try {
			Thread.sleep(5000);
			Util.waitTimeElementVisibility(propertyContainer.propertyExpandAll);
			propertyContainer.propertyExpandAll.click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	
*/	}
	
	public static void clickOnPropertySettingsTab() {
		
		try {
			Thread.sleep(5000);
			Util.waitTimeElementVisibility(propertyContainer.propertySettingsMenu);
			int intTest = bd.findElements(By.id("layoutForm:setProperty")).size();
			Assert.assertTrue("Failed, Property Settings Menu element is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Property Settings Menu element is present",propertyContainer.propertySettingsMenu.isDisplayed());
			propertyContainer.propertySettingsMenu.click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	
	public static void clickOnBookingLimitationsTab() {
		
		try {
			Thread.sleep(5000);
			Util.waitTimeElementVisibility(propertyContainer.BookingLimitations);
			int intTest = bd.findElements(By.id("layoutForm:powerRank")).size();
			Assert.assertTrue("Failed, Booking Limitations element is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Property Settings Menu element is present",propertyContainer.propertySettingsMenu.isDisplayed());
			executor.executeScript("arguments[0].click();", propertyContainer.BookingLimitations);
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	

	public static void clickOnSelectPropertyTab() {
		
		try {
			Thread.sleep(5000);
			Util.waitTimeElementVisibility(propertyContainer.propertyExpandAll);
			propertyContainer.propertyExpandAll.click();
			
/*			Util.waitTimeElementVisibility(propertyContainer.propertySpecifiedRadioButton);
			propertyContainer.propertySpecifiedRadioButton.click();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			Util.waitTimeElementVisibility(propertyContainer.selectProperty);
			propertyContainer.selectProperty.click();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			Util.waitTimeElementVisibility(propertyContainer.selectAllPropertyArrow);
			propertyContainer.selectAllPropertyArrow.click();
			Util.waitTimeElementVisibility(propertyContainer.selectPropertyArrow);
			propertyContainer.selectPropertyArrow.click();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			Util.waitTimeElementVisibility(propertyContainer.selectProperty);
			propertyContainer.selectProperty.click();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			Util.waitTimeElementVisibility(propertyContainer.selectPropertyArrow);
			propertyContainer.selectPropertyArrow.click();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			Util.waitTimeElementVisibility(propertyContainer.selectProperty);
			propertyContainer.selectProperty.click();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			Util.waitTimeElementVisibility(propertyContainer.selectPropertyArrow);
			propertyContainer.selectPropertyArrow.click();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			Util.waitTimeElementVisibility(propertyContainer.displayDropDown);
			propertyContainer.displayDropDown.click();
			Util.waitTimeElementVisibility(propertyContainer.displayDropDown);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:filterDisplay']/div[3]")).size();
			Assert.assertTrue("Failed, Display DropDown element is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Display DropDown element is present",propertyContainer.displayDropDown.isDisplayed());
			propertyContainer.displayTotalPriceSelect.click();*/
			
			Util.waitTimeElementVisibility(propertyContainer.propertyRegionDropdown);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:propertyRegion']")).size();
			Assert.assertTrue("Failed, Display DropDown element is not present",intTest > 0);
			LOGGER.info("property settings page is loaded.");
			
			boolean rates = propertyContainer.syncRatesToOpera.isSelected();
			if(rates== false){				
				propertyContainer.syncRatesToOpera.click();			
			}
			boolean programs = propertyContainer.syncProgramsToOpera.isSelected();
			if(programs== false){				
				executor.executeScript("arguments[0].click();", propertyContainer.syncProgramsToOpera);
			}
			
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}
	
	public static void clickOnSaveProperty() {
		
		try {
			Thread.sleep(2000);
			((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("window.scrollTo(0, document.body.scrollHeight)");
			Util.waitTimeElementVisibility(propertyContainer.propertySaveButton);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:saveButton']")).size();
			Assert.assertTrue("Failed, Property Save Button is not present",intTest > 0);
			
			LOGGER.info("Clicked on save button"); 
			
			//Assert.assertTrue("PASS, Property Save Button is present",propertyContainer.propertySaveButton.isDisplayed());
			propertyContainer.propertySaveButton.click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}		
	}
	
	public static void clickOnSelectPropertyCheckChangeTab() {
		
		try {
			Thread.sleep(10000);
			Util.waitTimeElementVisibility(propertyContainer.propertyExpandAll);
			propertyContainer.propertyExpandAll.click();
			Util.waitTimeElementVisibility(propertyContainer.selectBackProperty);
			propertyContainer.selectBackProperty.click();
			
			Util.waitTimeElementVisibility(propertyContainer.selectBackPropertyArrow);
			propertyContainer.selectBackPropertyArrow.click();
			/*try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
			Util.waitTimeElementVisibility(propertyContainer.selectAllPropertyArrow);
			propertyContainer.selectAllPropertyArrow.click();
			/*try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
			Util.waitTimeElementVisibility(propertyContainer.selectProperty);
			propertyContainer.selectProperty.click();
		/*	try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
			Util.waitTimeElementVisibility(propertyContainer.selectPropertyArrow);
			propertyContainer.selectPropertyArrow.click();
			/*try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
			Util.waitTimeElementVisibility(propertyContainer.selectPropertyArrow);
			propertyContainer.selectAllPropertyArrow.click();
			/*try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
			Util.waitTimeElementVisibility(propertyContainer.selectProperty);
			propertyContainer.selectProperty.click();
			/*try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
			Util.waitTimeElementVisibility(propertyContainer.selectPropertyArrow);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:propertyList']/tbody/tr/td[2]/button[1]")).size();
			Assert.assertTrue("Failed, Property Arrow option is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Property Arrow option is present",propertyContainer.selectPropertyArrow.isDisplayed());
			propertyContainer.selectPropertyArrow.click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	/*	try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	
	}
	
public static void provideResortFeeValue2() {
		
		try {
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(propertyContainer.propertyExpandAll);
			propertyContainer.propertyExpandAll.click();
			Util.waitTimeElementVisibility(propertyContainer.propertyResortFee);
			propertyContainer.propertyResortFee.click();
			propertyContainer.propertyResortFee.sendKeys("2.31");
			propertyContainer.propertyResortFee.sendKeys(Keys.TAB);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		
	
	}

public static void selectPowerRank() {
	
	try {
		Thread.sleep(2000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
	new WebDriverWait(bd,50).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='layoutForm:pwrRank']/div[3]/span")));
	LOGGER.info("Before Clicking on the Power Rank Drop Down:");
	Util.waitTimeElementVisibility(propertyContainer.powerRankSelectionDropDown);
	propertyContainer.powerRankSelectionDropDown.click();
	try {
		Thread.sleep(2000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	Util.waitTimeElementVisibility(propertyContainer.powerRankMenuSelection);
	int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:pwrRank_panel']/div/ul/li[2]")).size();
	Assert.assertTrue("Failed, Power Rank Selection element is not present",intTest > 0);
	
	propertyContainer.powerRankMenuSelection.click();
	LOGGER.info(" Value 1 is selected from Power Rank Dropdown");
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

public static void selectDominantPlay() {
	
	try {
		Thread.sleep(2000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
	new WebDriverWait(bd,50).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='layoutForm:dominantPlay']/div[3]/span")));
	LOGGER.info("Before Clicking on the Dominant Play Drop Down:");
	Util.waitTimeElementVisibility(propertyContainer.dominantplaySelectionDropDown);
	propertyContainer.dominantplaySelectionDropDown.click();
	try {
		Thread.sleep(2000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	Util.waitTimeElementVisibility(propertyContainer.dominantplayMenuSelection);
	int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:dominantPlay_panel']/div/ul/li[2]")).size();
	Assert.assertTrue("Failed, Dominant Play Selection element is not present",intTest > 0);
	
	propertyContainer.dominantplayMenuSelection.click();
	LOGGER.info(" Value Table is selected from Dominant Play Dropdown");
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}


public static void selectDominantPlayAsPoker() {
	
	try {
		Thread.sleep(20000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
	new WebDriverWait(bd,50).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='layoutForm:dominantPlay']/div[3]/span")));
	LOGGER.info("Before Clicking on the Dominant Play Drop Down:");
	Util.waitTimeElementVisibility(propertyContainer.dominantplaySelectionDropDown);
	propertyContainer.dominantplaySelectionDropDown.click();
	try {
		Thread.sleep(15000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	Util.waitTimeElementVisibility(propertyContainer.dominantplayMenuSelectionPoker);
	int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:dominantPlay_panel']/div/ul/li[3]")).size();
	Assert.assertTrue("Failed, Dominant Play Selection element is not present",intTest > 0);
	
	propertyContainer.dominantplayMenuSelectionPoker.click();
	LOGGER.info(" Value Poker is selected from Dominant Play Dropdown");
	try {
		Thread.sleep(15000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

public static void ClearAndSetText(WebElement element, String text)
{
    WebElement e = element;
    Actions navigator = new Actions(bd);
    navigator.click(e)
        //.sendKeys(Keys.END)
        //.keyDown(Keys.SHIFT)
        //.sendKeys(Keys.HOME)
        //.keyUp(Keys.SHIFT)
        .sendKeys(Keys.BACK_SPACE)
        .sendKeys(Keys.BACK_SPACE)
        .sendKeys(Keys.BACK_SPACE)
        .sendKeys(text)
        .perform();
}

public static void ClearText(WebElement element)
{
    WebElement e = element;
    Actions navigator = new Actions(bd);
    navigator.click(e)
        //.sendKeys(Keys.END)
        //.keyDown(Keys.SHIFT)
        //.sendKeys(Keys.HOME)
        //.keyUp(Keys.SHIFT)
        .sendKeys(Keys.BACK_SPACE)
        .sendKeys(Keys.BACK_SPACE)
        .sendKeys(Keys.BACK_SPACE)
        .perform();
}

public static void provideCompMaxValue() {
	
	try {
		Thread.sleep(2000);
		Util.waitTimeElementVisibility(propertyContainer.CompMax);
		propertyContainer.CompMax.click();
		Thread.sleep(3000);
		ClearAndSetText(propertyContainer.CompMax,"20");
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
}

public static void provideRateMaxValue() {
	
	try {
		Thread.sleep(2000);
		Util.waitTimeElementVisibility(propertyContainer.RateMax);
		propertyContainer.RateMax.click();
		Thread.sleep(3000);
		ClearAndSetText(propertyContainer.RateMax,"25");
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
}

public static void provideWeeklyLimitValue() {
	
	try {
		Thread.sleep(3000);
		Util.waitTimeElementVisibility(propertyContainer.WeeklyLimit);
		propertyContainer.WeeklyLimit.click();
		Thread.sleep(15000);
		ClearAndSetText(propertyContainer.WeeklyLimit,"35");
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
}

public static void provideDailyLimitValue() {
	
	try {
		Thread.sleep(3000);
		Util.waitTimeElementVisibility(propertyContainer.DailyLimit);
		propertyContainer.DailyLimit.click();
		Thread.sleep(15000);
		ClearAndSetText(propertyContainer.DailyLimit,"45");
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
}

public static void provideBookingWindowCompLimitValue() {
	
	try {
		Thread.sleep(3000);
		Util.waitTimeElementVisibility(propertyContainer.BookingWindowCompLimit);
		propertyContainer.BookingWindowCompLimit.click();
		Thread.sleep(15000);
		ClearAndSetText(propertyContainer.BookingWindowCompLimit,"55");
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
}

public static void provideCompMaxConfigValue() {
	
	try {
		Thread.sleep(3000);
		Util.waitTimeElementVisibility(propertyContainer.CompMaxConfig);
		propertyContainer.CompMaxConfig.click();
		Thread.sleep(15000);
		ClearAndSetText(propertyContainer.CompMaxConfig,"65");
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
}

public static void provideBookWindowRainLimitValue() {
	
	try {
		Thread.sleep(3000);
		Util.waitTimeElementVisibility(propertyContainer.BookWindowRainLimit);
		propertyContainer.BookWindowRainLimit.click();
		Thread.sleep(15000);
		ClearAndSetText(propertyContainer.BookWindowRainLimit,"75");
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
}



	public static void clickSaveBookingLimitations() {
		
		try {
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(propertyContainer.SaveBtn);
			propertyContainer.SaveBtn.click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
}
	
	public static void saveConfirmationBookingLimitations_CompMax() {
		boolean CorrectValue;
		
		try {
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(propertyContainer.SaveConfirmation);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:messages_container']/div")).size();
			String value= propertyContainer.CompMax.getText();
			System.out.println(value);
			if(value.equalsIgnoreCase("20")){
				 CorrectValue=true;
			}
			else{
				 CorrectValue=false;
			}
			
			Assert.assertTrue("Failed, Value not saved",intTest > 0 && CorrectValue);
			LOGGER.info("Comp Max value Saved");
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
}	

	public static void saveConfirmationBookingLimitations_RateMax() {
		boolean CorrectValue;
		
		try {
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(propertyContainer.SaveConfirmation);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:messages_container']/div")).size();
			String value= propertyContainer.RateMax.getText();
			System.out.println(value);
			if(value.equalsIgnoreCase("25")){
				 CorrectValue=true;
			}
			else{
				 CorrectValue=false;
			}
			
			Assert.assertTrue("Failed, Value not saved",intTest > 0 && CorrectValue);
			LOGGER.info("Rate Max value Saved");
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
}	
	
	public static void saveConfirmationBookingLimitations_WeeklyLimit() {
		boolean CorrectValue;
		
		try {
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(propertyContainer.SaveConfirmation);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:messages_container']/div")).size();
			String value= propertyContainer.WeeklyLimit.getText();
			System.out.println(value);
			if(value.equalsIgnoreCase("35")){
				 CorrectValue=true;
			}
			else{
				 CorrectValue=false;
			}
			
			Assert.assertTrue("Failed, Value not saved",intTest > 0 && CorrectValue);
			LOGGER.info("Weekly Limit value Saved");
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
}
	
	
	public static void saveConfirmationBookingLimitations_DailyLimit() {
		boolean CorrectValue;
		
		try {
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(propertyContainer.SaveConfirmation);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:messages_container']/div")).size();
			String value= propertyContainer.DailyLimit.getText();
			System.out.println(value);
			if(value.equalsIgnoreCase("45")){
				 CorrectValue=true;
			}
			else{
				 CorrectValue=false;
			}
			
			Assert.assertTrue("Failed, Value not saved",intTest > 0 && CorrectValue);
			LOGGER.info("Daily Limit value Saved");
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
}
	
	public static void saveConfirmationBookingLimitations_BookingWindowCompLimit() {
		boolean CorrectValue;
		
		try {
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(propertyContainer.SaveConfirmation);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:messages_container']/div")).size();
			String value= propertyContainer.BookingWindowCompLimit.getText();
			System.out.println(value);
			if(value.equalsIgnoreCase("55")){
				 CorrectValue=true;
			}
			else{
				 CorrectValue=false;
			}
			
			Assert.assertTrue("Failed, Value not saved",intTest > 0 && CorrectValue);
			LOGGER.info("Booking Window Comp Limit value Saved");
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
}
	
	public static void saveConfirmationBookingLimitations_CompMaxConfig() {
		boolean CorrectValue;
		
		try {
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(propertyContainer.SaveConfirmation);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:messages_container']/div")).size();
			String value= propertyContainer.CompMaxConfig.getText();
			System.out.println(value);
			if(value.equalsIgnoreCase("65")){
				 CorrectValue=true;
			}
			else{
				 CorrectValue=false;
			}
			
			Assert.assertTrue("Failed, Value not saved",intTest > 0 && CorrectValue);
			LOGGER.info("Comp Max Config value Saved");
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
}
	
	
	public static void saveConfirmationBookingLimitations_BookWindowRainLimit() {
		boolean CorrectValue;
		
		try {
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(propertyContainer.SaveConfirmation);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:messages_container']/div")).size();
			String value= propertyContainer.BookWindowRainLimit.getText();
			System.out.println(value);
			if(value.equalsIgnoreCase("75")){
				 CorrectValue=true;
			}
			else{
				 CorrectValue=false;
			}
			
			Assert.assertTrue("Failed, Value not saved",intTest > 0 && CorrectValue);
			LOGGER.info("Book Window Rain Limit value Saved");
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
}
	
	
	public static void LookBackDays_RateSettings() {
		try {
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(propertyContainer.LookBackDays);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:backwardBookingLimits']")).size();
			Assert.assertTrue("Failed, Look Back Days is not present",intTest > 0);
			//propertyContainer.LookBackDays.sendKeys("8");
			ClearAndSetText(propertyContainer.LookBackDays,"20");
			LOGGER.info("Value entered in Look Back Days"); 
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
}
	
	public static void LookBackDays_RateSettings_morethan999() {
		try {
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(propertyContainer.LookBackDays);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:backwardBookingLimits']")).size();
			Assert.assertTrue("Failed, Look Back Days is not present",intTest > 0);
			//propertyContainer.LookBackDays.sendKeys("8");
			ClearAndSetText(propertyContainer.LookBackDays,"44444444");
			LOGGER.info("Value entered in Look Back Days"); 
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
}
	
	public static void ExpandAll_RateSettings() {
		try {
			Thread.sleep(1000);
			Util.waitTimeElementVisibility(propertyContainer.propertyExpandAll);
			propertyContainer.propertyExpandAll.click();
		}
		catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void LookForwardDays_RateSettings_morethan999() {
		try {	
			Thread.sleep(1000);
			Util.waitTimeElementVisibility(propertyContainer.LookForwardDays);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:forwardBookingLimits']")).size();
			Assert.assertTrue("Failed, Look Forward Days is not present",intTest > 0);
			//propertyContainer.LookForwardDays.sendKeys("88");
			ClearAndSetText(propertyContainer.LookForwardDays,"44444444");
			LOGGER.info("Value entered in Look Forward Days"); 
		} 
		catch (InterruptedException e) {

			e.printStackTrace();
		}
}
	
	public static void LookForwardDays_RateSettings() {
		try {	
			Thread.sleep(1000);
			Util.waitTimeElementVisibility(propertyContainer.LookForwardDays);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:forwardBookingLimits']")).size();
			Assert.assertTrue("Failed, Look Forward Days is not present",intTest > 0);
			//propertyContainer.LookForwardDays.sendKeys("88");
			ClearAndSetText(propertyContainer.LookForwardDays,"200");
			LOGGER.info("Value entered in Look Forward Days"); 
		} 
		catch (InterruptedException e) {

			e.printStackTrace();
		}
}
	
	
	public static void ClearLookForwardDaysvalue() {
		try {
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(propertyContainer.LookForwardDays);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:forwardBookingLimits']")).size();
			Assert.assertTrue("Failed, Look Forward Days is not present",intTest > 0);
			//propertyContainer.LookForwardDays.sendKeys("88");
			ClearText(propertyContainer.LookForwardDays);
			LOGGER.info("Value entered in Look Forward Days"); 
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
}
	
	
	public static void ClearLookBackDaysvalue() {
		try {
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(propertyContainer.LookBackDays);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:backwardBookingLimits']")).size();
			Assert.assertTrue("Failed, Look Back Days is not present",intTest > 0);
			//propertyContainer.LookForwardDays.sendKeys("88");
			ClearText(propertyContainer.LookBackDays);
			LOGGER.info("Value entered in Look Back Days"); 
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
}

	public static void alertdialogbox_LookBackDays() {
		try {
			Thread.sleep(3000);
			int intTest=0;
			//Util.waitTimeElementVisibility(propertyContainer.alertdialog);
			String text = bd.findElement(By.xpath("//*[@id='layoutForm:alertDialogVal']/div[2]/p")).getText();
			if (text.contains("Please provide Look Back Days")){
				intTest=1;
			}
			else{
				intTest=0;
			}
			Assert.assertTrue("Failed, alertbox is not present",intTest > 0);
			//propertyContainer.LookForwardDays.sendKeys("88");
			LOGGER.info("Alert dialog box is displayed for providing Look Back Days"); 
			
			propertyContainer.alertdialog_ok.click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
}
	
	public static void alertdialogbox_valuemorethan999() {
		try {
			Thread.sleep(3000);
			int intTest=0;
			//Util.waitTimeElementVisibility(propertyContainer.alertdialog);
			String text = bd.findElement(By.xpath("//*[@id='layoutForm:alertDialogVal']/div[2]/p")).getText();
			if (text.contains("Booking Limits field supports values from 0 to 999 !!!")){
				intTest=1;
			}
			else{
				intTest=0;
			}
			Assert.assertTrue("Failed, alertbox is not present",intTest > 0);
			//propertyContainer.LookForwardDays.sendKeys("88");
			LOGGER.info("Alert dialog box is displayed for providing values from 0 to 999 "); 
			
			propertyContainer.alertdialog_ok.click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
}
	
	public static void alertdialogbox_LookForwardDays() {
		try {
			Thread.sleep(3000);
			int intTest=0;
			//Util.waitTimeElementVisibility(propertyContainer.alertdialog);
			String text = bd.findElement(By.xpath("//*[@id='layoutForm:alertDialogVal']/div[2]/p")).getText();
			if (text.contains("Please provide Look Forward Days")){
				intTest=1;
			}
			else{
				intTest=0;
			}
			Assert.assertTrue("Failed, alertbox is not present",intTest > 0);
			//propertyContainer.LookForwardDays.sendKeys("88");
			LOGGER.info("Alert dialog box is displayed for providing Look Forward Days"); 
			propertyContainer.alertdialog_ok.click();

		} catch (InterruptedException e) {

			e.printStackTrace();
		}
}
	
	
	
	public static void confirmation_on_save() {
		try {
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(propertyContainer.confirmationonsave);
			int intTest = bd.findElements(By.xpath("//*[@class='ui-growl-message']/span")).size();
			Assert.assertTrue("Failed, Error while saving ",intTest > 0);
			LOGGER.info("Successfully saved"); 
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
}
	
public static void checkResortFeeValue2TabOut() {
	
	try {
		Thread.sleep(3000);
		Util.waitTimeElementVisibility(propertyContainer.propertyResortFee);
		LOGGER.info(propertyContainer.propertyResortFee.getAttribute("value"));
		Assert.assertTrue("Failed, Resort Fee is not rounded to 3 decimal places",propertyContainer.propertyResortFee.getAttribute("value").equals("2.310"));
		
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
	

}
	
}
