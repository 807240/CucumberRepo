package com.mystique.view;

import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Assert.*;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.MystiqueProgramContainer;
import com.mystique.utils.CommonUtils;
import com.mystique.utils.Constants;

public class MystiqueProgramView {
	public static final Properties ticketProgram = CommonUtils.getConfigPath(Constants.TICKET_PROGRAM);
	public static final Properties roomProgram = CommonUtils.getConfigPath(Constants.ROOM_PROGRAM);
	public static final Properties common = CommonUtils.getConfigPath(Constants.COMMON_PATH);
	private static final Logger LOGGER = Logger
			.getLogger(MystiqueProgramView.class.getName());

	private static final MystiqueProgramContainer programContainer = PageFactory
			.initElements(BrowserDriver.getCurrentDriver(),
					MystiqueProgramContainer.class);
	
	
	static WebDriver bd = BrowserDriver.getCurrentDriver();
	static JavascriptExecutor executor = (JavascriptExecutor)bd;
	static CommonUtils Util=new CommonUtils();
	
	private static int randomNumber = (int)(Math.random()*10000);
	
	public static void selectCampaignAdmin(){
		
		Util.waitTimeElementVisibility(programContainer.campaignAdminDropDown);
		//programContainer.campaignAdminDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.campaignAdminDropDown);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("Clicking on Campaign Administration drop down");
		Util.waitTimeElementVisibility(programContainer.selectCampaignAdmin);
		//programContainer.selectCampaignAdmin.click(); 
		executor.executeScript("arguments[0].click();",programContainer.selectCampaignAdmin);
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	};
		
	
	public static void selectARIAfromDropDown() {
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		new WebDriverWait(bd,50).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='layoutForm:propertySelectMenu']/div[3]/span")));
		LOGGER.info("Before Clicking on the Property Drop Down:");
		Util.waitTimeElementVisibility(programContainer.propertyMenuSelectionDropDown);
		//programContainer.propertyMenuSelectionDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.propertyMenuSelectionDropDown);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.propertyMenuSelection);
		int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:propertySelectMenu_panel']/div/ul/li[2]")).size();
		Assert.assertTrue("Failed, Property Menu Selection element is not present",intTest > 0);
		
		//Assert.assertTrue("PASS, Property Menu Selection element is present",programContainer.propertyMenuSelection.isDisplayed());
		//programContainer.propertyMenuSelection.click();
		executor.executeScript("arguments[0].click();",programContainer.propertyMenuSelection);
		LOGGER.info("Clicked on ARIA");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
public static void selectBORGATAfromDropDown() {
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		new WebDriverWait(bd,50).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='layoutForm:propertySelectMenu']/div[3]/span")));
		LOGGER.info("Before Clicking on the Property Drop Down:");
		Util.waitTimeElementVisibility(programContainer.propertyMenuSelectionDropDown);
		//programContainer.propertyMenuSelectionDropDown.click(); 
		executor.executeScript("arguments[0].click();",programContainer.propertyMenuSelectionDropDown);
		try {
			Thread.sleep(15000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.propertyMenuSelectionBorgata);
		int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:propertySelectMenu_panel']/div/ul/li[2]")).size();
		Assert.assertTrue("Failed, Property Menu Selection element is not present",intTest > 0);
		
		//Assert.assertTrue("PASS, Property Menu Selection element is present",programContainer.propertyMenuSelection.isDisplayed());
		//programContainer.propertyMenuSelectionBorgata.click(); 
		executor.executeScript("arguments[0].click();",programContainer.propertyMenuSelectionBorgata);
		LOGGER.info("Clicked on Borgata");
		try {
			Thread.sleep(15000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public static void hoverOnProgramTab() {
		
		try {
			LOGGER.info("Inside select Program:");
			new WebDriverWait(bd,40).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[@class='ui-menuitem-text' and contains(text(),'Program')])[1]")));
			Actions action = new Actions(BrowserDriver.getCurrentDriver());
			WebElement we =bd.findElement(By.xpath("(//*[@class='ui-menuitem-text' and contains(text(),'Program')])[1]"));
			
			int intTest = bd.findElements(By.xpath("(//*[@class='ui-menuitem-text' and contains(text(),'Program')])[1]")).size();
			Assert.assertTrue("Failed, Program element is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Program element is present",bd.findElement(By.xpath("(//*[@class='ui-menuitem-text' and contains(text(),'Program')])[1]")).isDisplayed());
			action.moveToElement(we).build().perform();
			Thread.sleep(3500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}	
	}
	
	public static void hoverOnPropertyTab() {
		LOGGER.info("Inside select Property:");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	
		Actions action = new Actions(BrowserDriver.getCurrentDriver());
		WebElement we =BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:menuPanel']/div/ul/li[2]/a/span[2]"));
		action.moveToElement(we).build().perform();
		/*try {
			Thread.sleep(5000);
			Util.waitTimeElementVisibility(propertyContainer.propertyExpandAll);
			propertyContainer.propertyExpandAll.click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	
*/	}
	
public static void clickOnCreditCardAuthorizationsTab() {
		
		try {
			Thread.sleep(5000);
			Util.waitTimeElementVisibility(programContainer.CreditCardAuthorization_link);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:ccAuth']/span")).size();
			Assert.assertTrue("Failed, Credit Card Authorization link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Property Settings Menu element is present",propertyContainer.propertySettingsMenu.isDisplayed());
			//programContainer.CreditCardAuthorization_link.click(); 
			executor.executeScript("arguments[0].click();",programContainer.CreditCardAuthorization_link);
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	
	public static void clickManageProgram(){
		
		try {
			Thread.sleep(20000);
			Util.waitTimeElementVisibility(programContainer.managePrograms);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:menuBar']/ul/li[3]/ul")).size();
			Assert.assertTrue("Failed, Manage Programs link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Manage Programs link is present",programContainer.managePrograms.isDisplayed());
			executor.executeScript("arguments[0].click();",programContainer.managePrograms);
			//executor.executeScript("arguments[0].click();",programContainer.managePrograms);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	
	public static void clickAllProgram(){
		
		try {
			Thread.sleep(2000);
			Util.waitTimeElementVisibility(programContainer.allPrograms);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:setAllProgram']/span")).size();
			Assert.assertTrue("Failed, All Programs link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Manage Programs link is present",programContainer.managePrograms.isDisplayed());
			//programContainer.allPrograms.click(); 
			executor.executeScript("arguments[0].click();",programContainer.allPrograms);
			
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
public static void hoverOnSegmentTab() {
		
		try {
			LOGGER.info("Inside select Segment:");
			new WebDriverWait(bd,40).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[@class='ui-menuitem-text' and contains(text(),'Segment')])[1]")));
			Actions action = new Actions(BrowserDriver.getCurrentDriver());
			WebElement we =bd.findElement(By.xpath("(//*[@class='ui-menuitem-text' and contains(text(),'Segment')])[1]"));
			
			int intTest = bd.findElements(By.xpath("(//*[@class='ui-menuitem-text' and contains(text(),'Segment')])[1]")).size();
			Assert.assertTrue("Failed, Segment element is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Program element is present",bd.findElement(By.xpath("(//*[@class='ui-menuitem-text' and contains(text(),'Program')])[1]")).isDisplayed());
			action.moveToElement(we).build().perform();
			Thread.sleep(3500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}	
	}

	public static void clickManageSegments(){
		
		try {
			Thread.sleep(20000);
			Util.waitTimeElementVisibility(programContainer.manageSegments);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:setSegment']/span")).size();
			Assert.assertTrue("Failed, Manage Segments link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Manage Programs link is present",programContainer.managePrograms.isDisplayed());
			//programContainer.manageSegments.click(); 
			executor.executeScript("arguments[0].click();",programContainer.manageSegments);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void clickOnSearchLink () {
		try {
			Util.waitTimeElementVisibility(programContainer.searchProgramLink);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:searchProgramLink']")).size();
			Assert.assertTrue("Failed, Search Program Link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Search Program Link is present",programContainer.searchProgramLink.isDisplayed());
			//programContainer.searchProgramLink.click(); //Clicks the search program link
			executor.executeScript("arguments[0].click();",programContainer.searchProgramLink);
			Thread.sleep(8000);

		} catch (Exception ex) {
			ex.printStackTrace();
		} 	 
	}

	public static void inputCustomerValueFrom (final String programName) {
		try {

			Util.waitTimeElementVisibility(programContainer.SrchTierCreditToTextBox);
			programContainer.SrchTierCreditToTextBox.clear();
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(programContainer.SrchTierCreditFromTextBox);
			programContainer.SrchTierCreditFromTextBox.sendKeys(roomProgram.getProperty("program.search.customerFromValue"));
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(programContainer.searchProgramName);
			programContainer.searchProgramName.sendKeys(programName);
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(programContainer.searchButton);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:searchButton']")).size();
			Assert.assertTrue("Failed, Search Button is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Search Button is present",programContainer.searchButton.isDisplayed());
			//programContainer.searchButton.click(); 
			executor.executeScript("arguments[0].click();",programContainer.searchButton);
			Thread.sleep(3000);		 
		} catch (Exception ex) {
			ex.printStackTrace();
		} 		 
	}

	public static void inputCustomerValueTo (final String programName) {
		try {

			programContainer.SrchTierCreditFromTextBox.clear();
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(programContainer.SrchTierCreditToTextBox);
			programContainer.SrchTierCreditToTextBox.sendKeys(roomProgram.getProperty("program.search.customerToValue"));
			Thread.sleep(3000);
			programContainer.searchProgramName.clear();
			Util.waitTimeElementVisibility(programContainer.searchProgramName);
			programContainer.searchProgramName.sendKeys(programName);
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(programContainer.searchButton);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:searchButton']")).size();
			Assert.assertTrue("Failed, Search Button is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Search Button is present",programContainer.searchButton.isDisplayed());
			//programContainer.searchButton.click(); 
			executor.executeScript("arguments[0].click();",programContainer.searchButton);
			Thread.sleep(3000); 
		} catch (Exception ex) {
			ex.printStackTrace();
		} 

	}

	public static void inputCustomerValueToFrom (final String programName) {
		try {

			programContainer.SrchTierCreditFromTextBox.clear();
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(programContainer.SrchTierCreditFromTextBox);
			programContainer.SrchTierCreditFromTextBox.sendKeys(roomProgram.getProperty("program.search.customerFromValue"));
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(programContainer.SrchTierCreditToTextBox);
			programContainer.SrchTierCreditToTextBox.clear();
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(programContainer.SrchTierCreditToTextBox);
			programContainer.SrchTierCreditToTextBox.sendKeys(roomProgram.getProperty("program.search.customerToValue"));
			Thread.sleep(3000);
			programContainer.searchProgramName.clear();
			Util.waitTimeElementVisibility(programContainer.searchProgramName);
			programContainer.searchProgramName.sendKeys(programName);
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(programContainer.searchButton);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:searchButton']")).size();
			Assert.assertTrue("Failed, Search Button is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Search Button is present",programContainer.searchButton.isDisplayed());
			//programContainer.searchButton.click(); 
			executor.executeScript("arguments[0].click();",programContainer.searchButton);
			Thread.sleep(3000);
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
	}

/* Manage Programs */

public static void openProgramFeature() {
	try {
		Thread.sleep(15000);
		new WebDriverWait(bd,40).until(ExpectedConditions.visibilityOfElementLocated(By.id("layoutForm:dataTable:0:editButton")));
		//programContainer.editProgramLink.click();
		executor.executeScript("arguments[0].click();", programContainer.editProgramLink);
		Thread.sleep(15000);
		Util.waitTimeElementVisibility(programContainer.expandAll);
		int intTest = bd.findElements(By.xpath("//li[contains(text(),'Expand All')]")).size();
		Assert.assertTrue("Failed, Expand All link is not present",intTest > 0);
		
		//Assert.assertTrue("PASS, Expand All link is present",programContainer.expandAll.isDisplayed());
		//programContainer.expandAll.click();
		executor.executeScript("arguments[0].click();",	programContainer.expandAll);
		Thread.sleep(5000);
	}catch (InterruptedException e) {

		e.printStackTrace();
	}
}
/* Validate Tier Credit Range Label */
public static void valiadteTierCreditRangeLabel(){
	try{
		Thread.sleep(15000);
		Util.waitTimeElementVisibility(programContainer.TierCreditLabel);
		int intTest = bd.findElements(By.xpath("//label[contains(.,'Tier Credit Range') and @class = 'ui-outputlabel']")).size();
		Assert.assertTrue("Failed, TierCredit Label is not present",intTest > 0);
		
		//Assert.assertTrue("PASS, TierCredit Label is present",programContainer.TierCreditLabel.isDisplayed());
	}catch (InterruptedException e) {

		e.printStackTrace();
	}
}
	/*
	 * Create new Program
	 */
/* Set value in Tier credit range text */
public static void setTierCreditRange(String strTierCreditFrom,String strTierCreditTo){
	try{
		Thread.sleep(15000);
		Util.waitTimeElementVisibility(programContainer.TierCreditFromTextBox);
		programContainer.TierCreditFromTextBox.clear();
		programContainer.TierCreditFromTextBox.sendKeys("");
		programContainer.TierCreditFromTextBox.sendKeys(strTierCreditFrom);
		Util.waitTimeElementVisibility(programContainer.TierCreditToTextBox);
		programContainer.TierCreditToTextBox.clear();
		programContainer.TierCreditToTextBox.sendKeys("");
		programContainer.TierCreditToTextBox.sendKeys(strTierCreditTo);
	//	Thread.sleep(500);
	//	Assert.assertEquals(programContainer.TierCreditToTextBox.getText(),strTierCreditTo);
	}catch (InterruptedException e) {

		e.printStackTrace();
	}
}
/* Save Program Manager */
public static void saveProgram(){
	
	
	try{
		Thread.sleep(15000);
		Util.waitTimeElementVisibility(programContainer.saveProgram);
		int intTest = bd.findElements(By.id("layoutForm:saveButton")).size();
		Assert.assertTrue("Failed, Save Program link is not present",intTest > 0);
		
		//Assert.assertTrue("PASS, Save Program link is present",programContainer.saveProgram.isDisplayed());
		//programContainer.saveProgram.click(); 
		executor.executeScript("arguments[0].click();",programContainer.saveProgram);
		
	}catch (InterruptedException e) {

		e.printStackTrace();
	}
}


/*  Validate program saved message */
public static void validateProgramSaveMessage(){
	try{
		Thread.sleep(15000);
		Util.waitTimeElementVisibility(programContainer.ProgramSavedMessage);
		int intTest = bd.findElements(By.xpath("//p[contains(.,'Program/RoomRate Plan Saved')]")).size();
		Assert.assertTrue("Failed, Program Saved Message is not present",intTest > 0);
		//Assert.assertTrue("PASS, Program Saved Message is present",programContainer.ProgramSavedMessage.isDisplayed());
		
	}catch (InterruptedException e) {

		e.printStackTrace();
	}
}
/* Validate Error message- Tier Credit Range To must be greater than or equal to Tier Credit Range From */
public static void validateTierCreditRangeMessage(){
	
	
	try{
		Thread.sleep(15000);
		Util.waitTimeElementVisibility(programContainer.TierRangeErrorMessage);
		LOGGER.info("Validate error message");
		int intTest = bd.findElements(By.xpath("//P[contains(.,'Tier Credit Range \"To\" must be greater than or equal to Tier Credit Range \"From\"!')]")).size();
		Assert.assertTrue("Failed, Tier Range Error Message is not present",intTest > 0);
		
		//Assert.assertTrue("PASS, Tier Range Error Message is present",programContainer.TierRangeErrorMessage.isDisplayed());
		//programContainer.OKTierErrorMessae.click(); 
		executor.executeScript("arguments[0].click();",programContainer.OKTierErrorMessae);
		
	}catch (InterruptedException e) {

		e.printStackTrace();
	}
}

/* validate Tier Credit Range Field Value */
public static void validateTierCreditRangeFieldValue(String strTo,String strFrom){
	try{
		Thread.sleep(15000);
		Util.waitTimeElementVisibility(programContainer.TierCreditFromTextBox);
		//String decimalTierCreditFrom =  "65.25";
		//String decimalTierCreditTo =  "500.64523215";
		
		String SetValueInTierCreditFrom = programContainer.TierCreditFromTextBox.getText();
		String SetValueInTierCreditTo = programContainer.TierCreditToTextBox.getText();
		/*Assert.assertEquals(strTo,SetValueInTierCreditTo);
		Assert.assertEquals(strFrom,SetValueInTierCreditFrom);*/
		
		
		
	}catch (InterruptedException e) {

		e.printStackTrace();
	}
}
/* Set decimal value in Tier credit range text */
public static void setDecimalSplCharTierCreditRange(String decimalTierCreditFrom,String decimalTierCreditTo){
	try{
		Thread.sleep(15000);
		Util.waitTimeElementVisibility(programContainer.TierCreditFromTextBox);
		//String decimalTierCreditFrom =  "65.25";
		//String decimalTierCreditTo =  "500.64523215";
		programContainer.TierCreditFromTextBox.clear();
		programContainer.TierCreditFromTextBox.sendKeys("");
		programContainer.TierCreditFromTextBox.sendKeys(decimalTierCreditFrom);
		Util.waitTimeElementVisibility(programContainer.TierCreditToTextBox);
		programContainer.TierCreditToTextBox.clear();
		programContainer.TierCreditToTextBox.sendKeys("");
		programContainer.TierCreditToTextBox.sendKeys(decimalTierCreditTo);
		Thread.sleep(15000);
		String SetValueInTierCreditFrom = programContainer.TierCreditFromTextBox.getText();
		String SetValueInTierCreditTo = programContainer.TierCreditToTextBox.getText();
		
		Assert.assertNotEquals(decimalTierCreditFrom, SetValueInTierCreditFrom);
		Assert.assertNotEquals(decimalTierCreditTo, SetValueInTierCreditTo);
	}catch (InterruptedException e) {

		e.printStackTrace();
	}
}
	public static void createNewProgram(){
		//Util.waitTimeElementVisibility(programContainer.createProgramLink);
		new WebDriverWait(bd,40).until(ExpectedConditions.visibilityOfElementLocated(By.id("layoutForm:createProgram")));
		//programContainer.createProgramLink.click();
		executor.executeScript("arguments[0].click();", programContainer.createProgramLink);
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void saveNewProgram(){
		
		try {
			Util.waitTimeElementVisibility(programContainer.saveProgram);
			//programContainer.saveProgram.click();
			executor.executeScript("arguments[0].click();",programContainer.saveProgram);
			Thread.sleep(40000);
			if(bd.findElements(By.xpath("//li[contains(text(),'Expand All')]")).size()>0)
			{
				Util.waitTimeElementVisibility(programContainer.expandAll);
				int intTest = bd.findElements(By.xpath("//li[contains(text(),'Expand All')]")).size();
				Assert.assertTrue("Failed, Expand All link is not present",intTest > 0);
				
				//Assert.assertTrue("PASS, Expand All link is present",programContainer.expandAll.isDisplayed());
				//programContainer.expandAll.click(); 
				executor.executeScript("arguments[0].click();",programContainer.expandAll);
				}
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	
	public static void selectCategory(){
		if(programContainer.expandAll.isDisplayed())
		{
			Util.waitTimeElementVisibility(programContainer.expandAll);
			//programContainer.expandAll.click(); 
			executor.executeScript("arguments[0].click();",programContainer.expandAll);
		}
		
		
		Util.waitTimeElementVisibility(programContainer.programCategoryDropDown);
		//programContainer.programCategoryDropDown.click(); 
		executor.executeScript("arguments[0].click();",programContainer.programCategoryDropDown);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectProgramCategory);
	//	programContainer.selectProgramCategory.click();
		executor.executeScript("arguments[0].click();",programContainer.selectProgramCategory);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	

	public static void provideProgramValue(final String programName, final String userProgramId){
		Util.waitTimeElementVisibility(programContainer.programName);
		programContainer.programName.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		LOGGER.info("Program Name: "+programName);
		Util.waitTimeElementVisibility(programContainer.programName);
		programContainer.programName.sendKeys(programName);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		programContainer.userProgramId.clear();
		Util.waitTimeElementVisibility(programContainer.userProgramId);
		programContainer.userProgramId.sendKeys(userProgramId);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.programTag1Input);
		programContainer.programTag1Input.clear();
		Util.waitTimeElementVisibility(programContainer.programTag1Input);
		programContainer.programTag1Input.sendKeys(common.getProperty("common.programTagInput2"));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		//programContainer.selectProgramTag1.click(); 
		executor.executeScript("arguments[0].click();",programContainer.selectProgramTag1);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.tierOption);
		//programContainer.tierOption.click();
		executor.executeScript("arguments[0].click();", programContainer.tierOption);
		
		
		Util.waitTimeElementVisibility(programContainer.tierAdd);
	//	programContainer.tierAdd.click();
		executor.executeScript("arguments[0].click();", programContainer.tierAdd);
		
		try{
			Thread.sleep(3000);	
		} catch (InterruptedException e){
			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.TierCreditFromTextBox);
		programContainer.TierCreditFromTextBox.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
	
			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.TierCreditFromTextBox);
		programContainer.TierCreditFromTextBox.sendKeys(roomProgram.getProperty("program.customerValueFromInput"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
	
			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.TierCreditToTextBox);
		programContainer.TierCreditToTextBox.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
	
			e.printStackTrace();
		}*/
	
		/*Util.waitTimeElementVisibility(programContainer.clickAlertOk);
		programContainer.clickAlertOk.click();*/
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	/*	Util.waitTimeElementVisibility(programContainer.customerValueFromInput);
		programContainer.customerValueFromInput.clear();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
	
			e.printStackTrace();
		}*/
		/*Util.waitTimeElementVisibility(programContainer.customerValueToInput);
		programContainer.customerValueToInput.clear();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
	
			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.TierCreditToTextBox);
		programContainer.TierCreditToTextBox.sendKeys(roomProgram.getProperty("program.customerValueToInput"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
	
			e.printStackTrace();
		}*/
		/*Util.waitTimeElementVisibility(programContainer.saveProgram);
		programContainer.saveProgram.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	/*	Util.waitTimeElementVisibility(programContainer.clickAlertOk);
		programContainer.clickAlertOk.click();*/
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		/*Util.waitTimeElementVisibility(programContainer.customerValueFromInput);
	    programContainer.customerValueFromInput.clear();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
	
			e.printStackTrace();
		}*/
		/*Util.waitTimeElementVisibility(programContainer.customerValueFromInput);
		programContainer.customerValueFromInput.sendKeys(roomProgram.getProperty("program.customerValueFromInput"));*/
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
	
			e.printStackTrace();
		}*/
		/*Util.waitTimeElementVisibility(programContainer.customerValueToInput);
		programContainer.customerValueToInput.clear();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
	
			e.printStackTrace();
		}*/
		/*Util.waitTimeElementVisibility(programContainer.customerValueToInput);
		programContainer.customerValueToInput.sendKeys(roomProgram.getProperty("program.customerValueToInput"));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
	
			e.printStackTrace();
		}*/
		//
		Util.waitTimeElementVisibility(programContainer.reservationTypeDropDown);
		//programContainer.reservationTypeDropDown.click();
		executor.executeScript("arguments[0].click();", programContainer.reservationTypeDropDown);
	/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectProgramReservationType);
		//programContainer.selectProgramReservationType.click();
		executor.executeScript("arguments[0].click();", programContainer.selectProgramReservationType);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.depositRuleDropDown);
		//programContainer.depositRuleDropDown.click();
		executor.executeScript("arguments[0].click();", programContainer.depositRuleDropDown);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectProgramDepositRule);
		//programContainer.selectProgramDepositRule.click();
		executor.executeScript("arguments[0].click();", programContainer.selectProgramDepositRule);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.cancellationPolicyDropDown);
		//programContainer.cancellationPolicyDropDown.click();
		executor.executeScript("arguments[0].click();", programContainer.cancellationPolicyDropDown);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectProgramCancellationPolicy);
		//programContainer.selectProgramCancellationPolicy.click();
		executor.executeScript("arguments[0].click();", programContainer.selectProgramCancellationPolicy);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		//
		Util.waitTimeElementVisibility(programContainer.commissionPercentage);
		programContainer.commissionPercentage.clear();
		programContainer.commissionPercentage.sendKeys(roomProgram.getProperty("program.commissionPercentage"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		LOGGER.info("before programContainer.operaRateCategory.clear()");
		Util.waitTimeElementVisibility(programContainer.operaRateCategory);
		programContainer.operaRateCategory.clear();
		programContainer.operaRateCategory.sendKeys(roomProgram.getProperty("program.operaRateCategory"));
		/*try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		LOGGER.info("before programContainer.selectoperaRateCategory.click()");
		Util.waitTimeElementVisibility(programContainer.selectoperaRateCategory);
		//programContainer.selectoperaRateCategory.click();
		executor.executeScript("arguments[0].click();", programContainer.selectoperaRateCategory);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		//
	}
	
	public static void provideOfferBasicSettingsValue(){
		programContainer.patronPromotionId.clear();
		Util.waitTimeElementVisibility(programContainer.patronPromotionId);
		programContainer.patronPromotionId.sendKeys(roomProgram.getProperty("program.patronPromotionId"));
		/*try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		/*Util.waitTimeElementVisibility(programContainer.selectPatronPromotionId);
		programContainer.selectPatronPromotionId.click();*/
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.publicName);
		programContainer.publicName.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.publicName);
		programContainer.publicName.sendKeys(roomProgram.getProperty("program.invalidPublicName"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.saveProgram);
		//programContainer.saveProgram.click();
		executor.executeScript("arguments[0].click();", programContainer.saveProgram);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.clickAlertOk);
		//programContainer.clickAlertOk.click();
		executor.executeScript("arguments[0].click();", programContainer.clickAlertOk);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.publicName);
		programContainer.publicName.clear();
		Util.waitTimeElementVisibility(programContainer.publicName);
		programContainer.publicName.sendKeys(roomProgram.getProperty("program.publicName"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.maxNightsDropDown);
		//programContainer.maxNightsDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.maxNightsDropDown);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectMaxNights);
		//programContainer.selectMaxNights.click();
		executor.executeScript("arguments[0].click();", programContainer.selectMaxNights);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		/*Util.waitTimeElementVisibility(programContainer.offerForInterestCode);
		programContainer.offerForInterestCode.clear();*/
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		/*Util.waitTimeElementVisibility(programContainer.offerForInterestCode);
		programContainer.offerForInterestCode.sendKeys(roomProgram.getProperty("program.offerForInterestCode"));*/
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.priorityRadio);
		//programContainer.priorityRadio.click();
		executor.executeScript("arguments[0].click();", programContainer.priorityRadio);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.enableBestOffer);
		//programContainer.enableBestOffer.click();
		executor.executeScript("arguments[0].click();", programContainer.enableBestOffer);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.description);
		programContainer.description.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		//save
		Util.waitTimeElementVisibility(programContainer.description);
		programContainer.description.sendKeys("Desc of room");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.saveProgram);
		//programContainer.saveProgram.click();
		executor.executeScript("arguments[0].click();",programContainer.saveProgram);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.clickAlertOk);
		//programContainer.clickAlertOk.click();
		executor.executeScript("arguments[0].click();", programContainer.clickAlertOk);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.description);
		programContainer.description.clear();
	/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.description);
		programContainer.description.sendKeys(roomProgram.getProperty("program.description"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.periodStartDate);
		programContainer.periodStartDate.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.periodStartDate);
		programContainer.periodStartDate.sendKeys(roomProgram.getProperty("program.periodStartDate"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.periodEndDate);
		programContainer.periodEndDate.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.periodEndDate);
		programContainer.periodEndDate.sendKeys(roomProgram.getProperty("program.periodEndDate"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		/*Util.waitTimeElementVisibility(programContainer.valueAddedByManual);
		programContainer.valueAddedByManual.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	
		Util.waitTimeElementVisibility(programContainer.priceByPerDay);
		programContainer.priceByPerDay.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.priceByValueLink);
		programContainer.priceByValueLink.clear();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}		
		Util.waitTimeElementVisibility(programContainer.priceByValueLink);
		programContainer.priceByValueLink.sendKeys(roomProgram.getProperty("program.priceByValueLink"));*/
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}		
		*/
	}

	public static void provideAccessSettingsValue(){
		Util.waitTimeElementVisibility(programContainer.activeCheck);
		//programContainer.activeCheck.click();
		executor.executeScript("arguments[0].click();", programContainer.activeCheck);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.publicCheck);
		//programContainer.publicCheck.click();
		executor.executeScript("arguments[0].click();", programContainer.publicCheck);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.bookableOnlineCheck);
		//programContainer.bookableOnlineCheck.click();
		executor.executeScript("arguments[0].click();", programContainer.bookableOnlineCheck);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.viewOnlineCheck);
		//programContainer.viewOnlineCheck.click();
		executor.executeScript("arguments[0].click();", programContainer.viewOnlineCheck);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		*/
		Util.waitTimeElementVisibility(programContainer.bookableOnPropertySite);
		//programContainer.bookableOnPropertySite.click();
		executor.executeScript("arguments[0].click();", programContainer.bookableOnPropertySite);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.viewOnPropertySite);
		//programContainer.viewOnPropertySite.click();
		executor.executeScript("arguments[0].click();", programContainer.viewOnPropertySite);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	*/
		Util.waitTimeElementVisibility(programContainer.availableInIceCheck);
		//programContainer.availableInIceCheck.click();
		executor.executeScript("arguments[0].click();", programContainer.availableInIceCheck);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void createNewPricingRule(){
		Util.waitTimeElementVisibility(programContainer.createNewPricingOptionLink);
		//programContainer.createNewPricingOptionLink.click();
		executor.executeScript("arguments[0].click();", programContainer.createNewPricingOptionLink);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void backFromCreateNewPricingRule(){
		Util.waitTimeElementVisibility(programContainer.pricingOptionBack);
		//programContainer.pricingOptionBack.click();
		executor.executeScript("arguments[0].click();", programContainer.pricingOptionBack);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void saveCreatedNewPricingRule(){
		
		try {
			Thread.sleep(15000);
			Util.waitTimeElementVisibility(programContainer.pricingOptionSave);
			//programContainer.pricingOptionSave.click();
			executor.executeScript("arguments[0].click();", programContainer.pricingOptionSave);
			
			if(bd.findElements(By.xpath("//li[contains(text(),'Expand All')]")).size()>0)
			{
				Util.waitTimeElementVisibility(programContainer.expandAll);
				int intTest = bd.findElements(By.xpath("//li[contains(text(),'Expand All')]")).size();
				Assert.assertTrue("Failed, Expand All element is not present",intTest > 0);
				
				//Assert.assertTrue("PASS, Expand All element is present",programContainer.expandAll.isDisplayed());
				programContainer.expandAll.click();
				
				}
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		
	}
	
	public static void selectingRIforPricingRule(){
		Util.waitTimeElementVisibility(programContainer.pricingruleRIselect);
		//programContainer.pricingruleRIselect.click();
		executor.executeScript("arguments[0].click();", programContainer.pricingruleRIselect);
		
		Util.waitTimeElementVisibility(programContainer.ActiveRIpricing);
		//programContainer.ActiveRIpricing.click();
		executor.executeScript("arguments[0].click();", programContainer.ActiveRIpricing);
		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void changeCompNightsZero(){
		Util.waitTimeElementVisibility(programContainer.compNightsDropDown);
		//programContainer.compNightsDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.compNightsDropDown);
		
		Util.waitTimeElementVisibility(programContainer.selectCompNightZero);
		//programContainer.selectCompNightZero.click();
		executor.executeScript("arguments[0].click();",programContainer.selectCompNightZero);
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void changeCompNightsNonZero(){
		Util.waitTimeElementVisibility(programContainer.compNightsDropDown);
		//programContainer.compNightsDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.compNightsDropDown);
		
		Util.waitTimeElementVisibility(programContainer.selectCompNights);
		//programContainer.selectCompNights.click();
		executor.executeScript("arguments[0].click();",programContainer.selectCompNights);
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	
	public static void valueForPricingRule(final String startDate, final String endDate, final String discountType, int rand){
		Util.waitTimeElementVisibility(programContainer.activeCheckPricing);
		//programContainer.activeCheckPricing.click();
		executor.executeScript("arguments[0].click();",programContainer.activeCheckPricing);
		
		Util.waitTimeElementVisibility(programContainer.syncToOpera);
		//programContainer.activeCheckPricing.click();
		executor.executeScript("arguments[0].click();",programContainer.syncToOpera);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.parentRateTableDropDown);
		//programContainer.parentRateTableDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.parentRateTableDropDown);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectParentRateTable);
		//programContainer.selectParentRateTable.click();
		executor.executeScript("arguments[0].click();",programContainer.selectParentRateTable);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.pricingFromDate);
		programContainer.pricingFromDate.clear();
		programContainer.pricingFromDate.sendKeys(startDate);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.pricingToDate);
		programContainer.pricingToDate.clear();
		Util.waitTimeElementVisibility(programContainer.pricingToDate);
		programContainer.pricingToDate.sendKeys(endDate);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.checkSunday);
		//programContainer.checkSunday.click();
		executor.executeScript("arguments[0].click();",	programContainer.checkSunday);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.checkTuesday);
		//programContainer.checkTuesday.click();
		executor.executeScript("arguments[0].click();",	programContainer.checkTuesday);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.checkFriday);
		//programContainer.checkFriday.click();
		executor.executeScript("arguments[0].click();",	programContainer.checkFriday);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		
		if(StringUtils.equalsIgnoreCase(discountType, "percentage")) {
			//programContainer.percentageDiscountTypeCheck.click();
			executor.executeScript("arguments[0].click();",	programContainer.percentageDiscountTypeCheck);
			
			
		}else if(StringUtils.equalsIgnoreCase(discountType, "amount")) {
			//programContainer.amountDiscountTypeCheck.click();
			executor.executeScript("arguments[0].click();",programContainer.amountDiscountTypeCheck);
			
		}else{
			//programContainer.flatDiscountTypeCheck.click();
			executor.executeScript("arguments[0].click();",	programContainer.flatDiscountTypeCheck);
			
		}
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.discountValue);
		programContainer.discountValue.clear();
		Util.waitTimeElementVisibility(programContainer.discountValue);
		programContainer.discountValue.sendKeys(roomProgram.getProperty("pricingProgram.discountValue"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.compNightsDropDown);
		//programContainer.compNightsDropDown.click();
		executor.executeScript("arguments[0].click();",	programContainer.compNightsDropDown);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectCompNightZero);
		//programContainer.selectCompNightZero.click();
		executor.executeScript("arguments[0].click();",	programContainer.selectCompNightZero);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	//	Util.waitTimeElementVisibility(programContainer.pricingOperaRateCode);
	//	programContainer.pricingOperaRateCode.clear();
	//	programContainer.pricingOperaRateCode.sendKeys(roomProgram.getProperty("pricingProgram.invalidPricingOperaRateCode"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	//	Util.waitTimeElementVisibility(programContainer.pricingOptionSave);
		//programContainer.pricingOptionSave.click();
	//	executor.executeScript("arguments[0].click();",	programContainer.pricingOptionSave);
		
		/*try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	//	Util.waitTimeElementVisibility(programContainer.pricingOptionSave);
		//programContainer.clickAlertOk.click();
	//	executor.executeScript("arguments[0].click();",	programContainer.clickAlertOk);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.pricingOperaRateCode);
		programContainer.pricingOperaRateCode.clear();
		String appendStr = rand != 0?String.valueOf(rand):"";
		Util.waitTimeElementVisibility(programContainer.pricingOperaRateCode);
		programContainer.pricingOperaRateCode.sendKeys(roomProgram.getProperty("pricingProgram.pricingOperaRateCode")+appendStr);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.marketCode);
		programContainer.marketCode.clear();
		Util.waitTimeElementVisibility(programContainer.marketCode);
		programContainer.marketCode.sendKeys(roomProgram.getProperty("pricingProgram.marketCode"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectMarketCode);
		//programContainer.selectMarketCode.click();
		executor.executeScript("arguments[0].click();",	programContainer.selectMarketCode);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.sourceCode);
		programContainer.sourceCode.clear();
		Util.waitTimeElementVisibility(programContainer.sourceCode);
		programContainer.sourceCode.sendKeys(roomProgram.getProperty("pricingProgram.sourceCode"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectSourceCode);
	//	programContainer.selectSourceCode.click();
		executor.executeScript("arguments[0].click();",	programContainer.selectSourceCode);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		//Util.waitTimeElementVisibility(programContainer.packageName);
	//	programContainer.packageName.clear();
	//	Util.waitTimeElementVisibility(programContainer.packageName);
	//	programContainer.packageName.sendKeys(roomProgram.getProperty("pricingProgram.packageName"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	//	Util.waitTimeElementVisibility(programContainer.selectPackageName);
		//programContainer.selectPackageName.click();
	//	executor.executeScript("arguments[0].click();",	programContainer.selectPackageName);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void createNewRoutingInstruction(){
		Util.waitTimeElementVisibility(programContainer.createNewRoutingInstructionsLink);
		//programContainer.createNewRoutingInstructionsLink.click();
		executor.executeScript("arguments[0].click();",programContainer.createNewRoutingInstructionsLink);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	
	public static void backFromCreateNewRoutingInstruction(){
		Util.waitTimeElementVisibility(programContainer.routingInstructionsBack);
		//programContainer.routingInstructionsBack.click();
		executor.executeScript("arguments[0].click();",programContainer.routingInstructionsBack);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void saveCreatedNewRoutingInstruction(){
		Util.waitTimeElementVisibility(programContainer.routingInstructionsSave);
		//programContainer.routingInstructionsSave.click();
		executor.executeScript("arguments[0].click();",programContainer.routingInstructionsSave);
		
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		if(bd.findElements(By.xpath("//li[contains(text(),'Expand All')]")).size()>0)
		{
			Util.waitTimeElementVisibility(programContainer.expandAll);
			programContainer.expandAll.click();
			}
	}
	
	 public static void activeCheckPricing() {
		Util.waitTimeElementVisibility(programContainer.activeCheckPricing);
		//programContainer.activeCheckPricing.click();
		executor.executeScript("arguments[0].click();",programContainer.activeCheckPricing);
		
		
	 }
	
	
	
	public static void valueForRoutingInstruction(){
		Util.waitTimeElementVisibility(programContainer.routingInstructionsName);
		programContainer.routingInstructionsName.clear();
		Util.waitTimeElementVisibility(programContainer.routingInstructionsName);
		programContainer.routingInstructionsName.sendKeys("TEST ROUTING OPTIONS");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.routingTypeDropDown);
		//programContainer.routingTypeDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.routingTypeDropDown);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectRoutingType);
		//programContainer.selectRoutingType.click();
		executor.executeScript("arguments[0].click();",programContainer.selectRoutingType);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.authorizer);
		programContainer.authorizer.clear();
		Util.waitTimeElementVisibility(programContainer.authorizer);
		programContainer.authorizer.sendKeys("Alan Feldman");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectAuthorizer);
		//programContainer.selectAuthorizer.click();
		executor.executeScript("arguments[0].click();",programContainer.selectAuthorizer);
		
		/*try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.receiverId);
		programContainer.receiverId.clear();
		programContainer.receiverId.sendKeys("12345678");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.routingInstructionsActiveCheck);
		//programContainer.routingInstructionsActiveCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.routingInstructionsActiveCheck);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.checkSundayRI);
		//programContainer.checkSundayRI.click();
		executor.executeScript("arguments[0].click();",programContainer.checkSundayRI);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.checkTuesdayRI);
		//programContainer.checkTuesdayRI.click();
		executor.executeScript("arguments[0].click();",programContainer.checkTuesdayRI);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.checkFridayRI);
		//programContainer.checkFridayRI.click();
		executor.executeScript("arguments[0].click();",programContainer.checkFridayRI);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.checkSaturdayRI);
		//programContainer.checkSaturdayRI.click();
		executor.executeScript("arguments[0].click();",programContainer.checkSaturdayRI);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.DailyYNCheck);
		//programContainer.DailyYNCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.DailyYNCheck);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.maxCompNightsDropDown);
		//programContainer.maxCompNightsDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.maxCompNightsDropDown);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectMaxCompNights);
		//programContainer.selectMaxCompNights.click();
		executor.executeScript("arguments[0].click();",programContainer.selectMaxCompNights);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectRoutingCodes);
		//programContainer.selectRoutingCodes.click();
		executor.executeScript("arguments[0].click();",programContainer.selectRoutingCodes);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.activateRoutingCodes);
		//programContainer.activateRoutingCodes.click();
		executor.executeScript("arguments[0].click();",programContainer.activateRoutingCodes);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.routingLimitTypeDropDown);
		//programContainer.routingLimitTypeDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.routingLimitTypeDropDown);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectRoutingLimitType);
		//programContainer.selectRoutingLimitType.click();
		executor.executeScript("arguments[0].click();",	programContainer.selectRoutingLimitType);

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.routingLimit);
		programContainer.routingLimit.clear();
		Util.waitTimeElementVisibility(programContainer.routingLimit);
		programContainer.routingLimit.sendKeys("3");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.routingCompOrCoupon);
		programContainer.routingCompOrCoupon.clear();
		Util.waitTimeElementVisibility(programContainer.routingCompOrCoupon);
		programContainer.routingCompOrCoupon.sendKeys("1234567");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectRoutingCategories);
	//	programContainer.selectRoutingCategories.click();
		executor.executeScript("arguments[0].click();",	programContainer.selectRoutingCategories);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.activateRoutingCategories);
		//programContainer.activateRoutingCategories.click();
		executor.executeScript("arguments[0].click();",programContainer.activateRoutingCategories);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void providePromotionOrInclusionValue(){
		/*Util.waitTimeElementVisibility(programContainer.expandAll);
		programContainer.expandAll.click();*/
		Util.waitTimeElementVisibility(programContainer.promotionCode);
		programContainer.promotionCode.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.promotionCode);
		programContainer.promotionCode.sendKeys(roomProgram.getProperty("program.promotionCode")+getRandomNumber());
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.promoGroupDropDown);
		//programContainer.promoGroupDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.promoGroupDropDown);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectPromoGroup);
		//programContainer.selectPromoGroup.click();
		executor.executeScript("arguments[0].click();",programContainer.selectPromoGroup);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}*/
	}
	
	public static void provideDateRestrictionValue(){
		Util.waitTimeElementVisibility(programContainer.bookByDate);
		programContainer.bookByDate.clear();
		Util.waitTimeElementVisibility(programContainer.bookByDate);
		programContainer.bookByDate.sendKeys(roomProgram.getProperty("program.bookByDate"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	*/	
		BrowserDriver.getCurrentDriver().switchTo().frame(BrowserDriver.getCurrentDriver().findElement(By.id("layoutForm:termsAndConditions_iframe"))); //any locator
		((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML='©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™" 
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™" 
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™" 
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™" 
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "©®™â©®™â©®™â©®™â©®™â©®™â©"
				+"'");

		BrowserDriver.getCurrentDriver().switchTo().defaultContent();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.saveProgram);
		//programContainer.saveProgram.click();
		executor.executeScript("arguments[0].click();",programContainer.saveProgram);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.clickAlertOk);
		//programContainer.clickAlertOk.click();
		executor.executeScript("arguments[0].click();",programContainer.clickAlertOk);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
*/
		BrowserDriver.getCurrentDriver().switchTo().frame(BrowserDriver.getCurrentDriver().findElement(By.id("layoutForm:termsAndConditions_iframe"))); //any locator
		((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML='Cucumber Terms and conditions'");

		BrowserDriver.getCurrentDriver().switchTo().defaultContent();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void provideMinimumNoOfNightsValue() {
		
		
			//Thread.sleep(20000);
			Util.waitTimeElementVisibility(programContainer.hasToStayCheck);
			//programContainer.hasToStayCheck.click();
			executor.executeScript("arguments[0].click();",programContainer.hasToStayCheck);

			Util.waitTimeElementVisibility(programContainer.minSatyNightsDropDown);
			//programContainer.minSatyNightsDropDown.click();
			executor.executeScript("arguments[0].click();",programContainer.minSatyNightsDropDown);

			//Util.waitTimeElementVisibility(programContainer.selectMinSatyNights);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:minNights_panel']/div/ul/li[3]")).size();
			Assert.assertTrue("Failed, Select Min Saty Nights element is not present",intTest > 0);
			/*try {
				Assert.assertTrue("Failed, Select Min Saty Nights elemrnt is not present",programContainer.selectMinSatyNights.isDisplayed());
		    }
		    catch (AssertionError e) {
		        Assert.fail("Test Failed:Select Min Saty Nights element is not present" + e.getMessage());
		    }*/
			
			//Assert.assertTrue("PASS, Select Min Saty Nights elemrnt is present",programContainer.selectMinSatyNights.isDisplayed());
			//programContainer.selectMinSatyNights.click();
			executor.executeScript("arguments[0].click();",programContainer.selectMinSatyNights);

		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void provideAdvanceBookingValue(){
		Util.waitTimeElementVisibility(programContainer.hasToBookInAdvanceCheck);
		//programContainer.hasToBookInAdvanceCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.hasToBookInAdvanceCheck);

		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		//Util.waitTimeElementVisibility(programContainer.minDaysInAdvanceDropDown);
		//programContainer.minDaysInAdvanceDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.minDaysInAdvanceDropDown);

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		//Util.waitTimeElementVisibility(programContainer.selectMinDaysInAdvance);
		//new WebDriverWait(bd,40).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='layoutForm:minNights_panel']/div/ul/li[3]")));
		//programContainer.selectMinDaysInAdvance.click();
		executor.executeScript("arguments[0].click();",programContainer.selectMinDaysInAdvance);

		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void provideSelectPlayerTierValue(){
		Util.waitTimeElementVisibility(programContainer.specificTireCheck);
		//programContainer.specificTireCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.specificTireCheck);

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.minHoursAfterEnrollmentDropDown);
		//programContainer.minHoursAfterEnrollmentDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.minHoursAfterEnrollmentDropDown);

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.selectMinHoursAfterEnrollment);
		//programContainer.selectMinHoursAfterEnrollment.click();
		executor.executeScript("arguments[0].click();",programContainer.selectMinHoursAfterEnrollment);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void provideNotesValue(){
		BrowserDriver.getCurrentDriver().switchTo().frame(BrowserDriver.getCurrentDriver().findElement(By.id("layoutForm:agentsText_iframe"))); //any locator
		((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML='©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™" 
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™" 
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™" 
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™" 
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "©®™â©®™â©®™â©®™â©®™â©®™â©"
				+"'");

		BrowserDriver.getCurrentDriver().switchTo().defaultContent();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.saveProgram);
		//programContainer.saveProgram.click();
		executor.executeScript("arguments[0].click();",programContainer.saveProgram);

	/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.clickAlertOk);
		//programContainer.clickAlertOk.click();
		executor.executeScript("arguments[0].click();",programContainer.clickAlertOk);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/

		BrowserDriver.getCurrentDriver().switchTo().frame(BrowserDriver.getCurrentDriver().findElement(By.id("layoutForm:agentsText_iframe"))); //any locator
		((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML='Cucumber Agents Text'");

		BrowserDriver.getCurrentDriver().switchTo().defaultContent();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void provideSelectPaymentTypeValue(){
		Util.waitTimeElementVisibility(programContainer.inActivatePaymentType);
		//programContainer.inActivatePaymentType.click();
		executor.executeScript("arguments[0].click();",programContainer.inActivatePaymentType);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectPaymentTypeCheck);
		//programContainer.selectPaymentTypeCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.selectPaymentTypeCheck);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectPaymentType);
		//programContainer.selectPaymentType.click();
		executor.executeScript("arguments[0].click();",programContainer.selectPaymentType);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.activatePaymentType);
		//programContainer.activatePaymentType.click();
		executor.executeScript("arguments[0].click();",programContainer.activatePaymentType);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void checkIfAssociateRoomsValueExistsORNot(){
		try{
			WebElement select = BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:roomPickList2']/tbody/tr/td/ul"));
			List<WebElement> options = select.findElements(By.tagName("li"));
	        if(options.size()>1)
	        {
	        	provideAssociateRoomsValue();				
	        }	
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void checkIfAssociateRoomsSyncValueExistsORNot(){
		try{
			WebElement select = BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:syncRoomsPickList']/tbody/tr/td/ul"));
			List<WebElement> options = select.findElements(By.tagName("li"));
	        if(options.size()>1)
	        {
	        	provideAssociateRoomsSyncValue();				
	        }	
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void provideAssociateRoomsValue(){
		Util.waitTimeElementVisibility(programContainer.selectAssociateRooms);
	//	programContainer.selectAssociateRooms.click();
		executor.executeScript("arguments[0].click();",programContainer.selectAssociateRooms);

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.activateAssociateRooms);
	//	programContainer.activateAssociateRooms.click();
		executor.executeScript("arguments[0].click();",programContainer.activateAssociateRooms);

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void provideAssociateRoomsSyncValue(){
		Util.waitTimeElementVisibility(programContainer.selectAssociateSyncRooms);
	//	programContainer.selectAssociateRooms.click();
		executor.executeScript("arguments[0].click();",programContainer.selectAssociateSyncRooms);

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.activateAssociateSyncRooms);
	//	programContainer.activateAssociateRooms.click();
		executor.executeScript("arguments[0].click();",programContainer.activateAssociateSyncRooms);

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void searchName(final String pricingProgramName) {
		try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.searchName);
		//programContainer.searchName.click();
		executor.executeScript("arguments[0].click();",programContainer.searchName);

		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.searchName);
		
		int intTest = bd.findElements(By.id("layoutForm:dataTable:Name:filter")).size();
		Assert.assertTrue("Failed, Search Name element is not present",intTest > 0);
		
		//Assert.assertTrue("PASS, Search Name element is present",programContainer.searchName.isDisplayed());
		programContainer.searchName.sendKeys(pricingProgramName);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	public static void editProgram() {
		Util.waitTimeElementVisibility(programContainer.editPricingProgramLink);
		//programContainer.editPricingProgramLink.click();
		executor.executeScript("arguments[0].click();",programContainer.editPricingProgramLink);

		Util.waitTimeElementVisibility(programContainer.expandAll);
		int intTest = bd.findElements(By.xpath("//li[contains(text(),'Expand All')]")).size();
		Assert.assertTrue("Failed, ExpandAll element is not present",intTest > 0);
		
		//Assert.assertTrue("PASS, ExpandAll element is present",programContainer.expandAll.isDisplayed());
		programContainer.expandAll.click();
		/*try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}*/
		}
	
	
	public static void inactiveAccessSettingsValue() {
		Util.waitTimeElementVisibility(programContainer.activeCheck);
		//programContainer.activeCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.activeCheck);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}


	public static void activeAccessSettingsValue() {
		Util.waitTimeElementVisibility(programContainer.activeCheck);
		//programContainer.activeCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.activeCheck);

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}

	
	
	/*
	 * Edit Program
	 */
	
	public static void selectInactiveActiveAll(){
		Util.waitTimeElementVisibility(programContainer.selectInactivePrograms);
		//programContainer.selectInactivePrograms.click();
		executor.executeScript("arguments[0].click();",programContainer.selectInactivePrograms);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectActivePrograms);
	//	programContainer.selectActivePrograms.click();
		executor.executeScript("arguments[0].click();",programContainer.selectActivePrograms);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectAllPrograms);
		//programContainer.selectAllPrograms.click();
		executor.executeScript("arguments[0].click();",programContainer.selectAllPrograms);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void editProgramLink(){
		//Util.waitTimeElementVisibility(programContainer.editProgramLink);
		new WebDriverWait(bd,40).until(ExpectedConditions.visibilityOfElementLocated(By.id("layoutForm:dataTable:0:editButton")));
	//	programContainer.editProgramLink.click();
		executor.executeScript("arguments[0].click();", programContainer.editProgramLink);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void editPricingOptionLink(){
		Util.waitTimeElementVisibility(programContainer.editPricingOption);
		//programContainer.editPricingOption.click();
		executor.executeScript("arguments[0].click();",programContainer.editPricingOption);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void editRoutingInstructionsLink(){
		Util.waitTimeElementVisibility(programContainer.editRoutingInstructions);
	//	programContainer.editRoutingInstructions.click();
		executor.executeScript("arguments[0].click();",programContainer.editRoutingInstructions);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void selectCategoryEdit(){
		Util.waitTimeElementVisibility(programContainer.programCategoryDropDown);
		//programContainer.programCategoryDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.programCategoryDropDown);

		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectProgramCategoryEdit);
	//	programContainer.selectProgramCategoryEdit.click();
		executor.executeScript("arguments[0].click();",programContainer.selectProgramCategoryEdit);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void provideProgramValueEdit(){
		Util.waitTimeElementVisibility(programContainer.programTag1Input);
		programContainer.programTag1Input.clear();
		Util.waitTimeElementVisibility(programContainer.programTag1Input);
		programContainer.programTag1Input.sendKeys("TAG1");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectProgramTag1);
		//programContainer.selectProgramTag1.click();
		executor.executeScript("arguments[0].click();",programContainer.selectProgramTag1);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.addProgramTagButton);
		//programContainer.addProgramTagButton.click(); 
		executor.executeScript("arguments[0].click();",programContainer.addProgramTagButton);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.addProgramTagButton);
		//programContainer.addProgramTagButton.click(); 
		executor.executeScript("arguments[0].click();",programContainer.addProgramTagButton);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.programTag1Input2);
		programContainer.programTag1Input2.clear();
		Util.waitTimeElementVisibility(programContainer.programTag1Input2);
		programContainer.programTag1Input2.sendKeys("TAG2");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectProgramTag2);
		//programContainer.selectProgramTag2.click();
		executor.executeScript("arguments[0].click();",programContainer.selectProgramTag2);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.deleteProgramTag3Button);
		//programContainer.deleteProgramTag3Button.click(); 
		executor.executeScript("arguments[0].click();",programContainer.deleteProgramTag3Button);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.reservationTypeDropDown);
		//programContainer.reservationTypeDropDown.click(); 
		executor.executeScript("arguments[0].click();",programContainer.reservationTypeDropDown);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectProgramReservationType);
		//programContainer.selectProgramReservationType.click(); 
		executor.executeScript("arguments[0].click();",programContainer.selectProgramReservationType);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.depositRuleDropDown);
		//programContainer.depositRuleDropDown.click(); 
		executor.executeScript("arguments[0].click();",programContainer.depositRuleDropDown);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectProgramDepositRule);
		//programContainer.selectProgramDepositRule.click(); 
		executor.executeScript("arguments[0].click();",programContainer.selectProgramDepositRule);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.cancellationPolicyDropDown);
		//programContainer.cancellationPolicyDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.cancellationPolicyDropDown);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectProgramCancellationPolicy);
		//programContainer.selectProgramCancellationPolicy.click();
		executor.executeScript("arguments[0].click();",programContainer.selectProgramCancellationPolicy);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.commissionPercentage);
		programContainer.commissionPercentage.clear();
		Util.waitTimeElementVisibility(programContainer.commissionPercentage);
		programContainer.commissionPercentage.sendKeys("5");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.operaRateCategory);
		programContainer.operaRateCategory.clear();
		Util.waitTimeElementVisibility(programContainer.operaRateCategory);
		programContainer.operaRateCategory.sendKeys("CASH");
		/*try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectoperaRateCategory);
		//programContainer.selectoperaRateCategory.click();
		executor.executeScript("arguments[0].click();",programContainer.selectoperaRateCategory);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void provideOfferBasicSettingsValueEdit(){
		Util.waitTimeElementVisibility(programContainer.patronPromotionId);
		programContainer.patronPromotionId.clear();
		Util.waitTimeElementVisibility(programContainer.patronPromotionId);
		programContainer.patronPromotionId.sendKeys("103960");
		/*try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectPatronPromotionId);
		//programContainer.selectPatronPromotionId.click();
		executor.executeScript("arguments[0].click();",programContainer.selectPatronPromotionId);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.publicName);
		programContainer.publicName.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.saveProgram);
		//programContainer.saveProgram.click();
		executor.executeScript("arguments[0].click();",programContainer.saveProgram);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.publicName);
		programContainer.publicName.sendKeys(roomProgram.getProperty("program.EditPublicName"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.maxNightsDropDown);
		//programContainer.maxNightsDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.maxNightsDropDown);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectMaxNights);
		//programContainer.selectMaxNights.click(); 
		executor.executeScript("arguments[0].click();",programContainer.selectMaxNights);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.offerForInterestCode);
		programContainer.offerForInterestCode.clear();
		Util.waitTimeElementVisibility(programContainer.offerForInterestCode);
		programContainer.offerForInterestCode.sendKeys(roomProgram.getProperty("program.EditOfferForInterestCode"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.priorityRadio);
		//programContainer.priorityRadio.click();
		executor.executeScript("arguments[0].click();",programContainer.priorityRadio);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.enableBestOffer);
		//programContainer.enableBestOffer.click();
		executor.executeScript("arguments[0].click();",programContainer.enableBestOffer);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.description);
		programContainer.description.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.saveProgram);
		//programContainer.saveProgram.click();
		executor.executeScript("arguments[0].click();",programContainer.saveProgram);
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.clickAlertOk);
		//programContainer.clickAlertOk.click();
		executor.executeScript("arguments[0].click();",programContainer.clickAlertOk);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.description);
		programContainer.description.sendKeys(roomProgram.getProperty("program.description"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.periodStartDate);
		programContainer.periodStartDate.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.saveProgram);
		//programContainer.saveProgram.click();
		executor.executeScript("arguments[0].click();",programContainer.saveProgram);
	/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.periodStartDate);
		programContainer.periodStartDate.sendKeys(roomProgram.getProperty("program.periodStartDate"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.periodEndDate);
		programContainer.periodEndDate.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.saveProgram);
		//programContainer.saveProgram.click(); 
		executor.executeScript("arguments[0].click();",programContainer.saveProgram);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.clickAlertOk);
		//programContainer.clickAlertOk.click();
		executor.executeScript("arguments[0].click();",programContainer.clickAlertOk);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.periodEndDate);
		programContainer.periodEndDate.sendKeys(roomProgram.getProperty("program.periodEndDate"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.valueAddedByNone);
		//programContainer.valueAddedByNone.click();
		executor.executeScript("arguments[0].click();",programContainer.valueAddedByNone);
	/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	*/
		
	}
	
	public static void provideAccessSettingsValueEdit(){
		Util.waitTimeElementVisibility(programContainer.publicCheck);
		//programContainer.publicCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.publicCheck);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.bookableOnlineCheck);
		//programContainer.bookableOnlineCheck.click(); 
		executor.executeScript("arguments[0].click();",programContainer.bookableOnlineCheck);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.viewOnlineCheck);
		//programContainer.viewOnlineCheck.click(); 
		executor.executeScript("arguments[0].click();",programContainer.viewOnlineCheck);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void valueForPricingOptionEdit(){
		Util.waitTimeElementVisibility(programContainer.activeCheckPricing);
		//programContainer.activeCheckPricing.click();
		executor.executeScript("arguments[0].click();",programContainer.activeCheckPricing);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.parentRateTableDropDown);
		programContainer.parentRateTableDropDown.click(); 
		//executor.executeScript("arguments[0].click();",programContainer.parentRateTableDropDown);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectParentRateTableEdit);
		//programContainer.selectParentRateTableEdit.click();
		executor.executeScript("arguments[0].click();",programContainer.selectParentRateTableEdit);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.pricingFromDate);
		programContainer.pricingFromDate.clear();
		Util.waitTimeElementVisibility(programContainer.pricingFromDate);
		programContainer.pricingFromDate.sendKeys("11/01/2014");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.pricingToDate);
		programContainer.pricingToDate.clear();
		Util.waitTimeElementVisibility(programContainer.pricingToDate);
		programContainer.pricingToDate.sendKeys("11/10/2014");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.checkSunday);
		//programContainer.checkSunday.click(); 
		executor.executeScript("arguments[0].click();",programContainer.checkSunday);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.checkTuesday);
		//programContainer.checkTuesday.click();
		executor.executeScript("arguments[0].click();",programContainer.checkTuesday);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.checkWednesday);
		//programContainer.checkWednesday.click(); 
		executor.executeScript("arguments[0].click();",programContainer.checkWednesday);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.percentageDiscountTypeCheck);
		//programContainer.percentageDiscountTypeCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.percentageDiscountTypeCheck);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.discountValue);
		programContainer.discountValue.clear();
		programContainer.discountValue.sendKeys(roomProgram.getProperty("program.discountValue"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.compNightsDropDown);
		//programContainer.compNightsDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.compNightsDropDown);
	/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectCompNights);
		//programContainer.selectCompNights.click(); 
		executor.executeScript("arguments[0].click();",programContainer.selectCompNights);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.pricingOperaRateCode);
		programContainer.pricingOperaRateCode.clear();
		Util.waitTimeElementVisibility(programContainer.pricingOperaRateCode);
		programContainer.pricingOperaRateCode.sendKeys(roomProgram.getProperty("program.pricingOperaRateCode"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.marketCode);
		programContainer.marketCode.clear();
		Util.waitTimeElementVisibility(programContainer.marketCode);
		programContainer.marketCode.sendKeys(roomProgram.getProperty("pricingProgram.marketCode"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectMarketCode);
		//programContainer.selectMarketCode.click(); 
		executor.executeScript("arguments[0].click();",programContainer.selectMarketCode);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.sourceCode);
		programContainer.sourceCode.clear();
		Util.waitTimeElementVisibility(programContainer.sourceCode);
		programContainer.sourceCode.sendKeys(roomProgram.getProperty("pricingProgram.sourceCode"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectSourceCode);
		//programContainer.selectSourceCode.click();
		executor.executeScript("arguments[0].click();",programContainer.selectSourceCode);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void valueForRoutingInstructionEdit(){
		Util.waitTimeElementVisibility(programContainer.routingInstructionsName);
		programContainer.routingInstructionsName.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.routingInstructionsSave);
		//programContainer.routingInstructionsSave.click();
		executor.executeScript("arguments[0].click();",programContainer.routingInstructionsSave);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.routingInstructionsName);
		programContainer.routingInstructionsName.sendKeys("TEST ROUTING 1");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.routingTypeDropDown);
		//programContainer.routingTypeDropDown.click(); 
		executor.executeScript("arguments[0].click();",programContainer.routingTypeDropDown);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectRoutingType);
		//programContainer.selectRoutingType.click();
		executor.executeScript("arguments[0].click();",programContainer.selectRoutingType);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.authorizer);
		programContainer.authorizer.clear();
		Util.waitTimeElementVisibility(programContainer.authorizer);
		programContainer.authorizer.sendKeys("Alan Feldman");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectAuthorizer);
		//programContainer.selectAuthorizer.click();
		executor.executeScript("arguments[0].click();",programContainer.selectAuthorizer);
		/*try {
			Thread.sleep(240000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.receiverId);
		programContainer.receiverId.clear();
		Util.waitTimeElementVisibility(programContainer.receiverId);
		programContainer.receiverId.sendKeys("34567812");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.routingInstructionsActiveCheck);
		//programContainer.routingInstructionsActiveCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.routingInstructionsActiveCheck);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.checkFridayRI);
		//programContainer.checkFridayRI.click();
		executor.executeScript("arguments[0].click();",programContainer.checkFridayRI);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.checkSaturdayRI);
		//programContainer.checkSaturdayRI.click(); 
		executor.executeScript("arguments[0].click();",programContainer.checkSaturdayRI);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.DailyYNCheck);
		//programContainer.DailyYNCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.DailyYNCheck);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.maxCompNightsDropDown);
		//programContainer.maxCompNightsDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.maxCompNightsDropDown);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectMaxCompNightsEdit);
		//programContainer.selectMaxCompNightsEdit.click();
		executor.executeScript("arguments[0].click();",programContainer.selectMaxCompNightsEdit);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectRoutingCodesEdit);
		//programContainer.selectRoutingCodesEdit.click(); 
		executor.executeScript("arguments[0].click();",programContainer.selectRoutingCodesEdit);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.activateRoutingCodes);
		//programContainer.activateRoutingCodes.click();
		executor.executeScript("arguments[0].click();",programContainer.activateRoutingCodes);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.routingLimitTypeDropDown);
		//programContainer.routingLimitTypeDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.routingLimitTypeDropDown);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectRoutingLimitTypeEdit);
		//programContainer.selectRoutingLimitTypeEdit.click();
		executor.executeScript("arguments[0].click();",programContainer.selectRoutingLimitTypeEdit);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.routingPercent);
		programContainer.routingPercent.clear();
		Util.waitTimeElementVisibility(programContainer.routingPercent);
		programContainer.routingPercent.sendKeys("5");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.routingCompOrCoupon);
		programContainer.routingCompOrCoupon.clear();
		programContainer.routingCompOrCoupon.sendKeys("3456788");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectRoutingCategories);
		//programContainer.selectRoutingCategories.click();
		executor.executeScript("arguments[0].click();",programContainer.selectRoutingCategories);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.activateRoutingCategories);
		//programContainer.activateRoutingCategories.click();
		executor.executeScript("arguments[0].click();",programContainer.activateRoutingCategories);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void providePromotionOrInclusionValueEdit(){
		Util.waitTimeElementVisibility(programContainer.promotionCode);
		programContainer.promotionCode.clear();
		Util.waitTimeElementVisibility(programContainer.promotionCode);
		programContainer.promotionCode.sendKeys("TESTPC2");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.operaGuaranteeCodeDropDown);
		//programContainer.operaGuaranteeCodeDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.operaGuaranteeCodeDropDown);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectOperaGuaranteeCode);
		//programContainer.selectOperaGuaranteeCode.click(); 
		executor.executeScript("arguments[0].click();",programContainer.selectOperaGuaranteeCode);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void provideDateRestrictionValueEdit(){
		Util.waitTimeElementVisibility(programContainer.travelPeriodStartDate);
		programContainer.travelPeriodStartDate.clear();
		Util.waitTimeElementVisibility(programContainer.travelPeriodStartDate);
		programContainer.travelPeriodStartDate.sendKeys("11/01/2014");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.travelPeriodEndDate);
		programContainer.travelPeriodEndDate.clear();
		Util.waitTimeElementVisibility(programContainer.travelPeriodEndDate);
		programContainer.travelPeriodEndDate.sendKeys("11/10/2014");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.checkSundayRI);
		//programContainer.checkSundayRI.click();
		executor.executeScript("arguments[0].click();",programContainer.checkSundayRI);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.checkTuesdayRI);
		//programContainer.checkTuesdayRI.click(); 
		executor.executeScript("arguments[0].click();",programContainer.checkTuesdayRI);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.checkFridayRI);
		//programContainer.checkFridayRI.click();
		executor.executeScript("arguments[0].click();",programContainer.checkFridayRI);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.checkSaturdayRI);
		//programContainer.hasToStayCheck.click(); 
		executor.executeScript("arguments[0].click();",programContainer.hasToStayCheck);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.bookByDate);
		programContainer.bookByDate.clear();
		Util.waitTimeElementVisibility(programContainer.bookByDate);
		programContainer.bookByDate.sendKeys("11/01/2014");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void provideMinimumNoOfNightsValueEdit(){
		Util.waitTimeElementVisibility(programContainer.hasToStayCheck);
		//programContainer.hasToStayCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.hasToStayCheck);
		/*try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.minSatyNightsDropDown);
		//programContainer.minSatyNightsDropDown.click(); 
		executor.executeScript("arguments[0].click();",programContainer.minSatyNightsDropDown);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectMinSatyNightsEdit);
		//programContainer.selectMinSatyNightsEdit.click();
		executor.executeScript("arguments[0].click();",programContainer.selectMinSatyNightsEdit);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void provideAdvanceBookingValueEdit(){
		Util.waitTimeElementVisibility(programContainer.hasToBookInAdvanceCheck);
		//programContainer.hasToBookInAdvanceCheck.click(); 
		executor.executeScript("arguments[0].click();",programContainer.hasToBookInAdvanceCheck);
		/*try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.minDaysInAdvanceDropDown);
		//programContainer.minDaysInAdvanceDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.minDaysInAdvanceDropDown);
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.selectMinDaysInAdvanceEdit);
		//programContainer.selectMinDaysInAdvanceEdit.click();
		executor.executeScript("arguments[0].click();",programContainer.selectMinDaysInAdvanceEdit);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void provideSelectPlayerTierValueEdit(){
		Util.waitTimeElementVisibility(programContainer.specificTireCheck);
		//programContainer.specificTireCheck.click(); 
		executor.executeScript("arguments[0].click();",programContainer.specificTireCheck);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.minHoursAfterEnrollmentDropDown);
		//programContainer.minHoursAfterEnrollmentDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.minHoursAfterEnrollmentDropDown);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectMinHoursAfterEnrollmentEdit);
		//programContainer.selectMinHoursAfterEnrollmentEdit.click(); 
		executor.executeScript("arguments[0].click();",programContainer.selectMinHoursAfterEnrollmentEdit);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.tierInactiveSearch);
		programContainer.tierInactiveSearch.sendKeys("Platinum");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectTierEdit);
		//programContainer.selectTierEdit.click();
		executor.executeScript("arguments[0].click();",programContainer.selectTierEdit);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.activateTier);
		//programContainer.activateTier.click();
		executor.executeScript("arguments[0].click();",programContainer.activateTier);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void provideSelectPaymentTypeValueEdit(){
		Util.waitTimeElementVisibility(programContainer.selectPaymentTypeCheck);
		//programContainer.selectPaymentTypeCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.selectPaymentTypeCheck);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectPaymentType);
		//programContainer.selectPaymentType.click(); 
		executor.executeScript("arguments[0].click();",programContainer.selectPaymentType);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.activatePaymentType);
		//programContainer.activatePaymentType.click();
		executor.executeScript("arguments[0].click();",programContainer.activatePaymentType);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void provideAssociateRoomsValueEdit(){
		Util.waitTimeElementVisibility(programContainer.selectAssociateRoomsEdit);
		//programContainer.selectAssociateRoomsEdit.click(); 
		executor.executeScript("arguments[0].click();",programContainer.selectAssociateRoomsEdit);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.activateAssociateRooms);
		//programContainer.activateAssociateRooms.click();
		executor.executeScript("arguments[0].click();",programContainer.activateAssociateRooms);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void deletePricingOptionLink(){
		Util.waitTimeElementVisibility(programContainer.deletePricingRule);
		int intTest = bd.findElements(By.id("layoutForm:priceRuleDTOList:0:deletePricingRule")).size();
		Assert.assertTrue("Failed, Delete Pricing Rule element is not present",intTest > 0);
		
		//Assert.assertTrue("PASS, Delete Pricing Rule element is present",programContainer.deletePricingRule.isDisplayed());
		//programContainer.deletePricingRule.click(); 
		executor.executeScript("arguments[0].click();",programContainer.deletePricingRule);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		BrowserDriver.getCurrentDriver().switchTo().alert().accept();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void deleteRoutingInstructionsLink(){
		Util.waitTimeElementVisibility(programContainer.deleteRoutingInstructions);
		//programContainer.deleteRoutingInstructions.click(); 
		executor.executeScript("arguments[0].click();",programContainer.deleteRoutingInstructions);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		BrowserDriver.getCurrentDriver().switchTo().alert().accept();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void backToProgram(){
		Util.waitTimeElementVisibility(programContainer.backToProgram);
		//programContainer.backToProgram.click();
		executor.executeScript("arguments[0].click();",programContainer.backToProgram);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	/*
     *  Ticket Program
    */
	
	public static void clickManageTicketProgram(){
		Util.waitTimeElementVisibility(programContainer.manageTicketPrograms);
		//programContainer.manageTicketPrograms.click(); 
		executor.executeScript("arguments[0].click();",programContainer.manageTicketPrograms);
		/*try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	/*
	 * Create new  Ticket Program
	 */
	
	public static void createNewTicketProgram(){
		
		
		try {
			Util.waitTimeElementVisibility(programContainer.createTicketProgramLink);
			int intTest = bd.findElements(By.id("layoutForm:createProgram")).size();
			Assert.assertTrue("Failed, Ticket Program Link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Ticket Program Link is present",programContainer.createTicketProgramLink.isDisplayed());
			//programContainer.createTicketProgramLink.click();
			executor.executeScript("arguments[0].click();",programContainer.createTicketProgramLink);
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void saveNewTicketProgram(){
		Util.waitTimeElementVisibility(programContainer.saveProgram);
		//programContainer.saveProgram.click();
		executor.executeScript("arguments[0].click();",programContainer.saveProgram);
		/*try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	
	
	public static void provideTicketProgramValue(){
		Util.waitTimeElementVisibility(programContainer.ticketprogramName);
		programContainer.ticketprogramName.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.saveTicketProgram);
		//programContainer.saveTicketProgram.click();
		executor.executeScript("arguments[0].click();",programContainer.saveTicketProgram);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.ticketprogramName);
		programContainer.ticketprogramName.sendKeys(ticketProgram.getProperty("ticketProgram.ticketprogramName"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	
	public static void provideTicketProgramTag(){
		Util.waitTimeElementVisibility(programContainer.ticketprogramTag1Input);
		programContainer.ticketprogramTag1Input.clear();
		Util.waitTimeElementVisibility(programContainer.ticketprogramTag1Input);
		programContainer.ticketprogramTag1Input.sendKeys(common.getProperty("common.ticketprogramTag1Input"));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.addticketProgramTagButton);
		//programContainer.addticketProgramTagButton.click();
		executor.executeScript("arguments[0].click();",programContainer.addticketProgramTagButton);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		/*Util.waitTimeElementVisibility(programContainer.addticketProgramTagButton);
		programContainer.addticketProgramTagButton.click();*/
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		//Util.waitTimeElementVisibility(programContainer.ticketprogramTag1Input2);
		programContainer.ticketprogramTag1Input2.clear();
		Util.waitTimeElementVisibility(programContainer.ticketprogramTag1Input2);
		programContainer.ticketprogramTag1Input2.sendKeys(common.getProperty("common.ticketprogramTag1Input2"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.deleteticketProgramTag3Button);
		//programContainer.deleteticketProgramTag3Button.click();
		executor.executeScript("arguments[0].click();",programContainer.deleteticketProgramTag3Button);
		/*try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/

	}
	
		
	public static void selectTicketSeasonType(){
		Util.waitTimeElementVisibility(programContainer.seasonsTypeDropDown);
		//programContainer.seasonsTypeDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.seasonsTypeDropDown);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectTicketProgramSeasonType);
		//programContainer.selectTicketProgramSeasonType.click();
		executor.executeScript("arguments[0].click();",programContainer.selectTicketProgramSeasonType);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.saveTicketProgram);
		//programContainer.saveTicketProgram.click();
		executor.executeScript("arguments[0].click();",programContainer.saveTicketProgram);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	 
	 
	 
	public static void selectTicketbookingStartDate(){
		Util.waitTimeElementVisibility(programContainer.bookingStartDate);
		programContainer.bookingStartDate.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.bookingStartDate);
		programContainer.bookingStartDate.sendKeys(ticketProgram.getProperty("ticketProgram.bookingStartDate"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.saveTicketProgram);
		//programContainer.saveTicketProgram.click(); 
		executor.executeScript("arguments[0].click();",programContainer.saveTicketProgram);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	 
	 
	public static void selectTicketbookingEndtDate() {
		Util.waitTimeElementVisibility(programContainer.bookingEndDate);
		programContainer.bookingEndDate.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.bookingEndDate);
		programContainer.bookingEndDate.sendKeys(ticketProgram.getProperty("ticketProgram.bookingEndDate"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.saveTicketProgram);
		//programContainer.saveTicketProgram.click(); 
		executor.executeScript("arguments[0].click();",programContainer.saveTicketProgram);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}

	
	public static void performanceStartDateInRestriction(){
		Util.waitTimeElementVisibility(programContainer.performanceStartDateInRestriction);
		programContainer.performanceStartDateInRestriction.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.performanceStartDateInRestriction);
		programContainer.performanceStartDateInRestriction.sendKeys(ticketProgram.getProperty("ticketProgram.performanceStartDateInRestriction"));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.saveTicketProgram);
		//programContainer.saveTicketProgram.click();
		executor.executeScript("arguments[0].click();",programContainer.saveTicketProgram);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	  
    
	public static void performanceEndtDateInRestriction() {
		
		try {
			Thread.sleep(1000);
			Util.waitTimeElementVisibility(programContainer.performanceEndDateInRestriction);
			programContainer.performanceEndDateInRestriction.clear();
			Util.waitTimeElementVisibility(programContainer.performanceEndDateInRestriction);
			programContainer.performanceEndDateInRestriction.sendKeys(ticketProgram.getProperty("ticketProgram.performanceEndDateInRestriction"));
			/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}	*/
			Util.waitTimeElementVisibility(programContainer.saveTicketProgram);
			int intTest = bd.findElements(By.id("layoutForm:saveButton")).size();
			Assert.assertTrue("Failed, Save Ticket Program link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Save Ticket Program link is present",programContainer.saveTicketProgram.isDisplayed());
			//programContainer.saveTicketProgram.click(); 
			executor.executeScript("arguments[0].click();",programContainer.saveTicketProgram);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void ticketDescriptionMandatoryClear() {
	  BrowserDriver.getCurrentDriver().switchTo().frame(BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:Desc']/div/iframe")));//id("layoutForm:Desc_iframe")));
	  ((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML=''");		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	  BrowserDriver.getCurrentDriver().switchTo().defaultContent();
		
	  }
	
	public static void ticketDescriptionMandatory() {	
		BrowserDriver.getCurrentDriver().switchTo().frame(BrowserDriver.getCurrentDriver().findElement(By.id("layoutForm:learnmoresDesc_iframe")));//id("layoutForm:Desc_iframe"))); //any locator
		((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML='Description'");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		BrowserDriver.getCurrentDriver().switchTo().defaultContent();
		Util.waitTimeElementVisibility(programContainer.ticketProgramSave);
		//programContainer.ticketProgramSave.click();
		executor.executeScript("arguments[0].click();",programContainer.ticketProgramSave);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}
	public static void saveTicketProgram() {	
		Util.waitTimeElementVisibility(programContainer.saveTicketProgram);
		//programContainer.saveTicketProgram.click();
		executor.executeScript("arguments[0].click();",programContainer.saveTicketProgram);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}

	/*
	 * Edit manage ticket program
	 */
		
	public static void editManageTicketProgramLink(){
		
		try {
			Thread.sleep(1000);
			Util.waitTimeElementVisibility(programContainer.editManageTicketProgramLink);
			int intTest = bd.findElements(By.id("layoutForm:ticketProgramTable:0:editLink")).size();
			Assert.assertTrue("Failed, Edit Manage TicketProgram Link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Edit Manage TicketProgram Link is present",programContainer.editManageTicketProgramLink.isDisplayed());
			//programContainer.editManageTicketProgramLink.click();
			executor.executeScript("arguments[0].click();",programContainer.editManageTicketProgramLink);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
			
	
	public static void provideTicketProgramValueEdit(){
		
		try {
			Util.waitTimeElementVisibility(programContainer.expandAll);
			//programContainer.expandAll.click(); 
			executor.executeScript("arguments[0].click();",programContainer.expandAll);
			Util.waitTimeElementVisibility(programContainer.MLIFEUrl);
			programContainer.MLIFEUrl.sendKeys(ticketProgram.getProperty("ticketProgram.MLIFEUrl"));
			/* try {
			 Thread.sleep(4000);
			 } catch (InterruptedException e) {

			 e.printStackTrace();
			 }*/
			Util.waitTimeElementVisibility(programContainer.MLIFEUrlCopy);
			//programContainer.MLIFEUrlCopy.click();
			executor.executeScript("arguments[0].click();",programContainer.MLIFEUrlCopy);
			/* try {
			 Thread.sleep(3000);
			 } catch (InterruptedException e) {
			 e.printStackTrace();
			 }
			 */
			Util.waitTimeElementVisibility(programContainer.MLIFEUrl);
			programContainer.MLIFEUrl.clear();
			/* try {
			 Thread.sleep(3000);
			 } catch (InterruptedException e) {
			 e.printStackTrace();
			 }*/
			Util.waitTimeElementVisibility(programContainer.MLIFEUrlCopy);
			//programContainer.MLIFEUrlCopy.click(); 
			executor.executeScript("arguments[0].click();",programContainer.MLIFEUrlCopy);
			/* try {
			 Thread.sleep(3000);
			 } catch (InterruptedException e) {
			 e.printStackTrace();
			 }*/
			Util.waitTimeElementVisibility(programContainer.MLIFEUrl1);
			programContainer.MLIFEUrl1.sendKeys(ticketProgram.getProperty("ticketProgram.MLIFEUrl1"));
			/*try {
			 Thread.sleep(4000);
			 } catch (InterruptedException e) {

			 e.printStackTrace();
			 }*/
			Util.waitTimeElementVisibility(programContainer.MLIFEUrlCopy);
			//programContainer.MLIFEUrlCopy.click();
			executor.executeScript("arguments[0].click();",programContainer.MLIFEUrlCopy);
			/* try {
			 Thread.sleep(3000);
			 } catch (InterruptedException e) {
			 e.printStackTrace();
			 }*/
			Util.waitTimeElementVisibility(programContainer.seasons);  
			//programContainer.seasons.click(); 
			executor.executeScript("arguments[0].click();",programContainer.seasons);
			/* try {
			 Thread.sleep(3000);
			 } catch (InterruptedException e) {

			 e.printStackTrace();
			 }*/
			Util.waitTimeElementVisibility(programContainer.seasonsSelect);  
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:showDisplayPanel_panel']/div/ul/li[2]")).size();
			Assert.assertTrue("Failed, Seasons element is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Seasons element is present",programContainer.seasonsSelect.isDisplayed());
			//programContainer.seasonsSelect.click(); 
			executor.executeScript("arguments[0].click();",programContainer.seasonsSelect);
			Thread.sleep(3000);
		 } catch (InterruptedException e) {

		 e.printStackTrace();
		 }
	}
		  
	public static void provideTicketProgramTagEdit(){
		Util.waitTimeElementVisibility(programContainer.ticketprogramTag1Input);
		programContainer.ticketprogramTag1Input.clear();
		/* try {
		 Thread.sleep(3000);
		 } catch (InterruptedException e) {

		 e.printStackTrace();
		 }*/
		Util.waitTimeElementVisibility(programContainer.ticketprogramTag1Input);
		programContainer.ticketprogramTag1Input.sendKeys("TAG1");
		/* try {
		    Thread.sleep(3000);
		 } catch (InterruptedException e) {

		 e.printStackTrace();
		 }*/
		Util.waitTimeElementVisibility(programContainer.addticketProgramTagButton);
		//programContainer.addticketProgramTagButton.click(); 
		executor.executeScript("arguments[0].click();",programContainer.addticketProgramTagButton);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

            	e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.addticketProgramTagButton);		
		//programContainer.addticketProgramTagButton.click();
		executor.executeScript("arguments[0].click();",programContainer.addticketProgramTagButton);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			 e.printStackTrace();
}*/
		Util.waitTimeElementVisibility(programContainer.ticketprogramTag1Input2);
		programContainer.ticketprogramTag1Input2.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.ticketprogramTag1Input2);
		programContainer.ticketprogramTag1Input2.sendKeys("TAG2");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.deleteticketProgramTag3Button);		
		//programContainer.deleteticketProgramTag3Button.click(); 
		executor.executeScript("arguments[0].click();",programContainer.deleteticketProgramTag3Button);
		/*try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}


	public static void selectTicketSeasonTypeEdit() {
		Util.waitTimeElementVisibility(programContainer.seasonsTypeDropDown);
		//programContainer.seasonsTypeDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.seasonsTypeDropDown);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.selectTicketProgramSeasonType);
		//programContainer.selectTicketProgramSeasonType.click();
		executor.executeScript("arguments[0].click();",programContainer.selectTicketProgramSeasonType);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}	


	public static void selectTicketbookingStartDateEdit() {
		Util.waitTimeElementVisibility(programContainer.bookingStartDate);  
		programContainer.bookingStartDate.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.bookingStartDate);
		programContainer.bookingStartDate.sendKeys("03/25/2015");
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/

	}


	public static void selectTicketbookingEndtDateEdit() {
		Util.waitTimeElementVisibility(programContainer.bookingEndDate);
		programContainer.bookingEndDate.clear();
		/* try {
			   Thread.sleep(3000);
		   } catch (InterruptedException e) {

			   e.printStackTrace();
		   }*/
		Util.waitTimeElementVisibility(programContainer.bookingEndDate);
		programContainer.bookingEndDate.sendKeys("03/25/2015");
		/*  try {
			   Thread.sleep(3000);
		   } catch (InterruptedException e) {

			   e.printStackTrace();
		   }*/
	}


	public static void performanceStartDateInRestrictionEdit() {
		Util.waitTimeElementVisibility(programContainer.performanceStartDateInRestriction);
		programContainer.performanceStartDateInRestriction.clear();
		/*try {
			   Thread.sleep(3000);
		   } catch (InterruptedException e) {

			   e.printStackTrace();
		   }*/
		Util.waitTimeElementVisibility(programContainer.performanceStartDateInRestriction);
		programContainer.performanceStartDateInRestriction.sendKeys("03/25/2015");
		/*try {
			   Thread.sleep(3000);
		   } catch (InterruptedException e) {

			   e.printStackTrace();
		   }*/
	}

	public static void performanceEndDateInRestrictionEdit() {
		Util.waitTimeElementVisibility(programContainer.performanceEndDateInRestriction);
		programContainer.performanceEndDateInRestriction.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(programContainer.performanceEndDateInRestriction);
		programContainer.performanceEndDateInRestriction.sendKeys("03/25/2015");
		/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}		*/
	}	


	public static void ticketDescriptionMandatoryClearEdit() {
		BrowserDriver.getCurrentDriver().switchTo().frame(BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:Desc']/div/iframe")));//id("layoutForm:Desc_iframe")));
		((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML=''");	
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		BrowserDriver.getCurrentDriver().switchTo().defaultContent();

	}

		


	public static void ticketDescriptionMandatoryEdit() {
		BrowserDriver.getCurrentDriver().switchTo().frame(BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:Desc']/div/iframe")));//id("layoutForm:Desc_iframe"))); //any locator
		((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML='Description'");
		BrowserDriver.getCurrentDriver().switchTo().defaultContent();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}


	}

	public static String createPricingProgram(){
		LOGGER.info("Creating pricing program");

		createNewProgram();
		selectCategory();
		String randomNumber = String.valueOf(getRandomNumber());
		String pricingPrgName = "Cucumber9_"+randomNumber; 
		provideProgramValueForDoubleDerived(pricingPrgName, randomNumber);
		provideOfferBasicSettingsValueForDoubleDerived();
		provideAccessSettingsValue();
		createNewPricingRule();
		int rand = getRandomNumber();
		valueForPricingRule("11/01/2020", "11/20/2020", "amount",  rand);
		saveCreatedNewPricingRule();
		createNewPricingRule();
		valueForPricingRule("11/21/2020", "11/30/2020", "percentage", rand);
		saveCreatedNewPricingRule();

		providePromotionOrInclusionValueForDoubleDerived();
		provideDateRestrictionValueForDoubleDerived();
		//provideMinimumNoOfNightsValue();

		provideAdvanceBookingValue();
		provideSelectPlayerTierValue();
		provideNotesValueForDoubleDerived();
		checkIfSelectPaymentTypeExists();
		checkIfAssociateRoomsValueExistsORNot();
		checkIfAssociateRoomsSyncValueExistsORNot();
		saveNewProgram();

		return pricingPrgName;

	} 

	public static String createAndEditProgram(){
		LOGGER.info("Creating pricing program");
		createNewProgram();
		selectCategory();
		String randomNumber = String.valueOf(getRandomNumber());
		String createEditPrgName = "Cucumber9_"+randomNumber; 
		provideProgramValue(createEditPrgName, randomNumber);
		provideOfferBasicSettingsValue();
		provideAccessSettingsValue();
		createNewPricingRule();
		valueForPricingRule("11/01/2020", "11/20/2020", "amount",getRandomNumber());
		saveCreatedNewPricingRule();

		providePromotionOrInclusionValueForDoubleDerived();
		provideDateRestrictionValueForDoubleDerived();
		//provideMinimumNoOfNightsValue();

		provideAdvanceBookingValue();
		provideSelectPlayerTierValue();
		provideNotesValueForDoubleDerived();
		checkIfSelectPaymentTypeExists();
		checkIfAssociateRoomsValueExistsORNot();
		checkIfAssociateRoomsSyncValueExistsORNot();
		saveNewProgram();

		return createEditPrgName;

	}




	 
		
	public static void valueForPricingRuleForDerivedProgram(final String pricingProgramName){
		LOGGER.info("double derived pricing rule");
		Util.waitTimeElementVisibility(programContainer.activeCheckPricing);
		//programContainer.activeCheckPricing.click();
		executor.executeScript("arguments[0].click();",programContainer.activeCheckPricing);
		/*	try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		LOGGER.info("checking syncToOpera");
		Util.waitTimeElementVisibility(programContainer.syncToOperaCheck);
		//programContainer.syncToOperaCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.syncToOperaCheck);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.parentRateTableDropDown);
		//programContainer.parentRateTableDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.parentRateTableDropDown);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.selectParentRateTable);
		//programContainer.selectParentRateTable.click(); 
		executor.executeScript("arguments[0].click();",programContainer.selectParentRateTable);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.pricingProgramNameRadio);
		//programContainer.pricingProgramNameRadio.click();
		executor.executeScript("arguments[0].click();",programContainer.pricingProgramNameRadio);
		
		/*Util.waitTimeElementVisibility(programContainer.pricingProgramName);
		programContainer.pricingProgramName.click();
		programContainer.pricingProgramName.clear();
		programContainer.pricingProgramName.sendKeys(pricingProgramName);
		
		try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
		Util.waitTimeElementVisibility(programContainer.selectPricingProgramName);
		programContainer.selectPricingProgramName.click();*/
		Util.waitTimeElementVisibility(programContainer.pricingFromDate);
		programContainer.pricingFromDate.clear();
		programContainer.pricingFromDate.sendKeys("11/01/2020");
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.pricingToDate);
		programContainer.pricingToDate.clear();
		programContainer.pricingToDate.sendKeys("11/30/2020");
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.checkSunday);
		//programContainer.checkSunday.click();
		executor.executeScript("arguments[0].click();",programContainer.checkSunday);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.checkTuesday);
		//programContainer.checkTuesday.click();
		executor.executeScript("arguments[0].click();",programContainer.checkTuesday);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.percentageDiscountTypeCheck);
		//programContainer.percentageDiscountTypeCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.percentageDiscountTypeCheck);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.discountValue);
		programContainer.discountValue.clear();
		Util.waitTimeElementVisibility(programContainer.discountValue);
		programContainer.discountValue.sendKeys("8");
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/

		saveCreatedNewPricingRule();
		Util.waitTimeElementVisibility(programContainer.clickAlertOk);
		//programContainer.clickAlertOk.click(); 
		executor.executeScript("arguments[0].click();",programContainer.clickAlertOk);		

		Util.waitTimeElementVisibility(programContainer.pricingProgramName);
		programContainer.pricingProgramName.clear();
		Util.waitTimeElementVisibility(programContainer.pricingProgramName);
		programContainer.pricingProgramName.sendKeys(pricingProgramName);

		Util.waitTimeElementVisibility(programContainer.selectPricingProgramName);
		//programContainer.selectPricingProgramName.click();
		executor.executeScript("arguments[0].click();",programContainer.selectPricingProgramName);

		Util.waitTimeElementVisibility(programContainer.rateTableRadio);
	//	programContainer.rateTableRadio.click(); 
		executor.executeScript("arguments[0].click();",programContainer.rateTableRadio);

		Util.waitTimeElementVisibility(programContainer.pricingProgramNameRadio);
		//programContainer.pricingProgramNameRadio.click();
		executor.executeScript("arguments[0].click();",programContainer.pricingProgramNameRadio);

		Util.waitTimeElementVisibility(programContainer.flatDiscountTypeCheck);
		//programContainer.flatDiscountTypeCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.flatDiscountTypeCheck);

		Util.waitTimeElementVisibility(programContainer.percentageDiscountTypeCheck);
		//programContainer.percentageDiscountTypeCheck.click(); 
		executor.executeScript("arguments[0].click();",programContainer.percentageDiscountTypeCheck);
	

		/*
		 * saveCreatedNewPricingRule();
		 * Util.waitTimeElementVisibility(programContainer.pricingToDate);
		 * programContainer.pricingToDate.clear();
		 * Util.waitTimeElementVisibility(programContainer.pricingToDate);
		 * programContainer.pricingToDate.sendKeys("11/20/2020");
		 * 
		 * saveCreatedNewPricingRule();
		 * Util.waitTimeElementVisibility(programContainer.checkSaturday);
		 * //programContainer.checkSaturday.click();
		 * executor.executeScript("arguments[0].click();",programContainer.checkSaturday
		 * );
		 * 
		 * saveCreatedNewPricingRule();
		 * Util.waitTimeElementVisibility(programContainer.amountDiscountTypeCheck);
		 * //programContainer.amountDiscountTypeCheck.click();
		 * executor.executeScript("arguments[0].click();",programContainer.
		 * amountDiscountTypeCheck);
		 * 
		 * saveCreatedNewPricingRule();
		 * Util.waitTimeElementVisibility(programContainer.checkSaturday);
		 * //programContainer.checkSaturday.click();
		 * executor.executeScript("arguments[0].click();",programContainer.checkSaturday
		 * );
		 * 
		 * Util.waitTimeElementVisibility(programContainer.pricingFromDate);
		 * programContainer.pricingFromDate.clear();
		 * Util.waitTimeElementVisibility(programContainer.pricingFromDate);
		 * programContainer.pricingFromDate.sendKeys("10/30/2020");
		 * 
		 * saveCreatedNewPricingRule();
		 * Util.waitTimeElementVisibility(programContainer.pricingFromDate);
		 * programContainer.pricingFromDate.clear();
		 * programContainer.pricingFromDate.sendKeys("11/01/2020");
		 */

		Util.waitTimeElementVisibility(programContainer.compNightsDropDown);
		//programContainer.compNightsDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.compNightsDropDown);

		Util.waitTimeElementVisibility(programContainer.selectCompNightZero);
		//programContainer.selectCompNightZero.click();
		executor.executeScript("arguments[0].click();",programContainer.selectCompNightZero);

		Util.waitTimeElementVisibility(programContainer.pricingOperaRateCode);
		programContainer.pricingOperaRateCode.clear();
		Util.waitTimeElementVisibility(programContainer.pricingOperaRateCode);
		programContainer.pricingOperaRateCode.sendKeys("ZAARP"+getRandomNumber());

		Util.waitTimeElementVisibility(programContainer.marketCode);
		programContainer.marketCode.clear();
		Util.waitTimeElementVisibility(programContainer.marketCode);
		programContainer.marketCode.sendKeys("CTGX");

		Util.waitTimeElementVisibility(programContainer.selectMarketCode);
		//programContainer.selectMarketCode.click();
		executor.executeScript("arguments[0].click();",programContainer.selectMarketCode);

		Util.waitTimeElementVisibility(programContainer.sourceCode);
		programContainer.sourceCode.clear();
		programContainer.sourceCode.sendKeys("LDTEXP");

		Util.waitTimeElementVisibility(programContainer.selectSourceCode);
		//programContainer.selectSourceCode.click();
		executor.executeScript("arguments[0].click();",programContainer.selectSourceCode);

	}

	public static void provideProgramValueForDoubleDerived(final String programName, final String userProgramId){
		Util.waitTimeElementVisibility(programContainer.programName);
		programContainer.programName.clear();			
		LOGGER.info("Program Name: "+programName);
		Util.waitTimeElementVisibility(programContainer.programName);
		programContainer.programName.sendKeys(programName);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.userProgramId);
		programContainer.userProgramId.clear();	
		Util.waitTimeElementVisibility(programContainer.userProgramId);
		programContainer.userProgramId.sendKeys(userProgramId);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.tierOption);
		//programContainer.tierOption.click(); 
		executor.executeScript("arguments[0].click();",programContainer.tierOption);
		Util.waitTimeElementVisibility(programContainer.tierAdd);
		//programContainer.tierAdd.click();
		executor.executeScript("arguments[0].click();",programContainer.tierAdd);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(programContainer.TierCreditFromTextBox);
		programContainer.TierCreditFromTextBox.clear();
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.TierCreditFromTextBox);
		programContainer.TierCreditFromTextBox.sendKeys(roomProgram.getProperty("program.customerValueFromInput"));
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.TierCreditToTextBox);
		programContainer.TierCreditToTextBox.clear();
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.TierCreditToTextBox);
		programContainer.TierCreditToTextBox.sendKeys(roomProgram.getProperty("program.customerValueToInput"));
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.reservationTypeDropDown);
		//programContainer.reservationTypeDropDown.click(); 
		executor.executeScript("arguments[0].click();",programContainer.reservationTypeDropDown);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.selectProgramReservationType);
		//programContainer.selectProgramReservationType.click();
		executor.executeScript("arguments[0].click();",programContainer.selectProgramReservationType);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.depositRuleDropDown);
		//programContainer.depositRuleDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.depositRuleDropDown);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.selectProgramDepositRule);
		//programContainer.selectProgramDepositRule.click();
		executor.executeScript("arguments[0].click();",programContainer.selectProgramDepositRule);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.cancellationPolicyDropDown);
		//programContainer.cancellationPolicyDropDown.click(); 
		executor.executeScript("arguments[0].click();",programContainer.cancellationPolicyDropDown);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.selectProgramCancellationPolicy);
		//programContainer.selectProgramCancellationPolicy.click(); 
		executor.executeScript("arguments[0].click();",programContainer.selectProgramCancellationPolicy);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.commissionPercentage);
		programContainer.commissionPercentage.clear();
		Util.waitTimeElementVisibility(programContainer.commissionPercentage);
		programContainer.commissionPercentage.sendKeys(roomProgram.getProperty("program.commissionPercentage"));
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.operaRateCategory);
		programContainer.operaRateCategory.clear();
		Util.waitTimeElementVisibility(programContainer.operaRateCategory);
		programContainer.operaRateCategory.sendKeys(roomProgram.getProperty("program.operaRateCategory"));
		/*try {
				Thread.sleep(6000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.selectoperaRateCategory);
		//programContainer.selectoperaRateCategory.click(); 
		executor.executeScript("arguments[0].click();",programContainer.selectoperaRateCategory);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}	*/		
	}

	public static void provideOfferBasicSettingsValueForDoubleDerived(){
		Util.waitTimeElementVisibility(programContainer.patronPromotionId);
		programContainer.patronPromotionId.clear();
		Util.waitTimeElementVisibility(programContainer.patronPromotionId);
		programContainer.patronPromotionId.sendKeys(roomProgram.getProperty("program.patronPromotionId"));
		/*try {
				Thread.sleep(4000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		/*Util.waitTimeElementVisibility(programContainer.selectPatronPromotionId);
		programContainer.selectPatronPromotionId.click();*/
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}	*/	
		Util.waitTimeElementVisibility(programContainer.publicName);
		programContainer.publicName.clear();
		Util.waitTimeElementVisibility(programContainer.publicName);
		programContainer.publicName.sendKeys(roomProgram.getProperty("program.publicName"));
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.maxNightsDropDown);
		//programContainer.maxNightsDropDown.click(); 
		executor.executeScript("arguments[0].click();",programContainer.maxNightsDropDown);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.selectMaxNights);
		//programContainer.selectMaxNights.click();
		executor.executeScript("arguments[0].click();",programContainer.selectMaxNights);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		/*Util.waitTimeElementVisibility(programContainer.offerForInterestCode);
		programContainer.offerForInterestCode.clear();
		Util.waitTimeElementVisibility(programContainer.offerForInterestCode);
		programContainer.offerForInterestCode.sendKeys(roomProgram.getProperty("program.offerForInterestCode"));*/
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.priorityRadio);
		//programContainer.priorityRadio.click(); 
		executor.executeScript("arguments[0].click();",programContainer.priorityRadio);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.enableBestOffer);
		//programContainer.enableBestOffer.click(); 
		executor.executeScript("arguments[0].click();",programContainer.enableBestOffer);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}	*/	
		Util.waitTimeElementVisibility(programContainer.description);
		programContainer.description.clear();
		Util.waitTimeElementVisibility(programContainer.description);
		programContainer.description.sendKeys(roomProgram.getProperty("program.description"));
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.periodStartDate);
		programContainer.periodStartDate.clear();
		Util.waitTimeElementVisibility(programContainer.periodStartDate);
		programContainer.periodStartDate.sendKeys(roomProgram.getProperty("program.periodStartDate"));
		/*	try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.periodEndDate);
		programContainer.periodEndDate.clear();	
		Util.waitTimeElementVisibility(programContainer.periodEndDate);
		programContainer.periodEndDate.sendKeys(roomProgram.getProperty("program.periodEndDate"));
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		/*Util.waitTimeElementVisibility(programContainer.valueAddedByManual);
		programContainer.valueAddedByManual.click();
		try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}	
		Util.waitTimeElementVisibility(programContainer.priceByPerDay);
		programContainer.priceByPerDay.click();
		try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
		Util.waitTimeElementVisibility(programContainer.priceByValueLink);
		programContainer.priceByValueLink.clear();
		try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}		
		Util.waitTimeElementVisibility(programContainer.priceByValueLink);
		programContainer.priceByValueLink.sendKeys(roomProgram.getProperty("program.priceByValueLink"));*/
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
	}

	public static void providePromotionOrInclusionValueForDoubleDerived(){
		Util.waitTimeElementVisibility(programContainer.promotionCode);
		programContainer.promotionCode.clear();
		Util.waitTimeElementVisibility(programContainer.promotionCode);
		programContainer.promotionCode.sendKeys(roomProgram.getProperty("programDoubleDerived.promotionCode")+getRandomNumber());
		try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
		Util.waitTimeElementVisibility(programContainer.promoGroupDropDown);
		//programContainer.promoGroupDropDown.click(); 
		executor.executeScript("arguments[0].click();",programContainer.promoGroupDropDown);
		try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
		Util.waitTimeElementVisibility(programContainer.selectPromoGroup);
		//programContainer.selectPromoGroup.click();
		executor.executeScript("arguments[0].click();",programContainer.selectPromoGroup);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.learnMoreDescription);
		programContainer.learnMoreDescription.sendKeys(roomProgram.getProperty("programDoubleDerived.learnMoreDescription"));
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		
		LOGGER.info("checking syncToOpera");
		Util.waitTimeElementVisibility(programContainer.checkSyncToOpera);
		//programContainer.syncToOperaCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.checkSyncToOpera);
		
	}

	public static void provideDateRestrictionValueForDoubleDerived(){
		Util.waitTimeElementVisibility(programContainer.travelPeriodStartDate);
		programContainer.travelPeriodStartDate.clear();
		Util.waitTimeElementVisibility(programContainer.travelPeriodStartDate);
		programContainer.travelPeriodStartDate.sendKeys(roomProgram.getProperty("program.travelPeriodStartDate"));
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.travelPeriodEndDate);
		programContainer.travelPeriodEndDate.clear();
		Util.waitTimeElementVisibility(programContainer.travelPeriodEndDate);
		programContainer.travelPeriodEndDate.sendKeys(roomProgram.getProperty("program.travelPeriodEndDate"));
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.checkSundayRI);
		//programContainer.checkSundayRI.click(); 
		executor.executeScript("arguments[0].click();",programContainer.checkSundayRI);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.checkTuesdayRI);
		//programContainer.checkTuesdayRI.click();
		executor.executeScript("arguments[0].click();",programContainer.checkTuesdayRI);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.checkFridayRI);
		//programContainer.checkFridayRI.click(); 
		executor.executeScript("arguments[0].click();",programContainer.checkFridayRI);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.checkSaturdayRI);
		//programContainer.checkSaturdayRI.click();
		executor.executeScript("arguments[0].click();",programContainer.checkSaturdayRI);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.bookByDate);
		programContainer.bookByDate.clear();
		Util.waitTimeElementVisibility(programContainer.bookByDate);
		programContainer.bookByDate.sendKeys(roomProgram.getProperty("program.bookByDate"));
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.termsAndConditions);
		programContainer.termsAndConditions.sendKeys(roomProgram.getProperty("program.termsAndConditions"));
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
	}
	
	public static void checkIfSelectPaymentTypeExists(){
		try{
			WebElement select = BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:pickList3']/tbody/tr/td/ul"));
			List<WebElement> options = select.findElements(By.tagName("li"));
	        if(options.size()>1)
	        {
	        	provideSelectPaymentTypeValue();				
	        }	
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	public static void provideNotesValueForDoubleDerived(){
		if(programContainer.agentText.getText().isEmpty()){
			programContainer.agentText.sendKeys(roomProgram.getProperty("program.agentText"));
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
		}
	}

	public static int getRandomNumber(){
		return ++randomNumber;
	}

	/*
	 * Edit manage Program
	 */

	public static void createNewPricingProgram() {

		createNewProgram();
		selectCategory();
		String randomNumber = String.valueOf(MystiqueProgramView.getRandomNumber());
		MystiqueProgramView.provideProgramValueForDoubleDerived("Cucumber9_"+randomNumber, randomNumber);
		MystiqueProgramView.provideOfferBasicSettingsValueForDoubleDerived();	 
		checkButtonSyncToOpera();
		MystiqueProgramView.createNewPricingRule();
		checkSyncToOpera();
		MystiqueProgramView.provideOperaRateCode();

		MystiqueProgramView.providePromotionOrInclusionValueForDoubleDerived();
		MystiqueProgramView.providePromoCode();
		MystiqueProgramView.provideDateRestrictionValueForDoubleDerived();
		MystiqueProgramView.provideMinimumNoOfNightsValue();	 

		MystiqueProgramView.provideAdvanceBookingValue();
		MystiqueProgramView.provideSelectPlayerTierValue();
		MystiqueProgramView.provideNotesValueForDoubleDerived();
		MystiqueProgramView.checkIfSelectPaymentTypeExists();
		MystiqueProgramView.checkIfAssociateRoomsValueExistsORNot();
		saveNewProgram();
		MystiqueProgramView.hoverOnProgramTab();
		MystiqueProgramView.clickManageProgram();

		String programName = "Cucumber9_"+randomNumber;
		MystiqueProgramView.searchName(programName);
		MystiqueProgramView.editProgram();	 
	}


	private static void checkButtonSyncToOpera() {
		Util.waitTimeElementVisibility(programContainer.checkSyncToOpera);
		//programContainer.checkSyncToOpera.click();
		executor.executeScript("arguments[0].click();",programContainer.checkSyncToOpera);
		/*try {
			Thread.sleep(10000);
			} catch (InterruptedException e) {

			e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.activeCheck);
		//programContainer.activeCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.activeCheck);
		/*try {
			Thread.sleep(3000);
			} catch (InterruptedException e) {

			e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.publicCheck);
		//programContainer.publicCheck.click();
		executor.executeScript("arguments[0].click();",programContainer.publicCheck);
		/*try {
			Thread.sleep(3000);
			} catch (InterruptedException e) {

			e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.bookableOnlineCheck);
		//programContainer.bookableOnlineCheck.click(); 
		executor.executeScript("arguments[0].click();",programContainer.bookableOnlineCheck);
		/*try {
			Thread.sleep(3000);
			} catch (InterruptedException e) {

			e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.viewOnlineCheck);
		//programContainer.viewOnlineCheck.click(); 
		executor.executeScript("arguments[0].click();",programContainer.viewOnlineCheck);
		/*try {
			Thread.sleep(3000);
			} catch (InterruptedException e) {

			e.printStackTrace();
			}	*/ 
		Util.waitTimeElementVisibility(programContainer.bookableOnPropertySite);
		//programContainer.bookableOnPropertySite.click(); 
		executor.executeScript("arguments[0].click();",programContainer.bookableOnPropertySite);
		/*try {
			Thread.sleep(3000);
			} catch (InterruptedException e) {

			e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.viewOnPropertySite);
		//programContainer.viewOnPropertySite.click(); 
		executor.executeScript("arguments[0].click();",programContainer.viewOnPropertySite);
		/*try {
			Thread.sleep(3000);
			} catch (InterruptedException e) {

			e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.availableInIceCheck);
		//programContainer.availableInIceCheck.click(); 
		executor.executeScript("arguments[0].click();",programContainer.availableInIceCheck);
		/*try {
			Thread.sleep(3000);
			} catch (InterruptedException e) {

			e.printStackTrace();
			}	*/ 
	}


	public static void provideOperaRateCode() {

		programContainer.pricingOperaRateCode.clear();
		String randomNumber = String.valueOf(MystiqueProgramView.getRandomNumber());
		Util.waitTimeElementVisibility(programContainer.pricingOperaRateCode);
		programContainer.pricingOperaRateCode.sendKeys("ZAARP"+randomNumber);
		/*try {
			Thread.sleep(3000);
			} catch (InterruptedException e) {

			e.printStackTrace();
			}	*/
		Util.waitTimeElementVisibility(programContainer.discountValue);
		programContainer.discountValue.clear();
		Util.waitTimeElementVisibility(programContainer.discountValue);
		programContainer.discountValue.sendKeys("8");
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.compNightsDropDown);
		//programContainer.compNightsDropDown.click();
		executor.executeScript("arguments[0].click();",programContainer.compNightsDropDown);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.selectCompNights);
		//programContainer.selectCompNights.click();
		executor.executeScript("arguments[0].click();",programContainer.selectCompNights);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.marketCode);
		programContainer.marketCode.clear();
		Util.waitTimeElementVisibility(programContainer.marketCode);
		programContainer.marketCode.sendKeys(roomProgram.getProperty("pricingProgram.marketCode"));
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.selectMarketCode);
		//programContainer.selectMarketCode.click();
		executor.executeScript("arguments[0].click();",programContainer.selectMarketCode);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.sourceCode);
		programContainer.sourceCode.clear();
		Util.waitTimeElementVisibility(programContainer.sourceCode);
		programContainer.sourceCode.sendKeys(roomProgram.getProperty("pricingProgram.sourceCode"));
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.selectSourceCode);
		//programContainer.selectSourceCode.click(); 
		executor.executeScript("arguments[0].click();",programContainer.selectSourceCode);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.saveProgramPricing);
		//programContainer.saveProgramPricing.click();
		executor.executeScript("arguments[0].click();",programContainer.saveProgramPricing);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.packageName);

		programContainer.packageName.clear();
		Util.waitTimeElementVisibility(programContainer.packageName);
		programContainer.packageName.sendKeys(roomProgram.getProperty("pricingProgram.packageName"));
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.selectPackageName);
		//programContainer.selectPackageName.click(); 
		executor.executeScript("arguments[0].click();",programContainer.selectPackageName);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/

	}

	public static void providePromoCode() {
		Util.waitTimeElementVisibility(programContainer.promotionCode);
		programContainer.promotionCode.clear();
		String randomNumber = String.valueOf(MystiqueProgramView.getRandomNumber());
		Util.waitTimeElementVisibility(programContainer.promotionCode);
		programContainer.promotionCode.sendKeys("TESTPC1"+randomNumber);
		/*try {
			Thread.sleep(3000);
			} catch (InterruptedException e) {

			e.printStackTrace();
			}*/
	}

	public static void checkSyncToOpera() {
		Util.waitTimeElementVisibility(programContainer.activeLink);
		//programContainer.activeLink.click();
		executor.executeScript("arguments[0].click();",programContainer.activeLink);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}	*/	
		Util.waitTimeElementVisibility(programContainer.syncToOpera);
		//programContainer.syncToOpera.click();
		executor.executeScript("arguments[0].click();",programContainer.syncToOpera);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		//Util.waitTimeElementVisibility(programContainer.bookingDate);
		programContainer.bookingDate.clear();
		Util.waitTimeElementVisibility(programContainer.bookingDate);
		programContainer.bookingDate.sendKeys("03/20/2015");
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		//Util.waitTimeElementVisibility(programContainer.endDate);
		programContainer.endDate.clear();
		Util.waitTimeElementVisibility(programContainer.endDate);
		programContainer.endDate.sendKeys("03/20/2015");
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
		Util.waitTimeElementVisibility(programContainer.rateTable);
		//programContainer.rateTable.click(); 
		executor.executeScript("arguments[0].click();",programContainer.rateTable);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
		 */
		Util.waitTimeElementVisibility(programContainer.flat);
		//programContainer.flat.click();
		executor.executeScript("arguments[0].click();",programContainer.flat);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/	
		//Util.waitTimeElementVisibility(programContainer.value);
		programContainer.value.clear();
		Util.waitTimeElementVisibility(programContainer.value);
		programContainer.value.sendKeys("123");
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}	*/		
	}


	public static void editPricingProgram() {
		clickEditLink();
		checkSyncToOpera();
		saveNewProgram();

	}

	public static void clickEditLink() {
		Util.waitTimeElementVisibility(programContainer.editClick);
		//programContainer.editClick.click(); 
		executor.executeScript("arguments[0].click();",programContainer.editClick);
		/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
	}


	public static String editCreatedProgram() {
		editProgram();
		providePromotionOrInclusionValue();
		provideDateRestrictionValue();
		//provideMinimumNoOfNightsValue();
		provideAdvanceBookingValue();
		provideSelectPlayerTierValue();
		provideNotesValue();
		checkIfSelectPaymentTypeExists();
		checkIfAssociateRoomsValueExistsORNot();
		saveNewProgram();
		return null;
	}

public static void selectRegion_LasVegas(){
		
		try {
			Thread.sleep(20000);
			Util.waitTimeElementVisibility(programContainer.clickregion_LasVegas);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:j_idt58:region']/ul/li[1]")).size();
		//	Assert.assertTrue("Failed, Region is not present",intTest > 0);
			//LOGGER.info("Clicking on Region: Las Vegas ");
			try {
				scrollIntoViewMethod(programContainer.clickregion_LasVegas);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//Assert.assertTrue("PASS, Manage Programs link is present",programContainer.managePrograms.isDisplayed());
			//programContainer.clickregion_LasVegas.click();
			executor.executeScript("arguments[0].click();",programContainer.clickregion_LasVegas);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

public static void scrollIntoViewMethod(WebElement element) throws Exception{
    JavascriptExecutor js= (JavascriptExecutor) BrowserDriver.getCurrentDriver();
    //WebElement element= bd.findElement(element);
    js.executeScript("arguments[0].scrollIntoView(true);",element);
} 
	
public static void selectProperty_LasVegas_Delano(){
	
	try {
		Thread.sleep(20000);
		Util.waitTimeElementVisibility(programContainer.clickproperty_delano);
		//int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:j_idt58:propertyList']/ul/li[6]")).size();
		//Assert.assertTrue("Failed, Delano Las Vegas is not present",intTest > 0);
		LOGGER.info("Clicking on Property: Ariya ");
		try {
			scrollIntoViewMethod(programContainer.clickproperty_delano);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Assert.assertTrue("PASS, Manage Programs link is present",programContainer.managePrograms.isDisplayed());
		//programContainer.clickproperty_delano.click();
		executor.executeScript("arguments[0].click();",programContainer.clickproperty_delano);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

public static void allprogram_search(){
	
	try {
		Thread.sleep(20000);
		Util.waitTimeElementVisibility(programContainer.allProgramSearchBtn);
		int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:searchButton']")).size();
		Assert.assertTrue("Failed, Search button is not present",intTest > 0);
		LOGGER.info("Clicking on Search button ");
		//Assert.assertTrue("PASS, Manage Programs link is present",programContainer.managePrograms.isDisplayed());
		//programContainer.allProgramSearchBtn.click(); 
		executor.executeScript("arguments[0].click();",programContainer.allProgramSearchBtn);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}
		

public static void allprogram_export(){
	
	try {
		Thread.sleep(20000);
		Util.waitTimeElementVisibility(programContainer.allProgramExportlnk);
		//int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:j_idt179']/div[1]/a")).size();
		//Assert.assertTrue("Failed, Export link is not present",intTest > 0);
		LOGGER.info("Clicking on Export link");
		//Assert.assertTrue("PASS, Manage Programs link is present",programContainer.managePrograms.isDisplayed());
		//programContainer.allProgramExportlnk.click(); 
		executor.executeScript("arguments[0].click();",programContainer.allProgramExportlnk);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

public static void editPricingRule(){
	
	try {
		Thread.sleep(20000);
		//Util.waitTimeElementVisibility(programContainer.editPricingRule);
	  //createNewPricingRule();
		
		
		
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:priceRuleDTOList_data']/tr[1]/td[5]/a")).size();
		//Assert.assertTrue("Failed, edit link is not present",intTest > 0);
	
		if(intTest == 0) {
			createNewPricingRule();
		}else {
			LOGGER.info("Clicking on edit link for pricing rule ");
			//Assert.assertTrue("PASS, Manage Programs link is present",programContainer.managePrograms.isDisplayed());
			
			executor.executeScript("arguments[0].click();",programContainer.editPricingRule);
		}

	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

public static void check_ShowinICE_checkbox(){
	
	try {
		Thread.sleep(1000);
		Util.waitTimeElementVisibility(programContainer.ShowinICE_checkbox);
		int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:showInICE']/div[2]")).size();
		Assert.assertTrue("Failed, Show in ICE checkbox not present",intTest > 0);
		LOGGER.info("Checking Show in ICE checkbox on credit card authorization page");
		//Assert.assertTrue("PASS, Manage Programs link is present",programContainer.managePrograms.isDisplayed());
		System.out.println(programContainer.ShowinICE_checkbox.isSelected());
		boolean x=programContainer.ShowinICE_checkbox.isSelected();
		if(x== false){
			
			//programContainer.ShowinICE_checkbox.click(); 
			executor.executeScript("arguments[0].click();",programContainer.ShowinICE_checkbox);	
			
		}
		else
		{
			System.out.println("Show in ICE checkbox already selected");
			
		}
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

public static void selecting_FormFields(){
	
	try {
		Thread.sleep(1000);
		Util.waitTimeElementVisibility(programContainer.FormFields_checkbox);
		int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:fieldSource_data']/tr[1]/td[1]/div/div[2]")).size();
		Assert.assertTrue("Failed, Value not present",intTest > 0);
		LOGGER.info("Selecting value from Form Fields on credit card authorization page");
		//Assert.assertTrue("PASS, Manage Programs link is present",programContainer.managePrograms.isDisplayed());
		
			programContainer.FormFields_checkbox.click(); 
			//executor.executeScript("arguments[0].click();",programContainer.selectMinHoursAfterEnrollment);
			//programContainer.FormFields_singlemovearrow.click();
			executor.executeScript("arguments[0].click();",programContainer.FormFields_singlemovearrow);
		
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

public static void providevalue_header_AuthorizationNote(){
	
	try {
		Thread.sleep(1000);
		try {
			scrollIntoViewMethod(programContainer.headerinput);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//entering value in the header text field
		BrowserDriver.getCurrentDriver().switchTo().frame(BrowserDriver.getCurrentDriver().findElement(By.id("layoutForm:headerShort_iframe")));
		LOGGER.info("Entering value in Header Fields on credit card authorization page");
		//((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML='test header'");
		programContainer.headerinput.sendKeys(Keys.CONTROL + "a");
		programContainer.headerinput.sendKeys(Keys.DELETE);
		programContainer.headerinput.sendKeys("gjhgjhgjhgjhg hgkgkgkjg jkjgjkggg");
		BrowserDriver.getCurrentDriver().switchTo().defaultContent();
		
		Thread.sleep(10000);
		
		//entering value in the Authorization Note text field
		BrowserDriver.getCurrentDriver().switchTo().frame(BrowserDriver.getCurrentDriver().findElement(By.id("layoutForm:authorizationNote_iframe")));
		//LOGGER.info("Entering value in the Authorization Note Fields on credit card authorization page");
		//((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("document.body.innerHTML='test Authorization Note '");
		//programContainer.headerinput.clear();
		programContainer.headerinput.sendKeys(Keys.CONTROL + "a");
		programContainer.headerinput.sendKeys(Keys.DELETE);
		programContainer.headerinput.sendKeys("212545454 12454 hnfggh");
		BrowserDriver.getCurrentDriver().switchTo().defaultContent();
		
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

public static void providevalue_FaxNumber(){
	
	try {
		Thread.sleep(1000);
		
		try {
			scrollIntoViewMethod(programContainer.faxnumber);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Util.waitTimeElementVisibility(programContainer.faxnumber);
		int intTest = bd.findElements(By.id("layoutForm:faxNumber")).size();
		Assert.assertTrue("Failed, Fax number field not present",intTest > 0);
		LOGGER.info("Entering value on the Fax Number Fields on credit card authorization page");
		//Assert.assertTrue("PASS, Manage Programs link is present",programContainer.managePrograms.isDisplayed());
		
		programContainer.faxnumber.clear();
		programContainer.faxnumber.sendKeys("(702) 590-0123");
			
		
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

	public static void clickingSavebtn_cca(){
	
	try {
		Thread.sleep(1000);
		Util.waitTimeElementVisibility(programContainer.savebtn_cca);
		int intTest = bd.findElements(By.id("layoutForm:saveButton")).size();
		Assert.assertTrue("Failed, Save button feild not present",intTest > 0);
		LOGGER.info("clicking on the save button on credit card authorization page");
		//Assert.assertTrue("PASS, Manage Programs link is present",programContainer.managePrograms.isDisplayed());
		
		//programContainer.savebtn_cca.click(); 
		executor.executeScript("arguments[0].click();",programContainer.savebtn_cca);
		
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}
	
	public static void saveConfirmation_CreditCardAuthorization(){
		boolean flag;
	try {
		Thread.sleep(1000);
		Util.waitTimeElementVisibility(programContainer.validation_cca_save);
		int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:messages_container']/div/div/div[2]/span")).size();
		String value=programContainer.validation_cca_save.getText();
		//Assert.assertTrue("PASS, Manage Programs link is present",programContainer.managePrograms.isDisplayed());
		
		if(value.equalsIgnoreCase("Save Successful")){
			flag=true;
			
		}
		else{
			flag=false;
		}
		
		Assert.assertTrue("Failed, value not saved",intTest > 0 && flag);
		LOGGER.info("Credit card authorization page saved successfully");
		
		
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

public static void checkSupressRateAndPrintRate(){
	
	try {
		Thread.sleep(20000);
		Util.waitTimeElementVisibility(programContainer.supressRate);
		int intTest = bd.findElements(By.id("layoutForm:suppressRate")).size();
		Assert.assertTrue("Failed, suppress rate check box not present ",intTest > 0);
		LOGGER.info("Checking the Suppress rate checkbox ");
		//Assert.assertTrue("PASS, Manage Programs link is present",programContainer.managePrograms.isDisplayed());
		//programContainer.supressRate.click();
		executor.executeScript("arguments[0].click();",programContainer.supressRate);
		
		Util.waitTimeElementVisibility(programContainer.printRate);
		int intTest1 = bd.findElements(By.id("layoutForm:printRate")).size();
		Assert.assertTrue("Failed, print rate check box not present ",intTest1 > 0);
		LOGGER.info("Checking the print rate checkbox ");
		//Assert.assertTrue("PASS, Manage Programs link is present",programContainer.managePrograms.isDisplayed());
		//programContainer.printRate.click(); 
		executor.executeScript("arguments[0].click();",programContainer.printRate);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

public static void alertDialogBox(){
	
	try {
		Thread.sleep(20000);
		Util.waitTimeElementVisibility(programContainer.alertDialogbox);
		int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:alertDialogVal']/div[1]")).size();
		Assert.assertTrue("Failed, Alert Dialog Box is not present",intTest > 0);
		LOGGER.info(" Alert Dialog Box is displayed ");
		//Assert.assertTrue("PASS, Manage Programs link is present",programContainer.managePrograms.isDisplayed());
	//	programContainer.alertCloseBtn.click();
		executor.executeScript("arguments[0].click();",programContainer.alertCloseBtn);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
	
}

	
}




			
	

		

		
	


		
     


		
		


