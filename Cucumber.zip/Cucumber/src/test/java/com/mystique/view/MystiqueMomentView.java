package com.mystique.view;

import java.util.Properties;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.MystiqueMomentContainer;
import com.mystique.utils.CommonUtils;
import com.mystique.utils.Constants;

public class MystiqueMomentView {
	
	private static final Logger LOGGER = Logger.getLogger(MystiqueMomentView.class.getName());
	
	private static final MystiqueMomentContainer momentContainer = PageFactory.initElements(BrowserDriver.getCurrentDriver(),MystiqueMomentContainer.class);
	
	public static final Properties momentProperties = CommonUtils.getConfigPath(Constants.MOMENT_PATH);

	static WebDriver bd = BrowserDriver.getCurrentDriver();
	static CommonUtils Util = new CommonUtils();
	static JavascriptExecutor executor = (JavascriptExecutor) bd;
	
	public static void selectMomentTab() {
		LOGGER.info("Inside select Moment:");
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Actions action = new Actions(BrowserDriver.getCurrentDriver());
		WebElement we =BrowserDriver.getCurrentDriver().findElement(By.xpath("(//span[@class='ui-menuitem-text' and contains(text(),'Moments')])[1]"));
		//*[@id="layoutForm:menuBar"]/ul/li[4]/a/span[2]
		Util.waitTimeElementVisibility(we);
		action.moveToElement(we).build().perform();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		try {
			Util.waitTimeElementVisibility(momentContainer.manageMomentsTab);
			int intTest = bd.findElements(By.xpath("//*[@id=\"layoutForm:manageMoments\"]")).size();
			Assert.assertTrue("Failed, Manage Moments Tab is not present",intTest > 0);
			executor.executeScript("arguments[0].click();",momentContainer.manageMomentsTab);
			//momentContainer.manageMomentsTab.click();
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void clickOnEditLink() {
		try {
			Util.waitTimeElementVisibility(momentContainer.editLink);
			int intTest = bd.findElements(By.xpath("//*[@id=\"layoutForm:momentDataTable:0:editButton\"]")).size();
			Assert.assertTrue("Failed, Edit Link is not present",intTest > 0);
			
			momentContainer.editLink.click();
			LOGGER.info("Clicked on Edit moment:");
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}		
	}
	
	public static void clickOnEnableBestOffer(){
		try {
			Thread.sleep(5000);
			WebElement enableBestOffer = bd.findElement(By.xpath("//*[@id=\"layoutForm:checkbox_enableBestOffer\"]/div[2]"));
			((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("arguments[0].scrollIntoView(true);", enableBestOffer);
			
			Util.waitTimeElementVisibility(momentContainer.enableBestOffer);
			int intTest = bd.findElements(By.xpath("//*[@id=\"layoutForm:checkbox_enableBestOffer\"]/div[2]")).size();
			Assert.assertTrue("Failed, enableBestOffer checkbox not present",intTest > 0);
			
			boolean enableBestOfferActive = momentContainer.enableBestOffer.isSelected();
			if(enableBestOfferActive == false){
				executor.executeScript("arguments[0].click();",momentContainer.enableBestOffer);
			}
			LOGGER.info("Clicked on enableBestOffer");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void populateBookingWindow() {
		try {
			Thread.sleep(5000);
			WebElement showSourceBookingWindow = bd.findElement(By.xpath("//*[@id=\"layoutForm:bookingWindows_id\"]/div/div/div[10]/div[2]"));
			((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("arguments[0].scrollIntoView(true);", showSourceBookingWindow);
			
			Util.waitTimeElementVisibility(momentContainer.showSourceBookingWindow);
			executor.executeScript("arguments[0].click();",momentContainer.showSourceBookingWindow);
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		momentContainer.textareaBookingWindow.clear();
		momentContainer.textareaBookingWindow.sendKeys("<p>booking window test cucumber</p>");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		executor.executeScript("arguments[0].click();",momentContainer.showSourceBookingWindow);
	}
	
	public static void populateCorporatesortorder() {
		try {
			Util.waitTimeElementVisibility(momentContainer.corporatesortorder);
			momentContainer.corporatesortorder.clear();
			momentContainer.corporatesortorder.sendKeys("2");
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void populateExecutionProcess() {
		try {
			Thread.sleep(5000);
			WebElement showSourceExecutionProcess = bd.findElement(By.xpath("//*[@id=\"layoutForm:executionProcess_id\"]/div/div/div[10]/div[2]"));
			((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("arguments[0].scrollIntoView(true);", showSourceExecutionProcess);
			
			Util.waitTimeElementVisibility(momentContainer.showSourceExecutionProcess);
			executor.executeScript("arguments[0].click();",momentContainer.showSourceExecutionProcess);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		momentContainer.textareaExecutionProcess.clear();
		momentContainer.textareaExecutionProcess.sendKeys("<p>Execution Process test cucumber</p>");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		executor.executeScript("arguments[0].click();",momentContainer.showSourceExecutionProcess);
	}
	
	
	public static void clickSaveMomentButton() {
		
		try {
			Thread.sleep(5000);
			((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("window.scrollTo(0, document.body.scrollHeight)");
			Util.waitTimeElementVisibility(momentContainer.saveMomentBtn);
			int intTest = bd.findElements(By.xpath("//*[@id=\"layoutForm:saveButton\"]")).size();
			Assert.assertTrue("Failed, Save button is not present",intTest > 0);
			
			LOGGER.info("clicking on the save button on Moment page");
			momentContainer.saveMomentBtn.click();
			Thread.sleep(5000);
			
			Util.waitTimeElementVisibility(momentContainer.saveMomentDialogbox);
			int savetest = bd.findElements(By.xpath("//*[@id=\"layoutForm:messages_container\"]")).size();
			Assert.assertTrue("Failed, Save button is not present",savetest > 0);
			Thread.sleep(5000);
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
