package com.mystique.view;

import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.MystiqueDashboardContainer;
import com.mystique.utils.CommonUtils;

public class MystiqueDashboardView {

	private static final Logger LOGGER = Logger
			.getLogger(MystiqueDashboardView.class.getName());
	private static final MystiqueDashboardContainer dashboardContainer = PageFactory
			.initElements(BrowserDriver.getCurrentDriver(),
					MystiqueDashboardContainer.class);
	
	static WebDriver bd = BrowserDriver.getCurrentDriver();
	static CommonUtils Util=new CommonUtils();
	static JavascriptExecutor executor = (JavascriptExecutor)bd;
	
	public static void selectPropertyDropDown() {
		
		try {
			LOGGER.info("inside select administration");
			Util.waitTimeElementVisibility(dashboardContainer.applicationSelectionDropDown);
			/*try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
			BrowserDriver.waitForElement(dashboardContainer.applicationSelectionDropDown);
			LOGGER.info("dashboard loaded");
			LOGGER.info("@@@@@@@@@@@@@@@@@Before Application Drop down click");
			Util.waitTimeElementVisibility(dashboardContainer.applicationSelectionDropDown);
			//dashboardContainer.applicationSelectionDropDown.click();
			executor.executeScript("arguments[0].click();",dashboardContainer.applicationSelectionDropDown);
			/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:applicationSelectMenu_panel']/div/ul/li[1]")).size();
			Assert.assertTrue("Failed, Application Selection element is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Application Selection element is present",dashboardContainer.applicationSelection.isDisplayed());
			dashboardContainer.applicationSelection.click();
			LOGGER.info("Clicked on Property Drop Down");
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

	public static void selectARIAfromDropDown() {
		
		try {
			LOGGER.info("Before Clicking on the Property Drop Down:");
			Util.waitTimeElementVisibility(dashboardContainer.propertyMenuSelectionDropDown);
			//dashboardContainer.propertyMenuSelectionDropDown.click();
			executor.executeScript("arguments[0].click();",dashboardContainer.propertyMenuSelectionDropDown);
			/*try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}*/
			Util.waitTimeElementVisibility(dashboardContainer.propertyMenuSelection);
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:propertySelectMenu_panel']/div/ul/li[2]")).size();
			Assert.assertTrue("Failed, Property Menu Selection is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Property Menu Selection is present",dashboardContainer.propertyMenuSelection.isDisplayed());
			executor.executeScript("arguments[0].click();",dashboardContainer.propertyMenuSelection);
			//dashboardContainer.propertyMenuSelection.click();
			LOGGER.info("Clicked on ARIA");
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	public static void selectBELLAGIOfromDropDown() {
		LOGGER.info("Before Clicking on the Property Drop Down:");
		Util.waitTimeElementVisibility(dashboardContainer.propertyMenuSelectionDropDown);
		dashboardContainer.propertyMenuSelectionDropDown.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(dashboardContainer.propertyMenuSelection);
		dashboardContainer.propertyMenuSelection.click();
		LOGGER.info("Clicked on ARIA");
		/*try {
			Thread.sleep(20000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	public static void selectDellanofromDropDown() {
		LOGGER.info("Before Clicking on the Property Drop Down:");
		Util.waitTimeElementVisibility(dashboardContainer.propertyMenuSelectionDropDown);
		dashboardContainer.propertyMenuSelectionDropDown.click();
		Util.waitTimeElementVisibility(dashboardContainer.propertyMenuSelectionDellano);
		dashboardContainer.propertyMenuSelectionDellano.click();
		LOGGER.info("Clicked on Dellano");
		try {
			Thread.sleep(30000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	public static void selectMBfromDropDown() {
		LOGGER.info("Before Clicking on the Property Drop Down:");
		Util.waitTimeElementVisibility(dashboardContainer.propertyMenuSelectionDropDown);
		dashboardContainer.propertyMenuSelectionDropDown.click();
		Util.waitTimeElementVisibility(dashboardContainer.propertyMenuSelectionDellano);
		dashboardContainer.propertyMenuSelectionMB.click();
		LOGGER.info("Clicked on Mandalay Bay");
		
	}
}
