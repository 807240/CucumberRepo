package com.mystique.view;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.MystiqueRatesContainer;
import com.mystique.utils.CommonUtils;
import com.mystique.utils.Constants;

public class MystiqueRatesView {

	private static final Logger LOGGER = Logger
			.getLogger(MystiqueRatesView.class.getName());
	private static final MystiqueRatesContainer ratesContainer = PageFactory
			.initElements(BrowserDriver.getCurrentDriver(),
					MystiqueRatesContainer.class);
	
	public static final Properties rateProperties = CommonUtils.getConfigPath(Constants.RATE_PATH);
	public static final Properties commonProperties = BrowserDriver.getCommomProperties();
	
    private static int discriminatorValue;
	private static String rateTableName;
	private static boolean value =true;
	
	static WebDriver bd = BrowserDriver.getCurrentDriver();
	static JavascriptExecutor executor = (JavascriptExecutor) bd;
	static CommonUtils Util=new CommonUtils();
	
	public static void checkIfRatesExists() {
		do{			
		discriminatorValue= (int)(Math.random()*100000);
		rateTableName="CucumberRate" + discriminatorValue;
		Util.waitTimeElementVisibility(ratesContainer.searchRates);
		ratesContainer.searchRates.click();
		ratesContainer.filterRateTable.sendKeys(rateTableName);
		
		WebElement select = BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:rateDataTable_data']/tr"));
		List<WebElement> options = select.findElements(By.tagName("td"));
        	if(options.size()>1)
        	{
        		value =false;		
        	}	
	
		}
		while(value);
	}
	
	

	public static void popUpAlertMessage() {
		BrowserDriver.getCurrentDriver().switchTo().alert().accept();
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public static void popUpAlertDismiss() {
		BrowserDriver.getCurrentDriver().switchTo().alert().dismiss();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public static void clickPopUpOkay() {
		ratesContainer.clickAlertOk.click();
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	/*
	 * Manage Rate Table
	 */
	public static void manageRateTableTab() {
		LOGGER.info("Inside select Rates:");
		Actions action = new Actions(BrowserDriver.getCurrentDriver());
		WebElement we = BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:menuPanel']/div/ul/li[5]/a/span[2]"));
		action.moveToElement(we).build().perform();
		/*
		 * Point coordinates = ratesContainer.ratesMenu .findElement(
		 * By.xpath("//*[@id='layoutForm:menuPanel']/div/ul/li[5]/a/span[2]"))
		 * .getLocation(); Robot robot = null; try { robot = new Robot(); }
		 * catch (AWTException e1) {
		 * 
		 * e1.printStackTrace(); } robot.mouseMove(coordinates.getX() + 30,
		 * coordinates.getY() + 95);
		 */
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

		LOGGER.info("Before Clicking on the Manage Rate Table");
		Util.waitTimeElementVisibility(ratesContainer.manageRateTable);
		executor.executeScript("arguments[0].click()", ratesContainer.manageRateTable);
		//ratesContainer.manageRateTable.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public static void filterRateTable() {
		LOGGER.info("In filterRateTable method");
		Util.waitTimeElementVisibility(ratesContainer.filterRateTable);
		ratesContainer.filterRateTable.clear();
		discriminatorValue= 36598;
		rateTableName="CucumberRate" + discriminatorValue;
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("rate table name is "+rateTableName);
		Util.waitTimeElementVisibility(ratesContainer.filterRateTable);
		ratesContainer.filterRateTable.sendKeys(String.valueOf(rateTableName));
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public static void editRateTableLink() {
		try {
			Thread.sleep(5000);
			Util.waitTimeElementVisibility(ratesContainer.editRateTable);
			ratesContainer.editRateTable.click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void editRatesLink() {
		try {
			Thread.sleep(5000);
			Util.waitTimeElementVisibility(ratesContainer.editRatesLink);
			ratesContainer.editRatesLink.click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public static void editActiveFlag() {
		Util.waitTimeElementVisibility(ratesContainer.rateTableActiveCheck);
		boolean activeRate = ratesContainer.rateTableActiveCheck.isSelected();
		if(activeRate == false){
			ratesContainer.rateTableActiveCheck.click();
		}
		
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	*/	
	}
	
	public static void saveRateTable() {
		try {
			((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("window.scrollTo(0, document.body.scrollHeight)");
			Util.waitTimeElementVisibility(ratesContainer.saveRateTable);
			LOGGER.info("clicking on save rate table");
			int intTest = bd.findElements(By.xpath("//*[@id='layoutForm:saveButton']")).size();
			Assert.assertTrue("Failed, Save rate Button is not present",intTest > 0);
			
			ratesContainer.saveRateTable.click();
			Thread.sleep(5000);
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void cancelRateTable() {
		try {
			Thread.sleep(5000);
			((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("window.scrollTo(0, document.body.scrollHeight)");
			Util.waitTimeElementVisibility(ratesContainer.cancelButton);
			ratesContainer.cancelButton.click();
			Thread.sleep(10000);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	
	public static void rateTableDescriptionEdit() {
		LOGGER.info("In RateTableDescriptionEdit() method");
		Util.waitTimeElementVisibility(ratesContainer.rateTableDescription);
		ratesContainer.rateTableDescription.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		/*ratesContainer.rateTableDescription.sendKeys("©®™â©®™â©®™â©®™â©®™â©®™â©"
				+ "®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®"
				+ "™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™  ");
		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		ratesContainer.saveRateTable.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		ratesContainer.afterSaveClickAlertOk.click();
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		ratesContainer.rateTableDescription.clear();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(ratesContainer.rateTableDescription);
		ratesContainer.rateTableDescription.sendKeys(rateProperties.getProperty(Constants.RATE_TABLE_EDIT_DESCRIPTION));
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	public static void shortDescriptionEdit() {
		/*ratesContainer.shortDescription.sendKeys("©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™"
				+ "â©®™â©®™â©®™â©®™â©®™â©®™â©®™â©®™ ");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		ratesContainer.saveRateTable.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		ratesContainer.afterSaveClickAlertOk.click();
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	*/
		/*ratesContainer.shortDescription.clear();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		LOGGER.info("In shortDescriptionEdit() method");
		Util.waitTimeElementVisibility(ratesContainer.shortDescription);
		ratesContainer.shortDescription.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(ratesContainer.shortDescription);
		ratesContainer.shortDescription.sendKeys(rateProperties.getProperty(Constants.RATE_TABLE_EDIT_SHORT_DESCRIPTION));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void selectRateTableFromDateEdit() {
		Util.waitTimeElementVisibility(ratesContainer.shortDescription);
		ratesContainer.rateTableFromDate.clear();
	/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(ratesContainer.rateTableFromDate);
		ratesContainer.rateTableFromDate.sendKeys(rateProperties.getProperty(Constants.RATE_TABLE_EDIT_FROM_DATE));
	/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(ratesContainer.rateTableFromDate);
		executor.executeScript("arguments[0].click()", ratesContainer.rateTableFromDate);
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}

	public static void selectRateTableToDateEdit() {
		Util.waitTimeElementVisibility(ratesContainer.rateTableToDate);
		ratesContainer.rateTableToDate.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(ratesContainer.rateTableToDate);
		ratesContainer.rateTableToDate.sendKeys(rateProperties.getProperty(Constants.RATE_TABLE_EDIT_TO_DATE));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	*/	
	}

	public static void operaRateCategoryEdit() {
		Util.waitTimeElementVisibility(ratesContainer.operaRateCategory);
		ratesContainer.operaRateCategory.clear();
		/*try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(ratesContainer.operaRateCategory);
		ratesContainer.operaRateCategory.sendKeys(commonProperties.getProperty(Constants.COMMON_OPERA_RATE_CATEGORY_CASH));
		/*try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(ratesContainer.selectOperaRateCategory);
		ratesContainer.selectOperaRateCategory.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}

	public static void marketCodeEdit() {
		try {
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(ratesContainer.marketCode);
			ratesContainer.marketCode.clear();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(ratesContainer.marketCode);
		ratesContainer.marketCode.sendKeys(commonProperties.getProperty(Constants.COMMON_MARKET_CODE_CSLP));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(ratesContainer.selectMarketCode);
		ratesContainer.selectMarketCode.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}	

	public static void createRateTableLink() {

		/*
		 * Point coordinates = ratesContainer.createRateTable .findElement(
		 * By.xpath("//*[@id='layoutForm:createRateTable']")) .getLocation();
		 * Robot robot = null; try { robot = new Robot(); } catch (AWTException
		 * e1) {
		 * 
		 * e1.printStackTrace(); } robot.mouseMove(coordinates.getX() + 724,
		 * coordinates.getY() + 220); try { Thread.sleep(3000); } catch
		 * (InterruptedException e) {
		 * 
		 * e.printStackTrace(); }
		 */
		try {
			Thread.sleep(3000);
			Util.waitTimeElementVisibility(ratesContainer.createRateTable);
			ratesContainer.createRateTable.click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	public static void provideRateTableName() {
		LOGGER.info("Rate Table name is "+rateTableName);
		Util.waitTimeElementVisibility(ratesContainer.rateTableName);
		ratesContainer.rateTableName.clear();
		ratesContainer.rateTableName.sendKeys(rateTableName);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}
	
	public static void rateDescription() {
		
		Util.waitTimeElementVisibility(ratesContainer.rateDescription);
		LOGGER.info("Inside rate table description.");
		ratesContainer.rateDescription.clear();
		ratesContainer.rateDescription.sendKeys(rateProperties.getProperty(Constants.RATE_TABLE_CREATE_DESCRIPTION));
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		/*ratesContainer.saveRateTable.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	
		ratesContainer.rateDescription.clear();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		ratesContainer.rateDescription.sendKeys(rateProperties.getProperty(Constants.RATE_TABLE_CREATE_DESCRIPTION));
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void rateShortDescription() {
		
		Util.waitTimeElementVisibility(ratesContainer.rateShortDescription);
		LOGGER.info("Inside rate table short description.");
		ratesContainer.rateShortDescription.clear();
		ratesContainer.rateShortDescription.sendKeys(rateProperties.getProperty(Constants.RATE_TABLE_CREATE_SHORT_DESCRIPTION));
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void categoryDropDown() {
		Util.waitTimeElementVisibility(ratesContainer.categoryDropDown);
		ratesContainer.categoryDropDown.click();
		/*try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(ratesContainer.selectCategory);
		ratesContainer.selectCategory.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(ratesContainer.selectActiveCheckbox);
		ratesContainer.selectActiveCheckbox.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void selectRateTableFromDate() {
		LOGGER.info("Inside rate table selectRateTableFromDate.");
		Util.waitTimeElementVisibility(ratesContainer.rateTableFromDate);
		ratesContainer.rateTableFromDate.clear();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(ratesContainer.rateTableFromDate);
		ratesContainer.rateTableFromDate.sendKeys(rateProperties.getProperty(Constants.RATE_TABLE_CREATE_FROM_DATE));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(ratesContainer.rateTableFromDate);
		ratesContainer.rateTableFromDate.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void selectRateTableToDate() {
		LOGGER.info("Inside rate table selectRateTableToDate.");
		Util.waitTimeElementVisibility(ratesContainer.rateTableToDate);
		ratesContainer.rateTableToDate.clear();
	    /* try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(ratesContainer.rateTableToDate);
	     ratesContainer.rateTableToDate.sendKeys(rateProperties.getProperty(Constants.RATE_TABLE_CREATE_TO_DATE));
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
				
	    	e.printStackTrace();
		}
		*/
	}

	public static void operaRateCategory() {
		Util.waitTimeElementVisibility(ratesContainer.operaRateCategory);
		ratesContainer.operaRateCategory.clear();
		ratesContainer.operaRateCategory.sendKeys(commonProperties.getProperty(Constants.COMMON_OPERA_RATE_CATEGORY_COMP));
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(ratesContainer.selectOperaRateCategory);
		ratesContainer.selectOperaRateCategory.click();
		/*try {
			Thread.sleep(15000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		/*Util.waitTimeElementVisibility(ratesContainer.saveRateTable);
		ratesContainer.saveRateTable.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}

	public static void marketCode() {
		Util.waitTimeElementVisibility(ratesContainer.marketCode);
		ratesContainer.marketCode.clear();
		ratesContainer.marketCode.sendKeys(commonProperties.getProperty(Constants.COMMON_MARKET_CODE_CTGX));
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(ratesContainer.selectMarketCode);
		ratesContainer.selectMarketCode.click();
		/*try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(ratesContainer.rateTableActiveCheck);
		ratesContainer.rateTableActiveCheck.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void syncRoomToOpera() {
		LOGGER.info("Inside rate table SyncRoomToOpera.");
		Util.waitTimeElementVisibility(ratesContainer.syncRoomToOperaSelect);
		ratesContainer.syncRoomToOperaSelect.click();
		Util.waitTimeElementVisibility(ratesContainer.manageRateTableActiveButton);
		ratesContainer.manageRateTableActiveButton.click();
		/*try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	public static void checkIfSyncRoomToOpera(){
		try{
			WebElement select = BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:roomPickList']/tbody/tr/td/ul"));
			List<WebElement> options = select.findElements(By.tagName("li"));
	        if(options.size()>1)
	        {
	        	syncRoomToOpera();				
	        }	
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	public static void packageComponent() {
		Util.waitTimeElementVisibility(ratesContainer.packageComponent);
		ratesContainer.packageComponent.clear();
		ratesContainer.packageComponent.sendKeys(commonProperties.getProperty(Constants.COMMON_PACKAGE_COMPONENT));
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		/*Util.waitTimeElementVisibility(ratesContainer.selectPackageComponent);
		ratesContainer.selectPackageComponent.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}
	
	/*
	 * Manage Rate Modifier
	 */
	public static void manageRateModifierTab() {
		LOGGER.info("Inside select Rates:");
		Actions action = new Actions(BrowserDriver.getCurrentDriver());
		WebElement we = BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:ratesMenu']/a/span[2]"));
		action.moveToElement(we).build().perform();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(ratesContainer.manageRateModifierPage);
		ratesContainer.manageRateModifierPage.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	
	/*
	 * Export Rates
	 */
	public static void clickOnExportRates() {
		Util.waitTimeElementVisibility(ratesContainer.clickExportRatesLink);
		LOGGER.info("Clicking Export Rates Link");
		ratesContainer.clickExportRatesLink.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void provideDataForExport() {
		LOGGER.info("Providing data combinations for file download");
		Util.waitTimeElementVisibility(ratesContainer.rateTableSelectDropdown);
		/*Select rate_table = new Select(ratesContainer.rateTableSelectDropdown);
		rate_table.selectByValue("PREVAIL");*/
		ratesContainer.rateTableSelectDropdown.click();
		LOGGER.info("Selecting Rate");
		Util.waitTimeElementVisibility(ratesContainer.selectPrevailRateTable);
		ratesContainer.selectPrevailRateTable.click();
		
		
		Util.waitTimeElementVisibility(ratesContainer.roomDeselectPicklist);
		ratesContainer.roomDeselectPicklist.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("Selecting Room");
		Util.waitTimeElementVisibility(ratesContainer.roomSelect);
		ratesContainer.roomSelect.click();
		//Util.waitTimeElementVisibility(ratesContainer.roomSelect);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		/*ratesContainer.roomSelect.click();*/
		
		Util.waitTimeElementVisibility(ratesContainer.roomSelected);
		ratesContainer.roomSelected.click();
		LOGGER.info("Selecting Date Range");
		Util.waitTimeElementVisibility(ratesContainer.fromDate);
		ratesContainer.fromDate.click();
		ratesContainer.fromDate.clear();
		ratesContainer.fromDate.sendKeys("03/06/2020");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		Util.waitTimeElementVisibility(ratesContainer.toDate);
		ratesContainer.toDate.click();
		ratesContainer.toDate.clear();
		ratesContainer.toDate.sendKeys("03/08/2020");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void provideDataForRateModifier() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("Providing data combinations for listing Rate Modifier");
		Util.waitTimeElementVisibility(ratesContainer.rateModifierRateTableSelectDropdown);
		/*Select rate_table = new Select(ratesContainer.rateTableSelectDropdown);
		rate_table.selectByValue("PREVAIL");*/
		ratesContainer.rateModifierRateTableSelectDropdown.click();
		LOGGER.info("Selecting Rate");
		Util.waitTimeElementVisibility(ratesContainer.rateModifierSelectPrevailRateTable);
		ratesContainer.rateModifierSelectPrevailRateTable.click();
		
		
		Util.waitTimeElementVisibility(ratesContainer.rateModifierRoomDeselectPicklist);
		ratesContainer.rateModifierRoomDeselectPicklist.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("Selecting Room");
		Util.waitTimeElementVisibility(ratesContainer.rateModifierRoomSelect);
		ratesContainer.rateModifierRoomSelect.click();
		//Util.waitTimeElementVisibility(ratesContainer.roomSelect);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		/*ratesContainer.roomSelect.click();*/
		
		Util.waitTimeElementVisibility(ratesContainer.rateModifierRoomSelected);
		ratesContainer.rateModifierRoomSelected.click();
		LOGGER.info("Selecting Date Range");
		Util.waitTimeElementVisibility(ratesContainer.rateModifierFromDate);
		ratesContainer.rateModifierFromDate.click();
		ratesContainer.rateModifierFromDate.clear();
		ratesContainer.rateModifierFromDate.sendKeys("03/06/2020");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		Util.waitTimeElementVisibility(ratesContainer.rateModifierToDate);
		ratesContainer.rateModifierToDate.click();
		ratesContainer.rateModifierToDate.clear();
		ratesContainer.rateModifierToDate.sendKeys("03/06/2020");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void clickDownloadLink() {
		LOGGER.info("Downloading Export Sheet");
		Util.waitTimeElementVisibility(ratesContainer.exportButton);
		ratesContainer.exportButton.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		
		/*try {
			Robot robo = new Robot();
			robo.keyPress(KeyEvent.VK_ENTER);
			robo.keyRelease(KeyEvent.VK_ENTER);
		} catch (AWTException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		*/
		/*ratesContainer.exportButton.sendKeys(Keys.RETURN);*/
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("Export Sheet Downloaded");
	}
	
	public static void clickRateModifierGo() {
		LOGGER.info("Listing Rate Modifiers or Rates");
		Util.waitTimeElementVisibility(ratesContainer.rateModifierGoButton);
		ratesContainer.rateModifierGoButton.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("Clicked on the Go Button");
	}
	
	public static void checkExistingRates() {
		LOGGER.info("Checking Existing Rates");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		if(bd.findElements(By.xpath("//*[@id='layoutForm:rateGrid:0:output_date']")).size()>0) //*[@id="layoutForm:rateGrid_data"]/tr/td[2]  //*[@id="layoutForm:rateGrid_data"]/tr/td[7]
		{
			LOGGER.info("Records Exist");
			if(bd.findElement(By.xpath("//*[@id=\"layoutForm:rateGrid_data\"]/tr/td[2]")).getText() == bd.findElement(By.xpath("//*[@id=\"layoutForm:rateGrid_data\"]/tr/td[7]")).getText() )			
			{
				LOGGER.info("No Existing Rate Modifier found for Room");
			}
			else
				LOGGER.info("Existing Rate Modifier found for Room");
		}
		else
			LOGGER.info("No Records Exist");
	}
	
	public static void newRateModifier() {
		LOGGER.info("Creating New Rate Modifier");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		if(bd.findElements(By.xpath("//*[@id='layoutForm:rateGrid:0:output_date']")).size()>0)
		{
			LOGGER.info("Records Exist");
			//Util.waitTimeElementVisibility(ratesContainer.clickRateModifierField);
			Actions clickRateModifier =new Actions(bd);
			clickRateModifier.doubleClick(ratesContainer.clickRateModifierField).build().perform();
			//ratesContainer.clickRateModifierField.click();
			
//			Util.waitTimeElementVisibility(ratesContainer.rateModifierDropdown);
//			ratesContainer.rateModifierDropdown.click();
			Util.waitTimeElementVisibility(ratesContainer.clickRateModifierDropdown);
			ratesContainer.clickRateModifierDropdown.click();
//			Util.waitTimeElementVisibility(ratesContainer.selectRoomDLAV);
//			ratesContainer.selectRoomDLAV.click();
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			Util.waitTimeElementVisibility(ratesContainer.clickRateModifier);
			ratesContainer.clickRateModifier.click();
			Util.waitTimeElementVisibility(ratesContainer.selectAmountRateModifier);
			ratesContainer.selectAmountRateModifier.click();
			Util.waitTimeElementVisibility(ratesContainer.valueRateModifier);
			ratesContainer.valueRateModifier.click();
			//ratesContainer.valueRateModifier.clear();
			ratesContainer.valueRateModifier.sendKeys("-50000");
			Util.waitTimeElementVisibility(ratesContainer.rateModifierTotalRate);
			ratesContainer.rateModifierTotalRate.click();
			Util.waitTimeElementVisibility(ratesContainer.rateModifierReview);
			ratesContainer.rateModifierReview.click();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			if(ratesContainer.rateModifierSubmit.isDisplayed())
			{
				Util.waitTimeElementVisibility(ratesContainer.rateModifierSubmit);
				ratesContainer.rateModifierSubmit.click();
				
			}
			else
			{
				Util.waitTimeElementVisibility(ratesContainer.clickDialogOk);
				ratesContainer.clickDialogOk.click();
				//Actions clickRateModifier =new Actions(bd);
				clickRateModifier.doubleClick(ratesContainer.clickRateModifierField).build().perform();
				//ratesContainer.clickRateModifierField.click();
				
//				Util.waitTimeElementVisibility(ratesContainer.rateModifierDropdown);
//				ratesContainer.rateModifierDropdown.click();
				Util.waitTimeElementVisibility(ratesContainer.clickRateModifierDropdown);
				ratesContainer.clickRateModifierDropdown.click();
//				Util.waitTimeElementVisibility(ratesContainer.selectRoomDLAV);
//				ratesContainer.selectRoomDLAV.click();
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				Util.waitTimeElementVisibility(ratesContainer.clickRateModifier);
				ratesContainer.clickRateModifier.click();
				Util.waitTimeElementVisibility(ratesContainer.selectAmountRateModifier);
				ratesContainer.selectAmountRateModifier.click();
				Util.waitTimeElementVisibility(ratesContainer.valueRateModifier);
				ratesContainer.valueRateModifier.click();
				//ratesContainer.valueRateModifier.clear();
				ratesContainer.valueRateModifier.sendKeys("-50000");
				Util.waitTimeElementVisibility(ratesContainer.rateModifierTotalRate);
				ratesContainer.rateModifierTotalRate.click();
				Util.waitTimeElementVisibility(ratesContainer.rateModifierReview);
				ratesContainer.rateModifierReview.click();
			
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
	
					e.printStackTrace();
				}
				Util.waitTimeElementVisibility(ratesContainer.rateModifierSubmit);
				ratesContainer.rateModifierSubmit.click();
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
		}
		else
			LOGGER.info("No Records Exist");
	}
	
	public static void hoverOnDashboardPropertyMenu() {
		LOGGER.info("Hovering on Dashboard Property Menu-Bellagio");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Actions action = new Actions(bd);
		WebElement we = ratesContainer.propMenuBellagio;
		action.moveToElement(we).build().perform();
	}
	
	public static void selectPropertySubMenu() {
		LOGGER.info("Hovering on submenu for Dashboard Property Menu-Bellagio");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("Selecting Sub-menu Rates/Restriction");
		Actions action = new Actions(bd);
		WebElement we = ratesContainer.subMenuBellagio;
		action.moveToElement(we).click().build().perform();
	}
	
	public static void checkRateTableDisplay() {
		LOGGER.info("Waiting for page load");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(ratesContainer.activeRateTable);
		Assert.assertTrue("FAIL, Rate Table is not present",ratesContainer.activeRateTable.isDisplayed());
		LOGGER.info("PASS,Rate Table is displayed");
	}
	
	public static void hoveronRateTable() {
		LOGGER.info("Hovering on Dashboard Active Rate Table");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		rateTableName=ratesContainer.activeRateTableText.getText();
		Actions action = new Actions(bd);
		WebElement we = ratesContainer.activeRateTable;
		action.moveToElement(we).build().perform();
	}
	
	public static void selectEditRates() {
		LOGGER.info("Selecting Edit Rates");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(ratesContainer.editRatesMenu);
		ratesContainer.editRatesMenu.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void selectmngRateModifier() {
		LOGGER.info("Selecting Edit Rates");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(ratesContainer.mngRateModifierMenu);
		ratesContainer.mngRateModifierMenu.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void selectRateImportExport() {
		LOGGER.info("Selecting Edit Rates");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(ratesContainer.rateImportExport);
		ratesContainer.rateImportExport.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void checkRateTableDisplayEditRates() {
		LOGGER.info("Checking if Rate Table name is inherited as default");
		Util.waitTimeElementVisibility(ratesContainer.editRatechkDPRPO);
		Assert.assertTrue("FAIL, Rate Table is not present",ratesContainer.editRatechkDPRPO.isDisplayed());
		LOGGER.info("PASS,Rate Table is displayed");
		
	}
	
	public static void checkRateTableDisplayMngRateModifier() {
		LOGGER.info("Checking if Rate Table name is inherited as default");
		Util.waitTimeElementVisibility(ratesContainer.mngRateModifierchkDPRPO);
		LOGGER.info("The current rate table displayed-"+ ratesContainer.mngRateModifierchkDPRPO.getText());
		LOGGER.info("The current rate table captured-"+ rateTableName);
		Assert.assertEquals("FAIL, Rate Table is not present",ratesContainer.mngRateModifierchkDPRPO.getText(),rateTableName);
		LOGGER.info("PASS,Rate Table is displayed");
		
	}
	
	public static void checkRateTableDisplayRateImportExport() {
		LOGGER.info("Checking if Rate Table name is inherited as default");
		Util.waitTimeElementVisibility(ratesContainer.rateImportExportchkDPRPO);
		LOGGER.info("The current rate table displayed-"+ ratesContainer.rateImportExportchkDPRPO.getText());
		LOGGER.info("The current rate table captured-"+ rateTableName);
		Assert.assertEquals("FAIL, Rate Table is not present",ratesContainer.rateImportExportchkDPRPO.getText(),rateTableName);
		LOGGER.info("PASS,Rate Table is displayed");
		
	}
	
	public static void returnToHomeDashboard() {
		LOGGER.info("Returning to Home page");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(ratesContainer.clickHome);
		ratesContainer.clickHome.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}
	
	public static void selectRoomType() {
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		LOGGER.info("Selecting room types in Edit Rates");
		Util.waitTimeElementVisibility(ratesContainer.deselectEditRates);
		ratesContainer.deselectEditRates.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		LOGGER.info("Selecting Room");
		Util.waitTimeElementVisibility(ratesContainer.roomSelectEditRates);
		ratesContainer.roomSelectEditRates.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(ratesContainer.roomSelectedForEditRates);
		ratesContainer.roomSelectedForEditRates.click();
	}
	
	public static void selectDateRange() {
		
		LOGGER.info("Selecting Date Range");
		Util.waitTimeElementVisibility(ratesContainer.fromDateEditRates);
		ratesContainer.fromDateEditRates.click();
		ratesContainer.fromDateEditRates.clear();
		ratesContainer.fromDateEditRates.sendKeys("03/10/2020");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}		
		Util.waitTimeElementVisibility(ratesContainer.toDateForEditRates);
		ratesContainer.toDateForEditRates.click();
		ratesContainer.toDateForEditRates.clear();
		ratesContainer.toDateForEditRates.sendKeys("03/11/2020");
	}
	
	public static void clickOnGoForRates() {
		LOGGER.info("Clicking on the Go Button");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(ratesContainer.goBtnForEditRates);
		ratesContainer.goBtnForEditRates.click();
		LOGGER.info("Clicked on the Go Button");
	}
	
	public static void editDateRate() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		int randomValue= (int)(Math.random()*10000);
		Util.waitTimeElementVisibility(ratesContainer.changeEditRates);
		ratesContainer.changeEditRates.click();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		ratesContainer.changeInputEditRates.sendKeys(String.valueOf(randomValue));
	}
	
	public static void submitNowRates() {
		try {
			((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("window.scrollTo(0, document.body.scrollHeight)");
			Util.waitTimeElementVisibility(ratesContainer.submitNowBtnForEditRates);
			LOGGER.info("clicking on submit now rates");
			int intTest = bd.findElements(By.xpath("//*[@id=\"layoutForm:submitNowButton\"]")).size();
			Assert.assertTrue("Failed, submit now rates Button is not present",intTest > 0);
			
			ratesContainer.submitNowBtnForEditRates.click();
			Thread.sleep(3000);
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void submitRates() {
		try {
			((JavascriptExecutor) BrowserDriver.getCurrentDriver()).executeScript("window.scrollTo(0, document.body.scrollHeight)");
			Util.waitTimeElementVisibility(ratesContainer.submitBtnForEditRates);
			LOGGER.info("clicking on submit rates");
			int intTest = bd.findElements(By.xpath("//*[@id=\"layoutForm:btnSubmit\"]")).size();
			Assert.assertTrue("Failed, submit rates Button is not present",intTest > 0);
			
			ratesContainer.submitBtnForEditRates.click();
			Thread.sleep(3000);
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/* Feature File: 17_search_rate.feature */
	
	public static void selectRateSearchQuery() {
		LOGGER.info("Inside select Rates:");
		Actions action = new Actions(BrowserDriver.getCurrentDriver());
		WebElement we = BrowserDriver
				.getCurrentDriver()
				.findElement(
						By.xpath("//*[@id='layoutForm:menuPanel']/div/ul/li[5]/a/span[2]"));
		action.moveToElement(we).build().perform();
		
		Util.waitTimeElementVisibility(ratesContainer.selectRateSearch);
		ratesContainer.selectRateSearch.click();
	}
	
	public static void selectSearchRoomType()
	{
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(ratesContainer.selectRoomType);
		ratesContainer.selectRoomType.click();
	}
	
	public static void selectChannelDropDown()
	{
		Util.waitTimeElementVisibility(ratesContainer.channelDropdown);
		ratesContainer.channelDropdown.click();
		try
		{
			Thread.sleep(5000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(ratesContainer.selectMlife);
		ratesContainer.selectMlife.click();
	}

	public static void stayDate() {
		Util.waitTimeElementVisibility(ratesContainer.stayDate);
		ratesContainer.stayDate.clear();
		try
		{
			Thread.sleep(5000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();;
		}
		ratesContainer.stayDate.sendKeys("03/03/2020");
		
	}
	public static void searchRate() {
		try
		{
			Thread.sleep(3000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();;
		}
		Util.waitTimeElementVisibility(ratesContainer.searchRate);
		ratesContainer.searchRate.click();
		try
		{
			Thread.sleep(10000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();;
		}
		
	}

	public static void availableRecords() {
		try{
			Thread.sleep(5000);
			LOGGER.info("Checking if Active Rates are displayed");
			WebElement select = BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id=\"layoutForm:rateResultTable_data\"]/tr"));
			List<WebElement> options = select.findElements(By.tagName("td"));
	        if(options.size()>1)
	        {
	        	LOGGER.info("I am able to see Active records");	
	        }	
		}catch(Exception e){
			e.printStackTrace();
		}  	
	}	
	
}
