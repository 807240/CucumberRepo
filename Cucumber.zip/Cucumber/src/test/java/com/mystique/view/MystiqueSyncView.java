package com.mystique.view;

import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.MystiqueSyncContainer;
import com.mystique.utils.CommonUtils;

public class MystiqueSyncView {

	private static final Logger LOGGER = Logger.getLogger(MystiqueSyncView.class.getName());
	private static final MystiqueSyncContainer syncContainer = PageFactory.initElements(BrowserDriver.getCurrentDriver(), MystiqueSyncContainer.class);

	static WebDriver bd = BrowserDriver.getCurrentDriver();
	static CommonUtils Util=new CommonUtils();
	public static void selectGeneralAdmin() {
		Util.waitTimeElementVisibility(syncContainer.generalAdminDropDown);
		syncContainer.generalAdminDropDown.click();
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info("Clicking on General Administration drop down");
		Util.waitTimeElementVisibility(syncContainer.selectGeneralAdmin);
		syncContainer.selectGeneralAdmin.click();
		/*try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/

	}

	public static void hoverOnSyncTab() {
		LOGGER.info("Inside select sync:");
		try {
			Thread.sleep(25000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	

		Actions action = new Actions(BrowserDriver.getCurrentDriver());
		WebElement we = BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:menuBar']/ul/li[5]/a"));
		action.moveToElement(we).build().perform();

		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}		

	}

	public static void clickSyncToPartnerTab() {
		
		try {
			Util.waitTimeElementVisibility(syncContainer.clickSyncToPartner);
			Assert.assertTrue("PASS, Sync Channel is present",syncContainer.clickSyncToPartner.isDisplayed());
			syncContainer.clickSyncToPartner.click();
			Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

	public static void selectInputForSync() {
		Util.waitTimeElementVisibility(syncContainer.clickOnChannelDropDown);
		syncContainer.clickOnChannelDropDown.click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		Util.waitTimeElementVisibility(syncContainer.SelectChannel);
		syncContainer.SelectChannel.click();
	/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(syncContainer.clickOnPropertyDropDown);
		syncContainer.clickOnPropertyDropDown.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(syncContainer.selectPropertyDropDown);
		syncContainer.selectPropertyDropDown.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(syncContainer.clickOnSync);
		syncContainer.clickOnSync.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(syncContainer.clickAvailableResource);
		syncContainer.clickAvailableResource.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(syncContainer.activateAvailableResource);
		syncContainer.activateAvailableResource.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(syncContainer.clickOnSync);
		syncContainer.clickOnSync.click();
	/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(syncContainer.deactivateAvailableResource);
		syncContainer.deactivateAvailableResource.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(syncContainer.clickAvailableResource);
		syncContainer.clickAvailableResource.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(syncContainer.activateAvailableResource);
		syncContainer.activateAvailableResource.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(syncContainer.clickAvailableResource);
		syncContainer.clickAvailableResource.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(syncContainer.activateAvailableResource);
		syncContainer.activateAvailableResource.click();
	/*	try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(syncContainer.clickOnSync);
		syncContainer.clickOnSync.click();
		/*try {
			Thread.sleep(25000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(syncContainer.deactivateAvailableResource);
		syncContainer.deactivateAvailableResource.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
		Util.waitTimeElementVisibility(syncContainer.activateAllAvailableResource);
		syncContainer.activateAllAvailableResource.click();
		/*try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}*/
	}

	public static void clickOnSync() {
		
		try {
			Util.waitTimeElementVisibility(syncContainer.clickOnPropertyDropDown);
			Assert.assertTrue("PASS, Property DropDown is present",syncContainer.clickOnPropertyDropDown.isDisplayed());
			syncContainer.clickOnSync.click();
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}	
	}
}
