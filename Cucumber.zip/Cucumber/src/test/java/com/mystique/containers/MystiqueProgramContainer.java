package com.mystique.containers;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MystiqueProgramContainer {
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:applicationSelectMenu']/div[3]/span")
	public WebElement campaignAdminDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:applicationSelectMenu_panel']/div[1]/ul/li[2]")
	public WebElement selectCampaignAdmin;
	
	/*@FindBy(how = How.ID, using = "layoutForm:applicationSelectMenu")
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:applicationSelectMenu']/div[3]/span")
	public WebElement applicationSelectionDropDown;
		
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:applicationSelectMenu_panel']/div/ul/li[1]")
	public WebElement applicationSelection;*/

	//@FindBy(how = How.ID, using = "layoutForm:propertySelectMenu")
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:propertySelectMenu']/div[3]/span")
	public WebElement propertyMenuSelectionDropDown;
	
	@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:ccAuth']/span")
	public WebElement CreditCardAuthorization_link;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:propertySelectMenu_panel']/div/ul/li[2]")
	public WebElement propertyMenuSelection;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateCategory_panel']/ul/li")
	public WebElement operaCodeDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:propertySelectMenu_panel']/div/ul/li[6]")
	public WebElement propertyMenuSelectionBorgata;
	
	@FindBy(how = How.ID, using = "layoutForm:menuPanel")
	public WebElement programMenu;
	
	/*
	 * Manage Segment
	 */
	
	@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:setSegment']/span")
	public WebElement manageSegments;
	
	
	/*
	 * Manage Program
	 */
	
	@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:setProgram']/span")
	public WebElement managePrograms;

		
	@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:setAllProgram']/span")
	public WebElement allPrograms;
	
	@FindBy(how = How.ID, using = "layoutForm:createProgram")
	public WebElement createProgramLink;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:filter']/tbody/tr/td[1]/div/div[2]")
	public WebElement selectInactivePrograms;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:filter']/tbody/tr/td[3]/div/div[2]")
	public WebElement selectActivePrograms;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:filter']/tbody/tr/td[5]/div/div[2]")
	public WebElement selectAllPrograms;
	
	//@FindBy(how = How.XPATH, xpath = "(//*[contains(text(),'Edit')])[2]")
	@FindBy(how = How.ID, using = "layoutForm:dataTable:0:editButton")
	public WebElement editProgramLink;
	
	
	@FindBy(how = How.XPATH, xpath = "//li[contains(text(),'Expand All')]")
	public WebElement expandAll;
	
	@FindBy(how = How.ID, using = "layoutForm:dataTable:0:addRoutingLink")
	public WebElement inheritProgramLink;
	
	@FindBy(how = How.ID, using = "layoutForm:saveButton")
	public WebElement saveProgram;

	@FindBy(how = How.XPATH, xpath = "//button[@id = 'layoutForm:alertOkButton']")
	public WebElement OKTierErrorMessae;
	
	@FindBy(how = How.XPATH, xpath = "//P[contains(.,'Tier Credit Range \"To\" must be greater than or equal to Tier Credit Range \"From\"!')]")
	public WebElement TierRangeErrorMessage;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:saveButton']/span")
	public WebElement ticketProgramSave;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:category']/div[3]/span")
	public WebElement programCategoryDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:category_panel']/div/ul/li[1]")
	public WebElement selectProgramCategory;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:category_panel']/div/ul/li[2]")
	public WebElement selectProgramCategoryEdit;
	
	@FindBy(how = How.XPATH, xpath = "//p[contains(.,'Program/RoomRate Plan Saved')]")
	public WebElement ProgramSavedMessage;
	
	@FindBy(how = How.ID, using = "layoutForm:name")
	public WebElement programName;
	
	@FindBy(how = How.ID, using = "layoutForm:userProgramId")
	public WebElement userProgramId;
	
	@FindBy(how = How.ID, using = "layoutForm:theo")
	public WebElement programTheo;
	
	@FindBy(how = How.ID, using = "layoutForm:tag1_input")
	public WebElement programTag1Input;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:tag1_panel']/ul/li[1]")
	public WebElement selectProgramTag1;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:tag1_panel']/ul/li[1]")
	public WebElement selectProgramTag1Edit;
	
	@FindBy(how = How.ID, using = "layoutForm:btnAdd0")
	public WebElement addProgramTagButton;
	
	@FindBy(how = How.ID, using = "layoutForm:tag2_input")
	public WebElement programTag1Input2;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:tag2_panel']/ul/li[1]")
	public WebElement selectProgramTag2;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:tag2_panel']/ul/li[1]")
	public WebElement selectProgramTag2Edit;
	
	@FindBy(how = How.ID, using = "layoutForm:btnDelete2")
	public WebElement deleteProgramTag3Button;
	
	@FindBy(how = How.ID, using = "layoutForm:customerValueFrom")
	public WebElement customerValueFromInput;
	
	@FindBy(how = How.ID, using = "layoutForm:customerValueTo")
	public WebElement customerValueToInput;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:reservationTypeId']/div[3]/span")
	public WebElement reservationTypeDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:reservationTypeId_panel']/div/ul/li[2]")
	public WebElement selectProgramReservationType;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:depositRuleId']/div[3]/span")
	public WebElement depositRuleDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:depositRuleId_panel']/div/ul/li[2]")
	public WebElement selectProgramDepositRule;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:cancellationPolicyId']/div[3]/span")
	public WebElement cancellationPolicyDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:cancellationPolicyId_panel']/div/ul/li[2]")
	public WebElement selectProgramCancellationPolicy;
	
	@FindBy(how = How.ID, using = "layoutForm:extraGuestCharge")
	public WebElement extraGuestCharge;
	
	@FindBy(how = How.ID, using = "layoutForm:commissionPercentage")
	public WebElement commissionPercentage;
	
	@FindBy(how = How.ID, using = "layoutForm:rateCategory_input")
	public WebElement operaRateCategory;
		
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateCategory_panel']/ul/li")
	public WebElement selectoperaRateCategory;
	
	@FindBy(how = How.ID, using = "layoutForm:operaCodeAutoComplete_input")
	public WebElement operaRateCode;
	
	@FindBy(how = How.ID, using = "layoutForm:transactionCode_input")
	public WebElement transactionCode;
	
	@FindBy(how = How.ID, using = "layoutForm:patronPromoAutoComplete")
	public WebElement patronPromotionId;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:basicpanel']/tbody/tr[1]/td")
	public WebElement clickHere;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:patronPromoAutoComplete_panel']/ul/li")
	public WebElement selectPatronPromotionId;
	
	@FindBy(how = How.ID, using = "layoutForm:publicPromotionName")
	public WebElement publicName;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:maxNights']/div[3]/span")
	public WebElement maxNightsDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:maxNights_panel']/div/ul/li[6]")
	public WebElement selectMaxNights;
	
	@FindBy(how = How.ID, using = "layoutForm:offerInterestCode")
	public WebElement offerForInterestCode;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:priorityRadio']/tbody/tr/td[3]/div/div[2]/span")
	public WebElement priorityRadio;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:bestOfferCheckbox']/div[2]")
	public WebElement enableBestOffer;
	
	@FindBy(how = How.ID, using = "layoutForm:description")
	public WebElement description;
	
	@FindBy(how = How.ID, using = "layoutForm:periodStartDate_input")
	public WebElement periodStartDate;
	
	@FindBy(how = How.ID, using = "layoutForm:periodEndDate_input")
	public WebElement periodEndDate;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:activateCheckbox']/div[2]")
	public WebElement activeCheck;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:isPublic']/div[2]")
	public WebElement publicCheck;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:bookableOnline']/div[2]")
	public WebElement bookableOnlineCheck;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:viewOnline']/div[2]")
	public WebElement viewOnlineCheck;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:bookablePropertySide']/div[2]")
	public WebElement bookableOnPropertySite;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:viewPropertySide']/div[2]")
	public WebElement viewOnPropertySite;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:availableInIce']/div[2]")
	public WebElement availableInIceCheck;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:pricingOptionLink']")
	public WebElement createNewPricingOptionLink;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:sunday']")
	public WebElement checkSunday;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:tuesday']")
	public WebElement checkTuesday;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:friday']")
	public WebElement checkFriday;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:wednesday']")
	public WebElement checkWednesday;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:saturday']")
	public WebElement checkSaturday;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:searchProgramLink']")
	public WebElement searchProgramLink;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:programName']")
	public WebElement searchProgramName;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:customerValueFrom']")
	public WebElement inputCustomerValueFrom;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:customerValueTo']")
	public WebElement inputCustomerValueTo;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:searchButton']")
	public WebElement searchButton;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:isBAR']/div[2]")
	public WebElement BAROffer;
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:activateCheckbox']/div[2]")
	public WebElement activeFlag;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:isPublic']/div[2]")
	public WebElement OfferPage;
	
	@FindBy(how = How.ID, using = "layoutForm:mlifeFromCode")
	public WebElement MLIFEUrl;
	
	@FindBy(how = How.ID, using = "layoutForm:mlifeFromCode")
	public WebElement MLIFEUrl1;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:activateCheckbox']/div[2]")
	public WebElement clickActive;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:mlifeURLButton']/span")
	public WebElement MLIFEUrlCopy;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:syncToOperaCheckbox']/div[2]")
	public WebElement checkSyncToOpera;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:discountType']/tbody/tr/td/div/div[2]")
	public WebElement amount;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:discountType']/tbody/tr/td[3]/div/div[2]")
	public WebElement percentage;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:discountType']/tbody/tr/td[5]/div/div[2]")
	public WebElement flat;
	
	@FindBy(how = How.ID, using = "layoutForm:syncToOpera")
	public WebElement syncToOpera;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:j_idt266']/a")
	public WebElement newPricingOptions;
	
	@FindBy(how = How.ID, using = "layoutForm:activeFlag")
	public WebElement activeLink;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:j_idt61']/tbody/tr/td[4]/div/div[2]")
	public WebElement pricingProgName;
	
	@FindBy(how = How.ID, using = "layoutForm:startDate_input")
	public WebElement bookingDate;
	
	@FindBy(how = How.ID, using = "layoutForm:endDate_input")
	public WebElement endDate;
	
	@FindBy(how = How.ID, using = "layoutForm:saveButton")
	public WebElement saveProgramPricing;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:parentPannel']/tbody/tr/td/div/div[2]")
	public WebElement rateTable;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:parentPannel']/tbody/tr/td[3]/div/div[3]")
	public WebElement dropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateTableId_panel']/div/ul/li[3]")
	public WebElement dropDownValue;
	
	@FindBy(how = How.ID, using = "layoutForm:discountValue")
	public WebElement value;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:priceRuleDTOList_data']/tr/td[3]/a")
	public WebElement editClick;
	
	@FindBy(how = How.ID, using = "layoutForm:userProgramId")
	public WebElement clickUserProgramID;
	
	
	@FindBy(how = How.XPATH, xpath ="//*[@id='layoutForm:routingInstructionPickList']/tbody/tr/td[1]/ul/li[1]")
	public WebElement pricingruleRIselect;
	
	@FindBy(how = How.XPATH, xpath ="//*[@id='layoutForm:routingInstructionPickList']/tbody/tr/td[2]/button[1]/span[2]")
	public WebElement ActiveRIpricing;
	
	
	@FindBy(how = How.XPATH, xpath ="//label[contains(.,'Tier Credit Range') and @class = 'ui-outputlabel']")
	public WebElement TierCreditLabel;
	

	@FindBy(how = How.ID, using ="layoutForm:tierCreditRangeFrom")
	public WebElement TierCreditFromTextBox;
	
	@FindBy(how = How.ID, using ="layoutForm:tierCreditRangeSrchFrom")
	public WebElement SrchTierCreditFromTextBox;
	
	@FindBy(how = How.ID, using ="layoutForm:tierCreditRangeSrchTo")
	public WebElement SrchTierCreditToTextBox;

	@FindBy(how = How.ID, using ="layoutForm:tierCreditRangeTo")
	public WebElement TierCreditToTextBox;
	
	@FindBy(how = How.XPATH, xpath ="//*[@data-item-label='NOIR']")
	public WebElement tierOption;
	
	@FindBy(how = How.XPATH, xpath ="//*[@id='layoutForm:pickList2']/tbody/tr/td[2]/button[1]/span[1]")
	public WebElement tierAdd;
	
	
	/*
	 * Pricing Option
	 */
	
	
	@FindBy(how = How.ID, using = "layoutForm:activeFlag")
	public WebElement activeCheckPricing;
	
	@FindBy(how = How.ID, using = "layoutForm:syncToOpera")
	public WebElement syncToOperaCheck;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:masterFlag']/div[2]")
	public WebElement masterCheckPricing;
	
	@FindBy(how = How.ID, using = "layoutForm:name")
	public WebElement pricingOptionName;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:opt1']/div[2]")
	public WebElement rateTableRadio;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateTableId']/div[3]/span")
	public WebElement parentRateTableDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateTableId_panel']/div/ul/li[2]")
	public WebElement selectParentRateTable;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateTableId_panel']/div/ul/li[3]")
	public WebElement selectParentRateTableEdit;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:opt2']/div[2]")
	public WebElement pricingProgramNameRadio;
	
	@FindBy(how = How.ID, using = "layoutForm:pricingProgramId_input")
	public WebElement pricingProgramName;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:pricingProgramId_panel']/ul/li[1]")
	public WebElement selectPricingProgramName;
	
	@FindBy(how = How.ID, using = "layoutForm:startDate_input")
	public WebElement pricingFromDate;
	
	@FindBy(how = How.ID, using = "layoutForm:endDate_input")
	public WebElement pricingToDate;
		
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:discountType']/tbody/tr[1]/td[5]/div/div[2]")
	public WebElement flatDiscountTypeCheck;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:discountType']/tbody/tr/td[3]/div/div[2]")
	public WebElement percentageDiscountTypeCheck;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:discountType']/tbody/tr/td[1]/div/div[2]")
	public WebElement amountDiscountTypeCheck;
	
	@FindBy(how = How.ID, using = "layoutForm:discountValue")
	public WebElement discountValue;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:extraNights']/div[3]/span")
	public WebElement compNightsDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:extraNights_panel']/div/ul/li[4]")
	public WebElement selectCompNights;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:extraNights_panel']/div/ul/li[1]")
	public WebElement selectCompNightZero;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:extraNights_panel']/div/ul/li[5]")
	public WebElement selectCompNightsEdit;
	
	@FindBy(how = How.ID, using = "layoutForm:discountFixed")
	public WebElement fixedRate;
	
	@FindBy(how = How.ID, using = "layoutForm:operaCodeId")
	public WebElement pricingOperaRateCode;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:operaCodeId_panel']/ul/li[1]")
	public WebElement selectPricingOperaRateCode;
	
	@FindBy(how = How.ID, using = "layoutForm:marketCode_input")
	public WebElement marketCode;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:marketCode_panel']/ul/li[1]")
	public WebElement selectMarketCode;
	
	@FindBy(how = How.ID, using = "layoutForm:sourceCode_input")
	public WebElement sourceCode;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:sourceCode_panel']/ul/li[1]")
	public WebElement selectSourceCode;
	
	@FindBy(how = How.ID, using = "layoutForm:packageName_input")
	public WebElement packageName;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:packageName_panel']/ul/li[1]")
	public WebElement selectPackageName;
		
	@FindBy(how = How.ID, using = "layoutForm:saveButton")
	public WebElement pricingOptionSave;
	
	@FindBy(how = How.ID, using = "layoutForm:back")
	public WebElement pricingOptionBack;
	
	/*
	 *End of Pricing Option
	 */
	
	@FindBy(how = How.XPATH, xpath = "//a[contains(text(),'Create New Routing Instruction')]")
	public WebElement createNewRoutingInstructionsLink;
	
	/*
	 * Routing Instructions
	 */
	
	@FindBy(how = How.ID, using = "layoutForm:name")
	public WebElement routingInstructionsName;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:routingType']/div[3]/span")
	public WebElement routingTypeDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:routingType_panel']/div/ul/li[1]")
	public WebElement selectRoutingType;
	
	@FindBy(how = How.ID, using = "layoutForm:authorizerAutoComplete_input")
	public WebElement authorizer;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:authorizerAutoComplete_panel']/ul/li")
	public WebElement selectAuthorizer;
	
	@FindBy(how = How.ID, using = "layoutForm:receiverId")
	public WebElement receiverId;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:activeFlag']/div[2]")
	public WebElement routingInstructionsActiveCheck;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:selectSunday']/div[2]")
	public WebElement checkSundayRI;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:selectTuesday']/div[2]")
	public WebElement checkTuesdayRI;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:selectFriday']/div[2]")
	public WebElement checkFridayRI;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:selectSaturday']/div[2]")
	public WebElement checkSaturdayRI;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dailyFlag']/div[2]")
	public WebElement DailyYNCheck;
		
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:mcn']/div[3]/span")
	public WebElement maxCompNightsDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:mcn_panel']/div/ul/li[5]")
	public WebElement selectMaxCompNights;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:mcn_panel']/div/ul/li[6]")
	public WebElement selectMaxCompNightsEdit;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:routingcodesPickList']/tbody/tr/td[1]/ul/li[1]")
	public WebElement selectRoutingCodes;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:routingcodesPickList']/tbody/tr/td[1]/ul/li[2]")
	public WebElement selectRoutingCodesEdit;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:routingcodesPickList']/tbody/tr/td[2]/button[1]")
	public WebElement activateRoutingCodes;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:windowSelect']/div[3]/span")
	public WebElement windowDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:routingType_panel']/div/ul/li[2]")
	public WebElement selectWindow;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:routingLimitType']/div[3]/span")
	public WebElement routingLimitTypeDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:routingLimitType_panel']/div/ul/li[2]")
	public WebElement selectRoutingLimitType;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:routingLimitType_panel']/div/ul/li[3]")
	public WebElement selectRoutingLimitTypeEdit;
	
	@FindBy(how = How.ID, using = "layoutForm:limit")
	public WebElement routingLimit;
	
	@FindBy(how = How.ID, using = "layoutForm:percent")
	public WebElement routingPercent;
	
	@FindBy(how = How.ID, using = "layoutForm:covers")
	public WebElement routingCovers;
	
	@FindBy(how = How.ID, using = "layoutForm:coupon")
	public WebElement routingCompOrCoupon;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:routingcategories']/tbody/tr/td[1]/ul/li[1]")
	public WebElement selectRoutingCategories;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:routingcategories']/tbody/tr/td[2]/button[1]")
	public WebElement activateRoutingCategories;
	
	@FindBy(how = How.ID, using = "layoutForm:saveButton")
	public WebElement routingInstructionsSave;
	
	@FindBy(how = How.ID, using = "layoutForm:back")
	public WebElement routingInstructionsBack;
	
	
	/*
	 * End of Routing Instructions
	 */
	
	@FindBy(how = How.ID, using = "layoutForm:promoCode")
	public WebElement promotionCode;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:operaGuaranteeCode']/div[3]/span")
	public WebElement operaGuaranteeCodeDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:operaGuaranteeCode_panel']/div/ul/li[2]")
	public WebElement selectOperaGuaranteeCode;
	
	@FindBy(how = How.ID, using = "layoutForm:promoGroup_label")
	public WebElement promoGroupDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:promoGroup_panel']/div/ul/li[2]")
	public WebElement selectPromoGroup;
	
	@FindBy(how = How.ID, using = "layoutForm:learnmoreDesc_iframe")
	public WebElement learnMoreDescription;
	
	@FindBy(how = How.ID, using = "layoutForm:travelPeriod_input")
	public WebElement travelPeriodStartDate;
	
	@FindBy(how = How.ID, using = "layoutForm:travelPeriodEnd_input")
	public WebElement travelPeriodEndDate;
	
	@FindBy(how = How.ID, using = "layoutForm:travelPeriod_input")
	public WebElement RestrictionStartDate;
	
	@FindBy(how = How.ID, using = "layoutForm:travelPeriodEnd_input")
	public WebElement RestrictionEndDate;
	
	@FindBy(how = How.ID, using = "layoutForm:bookBy_input")
	public WebElement bookByDate;
	
	@FindBy(how = How.ID, using = "layoutForm:termsAndConditions_iframe")
	public WebElement termsAndConditions;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:minimumNumberOfNightsSelect']/tbody/tr/td[3]/div/div[2]")
	public WebElement hasToStayCheck;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:minNights']/div[3]/span")
	public WebElement minSatyNightsDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:minNights_panel']/div/ul/li[3]")
	public WebElement selectMinSatyNights;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:minNights_panel']/div/ul/li[2]")
	public WebElement selectMinSatyNightsEdit;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:daysInAdvanceSelect']/tbody/tr/td[3]/div/div[2]")
	public WebElement hasToBookInAdvanceCheck;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:daysInAdvance']/div[3]/span")
	public WebElement minDaysInAdvanceDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:daysInAdvance_panel']/div/ul/li[3]")
	public WebElement selectMinDaysInAdvance;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:daysInAdvance_panel']/div/ul/li[3]")
	public WebElement selectMinDaysInAdvanceEdit;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:playerTierRadio']/tbody/tr/td[3]/div/div[2]")
	public WebElement specificTireCheck;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:hoursAfterEnrollment']/div[3]/span")
	public WebElement minHoursAfterEnrollmentDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:hoursAfterEnrollment_panel']/div/ul/li[13]")
	public WebElement selectMinHoursAfterEnrollment;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:hoursAfterEnrollment_panel']/div/ul/li[7]")
	public WebElement selectMinHoursAfterEnrollmentEdit;
	
	@FindBy(how = How.ID, using = "layoutForm:pickList2_source_filter")
	public WebElement tierInactiveSearch;
	
	@FindBy(how = How.ID, using = "layoutForm:pickList2_target_filter")
	public WebElement tierActiveSearch;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:pickList2']/tbody/tr/td[1]/ul/li[4]")
	public WebElement selectTier;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:pickList2']/tbody/tr/td[1]/ul/li[4]")
	public WebElement selectTierEdit;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:pickList2']/tbody/tr/td[2]/button[4]")
	public WebElement inActivateTier;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:pickList2']/tbody/tr/td[2]/button[1]")
	public WebElement activateTier;
	
	@FindBy(how = How.ID, using = "layoutForm:agentsText_iframe")
	public WebElement agentText;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:paymentTypeRadio']/tbody/tr/td[3]/div/div[2]")
	public WebElement selectPaymentTypeCheck;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:pickList3']/tbody/tr/td[1]/ul/li[1]")
	public WebElement selectPaymentType;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:pickList3']/tbody/tr/td[2]/button[4]")
	public WebElement inActivatePaymentType;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:pickList3']/tbody/tr/td[2]/button[1]")
	public WebElement activatePaymentType;
	
	@FindBy(how = How.ID, using = "layoutForm:roomPickList2_source_filter")
	public WebElement associateRoomInactiveSearch;
	
	@FindBy(how = How.ID, using = "layoutForm:roomPickList2_target_filter")
	public WebElement associateRoomActiveSearch;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:roomPickList2']/tbody/tr/td[1]/ul/li[1]")
	public WebElement selectAssociateRooms;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:syncRoomsPickList']/tbody/tr/td[1]/ul/li[1]")
	public WebElement selectAssociateSyncRooms;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:roomPickList2']/tbody/tr/td[1]/ul/li[1]")
	public WebElement selectAssociateRoomsEdit;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:roomPickList2']/tbody/tr/td[2]/button[1]")
	public WebElement activateAssociateRooms;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:syncRoomsPickList']/tbody/tr/td[2]/button[1]")
	public WebElement activateAssociateSyncRooms;
	
	@FindBy(how = How.XPATH, xpath = "//*[contains(@onclick,'layoutForm:priceRuleDTOList')]")
	public WebElement editPricingOption;
	
	@FindBy(how = How.ID, using = "layoutForm:priceRuleDTOList:0:deletePricingRule")
	public WebElement deletePricingRule;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:routingInstructionDTOList_data']/tr/td[2]/a")
	public WebElement editRoutingInstructions;
	
	@FindBy(how = How.ID, using = "layoutForm:routingInstructionDTOList:1:deleteRoutingInstructions")
	public WebElement deleteRoutingInstructions;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:valueAddBy']/tbody/tr/td[5]/div/div[2]")
	public WebElement valueAddedByManual;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:valueAddBy']/tbody/tr/td[1]/div/div[2]")
	public WebElement valueAddedByNone;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:priceby']/tbody/tr/td/div/div[2]")
	public WebElement priceByPerDay;
	
	@FindBy(how = How.ID, using = "layoutForm:valueid")
	public WebElement priceByValueLink;
	

	@FindBy(how = How.ID, using = "layoutForm:dataTable:Name:filter")
	public WebElement searchName;
	
	@FindBy(how = How.ID, using = "layoutForm:dataTable:0:editButton")
	public WebElement editPricingProgramLink;
	

	/*
	 * Media
	 */
	
	@FindBy(how = How.ID, using = "layoutForm:dataTable:0:mediaButton")
	public WebElement mediaLink;
	
	@FindBy(how = How.ID, using = "layoutForm:createMediaButton")
	public WebElement createMedia;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:mediaType']/div[3]/span")
	public WebElement mediaTypeDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:mediaType_panel']/div/ul/li[1]")
	public WebElement selectMediaType;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:group']/div[3]/span")
	public WebElement groupDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:group_panel']/div/ul/li[1]")
	public WebElement selectGroup;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:subGroup']/div[3]/span")
	public WebElement subGroupDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:subGroup_panel']/div/ul/li[1]")
	public WebElement selectSubGroup;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:scope']/div[3]/span")
	public WebElement scopeDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:scope_panel']/div/ul/li[1]")
	public WebElement selectScope;
	
	@FindBy(how = How.ID, using = "layoutForm:activeFlag")
	public WebElement mediaActiveFlag;
	
	@FindBy(how = How.ID, using = "layoutForm:mediaAltText_text")
	public WebElement mediaAltText;
	
	@FindBy(how = How.ID, using = "layoutForm:saveButton")
	public WebElement mediaSave;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:mediaTree_node_0']/td[1]/span")
	public WebElement mediaLogo;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:mediaTree_node_0_0']/td[1]/span[2]")
	public WebElement mediaMonochrome;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:mediaTree_node_0_0_0']/td[1]/span[3]")
	public WebElement mediaTiny;
	
	@FindBy(how = How.ID, using = "layoutForm:mediaTree:0_0_0_0:editButton")
	public WebElement mediaEdit;
	
	@FindBy(how = How.ID, using = "layoutForm:program_parent")
	public WebElement backToProgram;
	
	/*
	 * Program Filter
	 */
	
	@FindBy(how = How.ID, using = "layoutForm:dataTable:Name:filter")
	public WebElement searchProgram;
	
	/*
	 * Program Inherit
	 */
	
	@FindBy(how = How.ID, using = "layoutForm:dataTable:0:addRoutingLink")
	public WebElement inheritLink;
	
	@FindBy(how = How.ID, using = "layoutForm:baseProgramName")
	public WebElement parentProgramName;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:priceRuleDTOList_data']/tr/td[1]")
	public WebElement parentPricingOption;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:routingInstructionDTOList_data']/tr/td[1]")
	public WebElement parentRoutingInstruction;
	
	@FindBy(how = How.ID, using = "layoutForm:category_label")
	public WebElement parentCategory;
	
	@FindBy(how = How.ID, using = "layoutForm:rateTableId_label")
	public WebElement parentPricingRuleRateTable;
	
	@FindBy(how = How.ID, using = "layoutForm:routingType_label")
	public WebElement parentRoutingInstructionRoutingType;
	
	
	
	/*
	 * Child Program Inherit
	 */
	@FindBy(how = How.ID, using = "layoutForm:dataTable:0:addRoutingLink")
	public WebElement inheritChildProgramLink;
	
	@FindBy(how = How.ID, using = "layoutForm:baseProgramName")
	public WebElement grandParentProgramName;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:priceRuleDTOList_data']/tr/td[1]")
	public WebElement grandParentPricingOption;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:routingInstructionDTOList_data']/tr/td[1]")
	public WebElement grandParentRoutingInstruction;
	
	/*
	 * Check Inherit Program
	 */
	
	@FindBy(how = How.ID, using = "layoutForm:dataTable:0:editLink")
	public WebElement inheritChildProgramEditLink;	
	
	@FindBy(how = How.ID, using = "layoutForm:dataTable:0:editLink")
	public WebElement inheritGrandChildProgramEditLink;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:alertDialogVal']/div[3]/div/button")
	public WebElement clickAlertOk;
	
	@FindBy(how = How.ID, using = "layoutForm:okButton")
	public WebElement clickAlertOkTmp;
	 
	
	/*
	 * Manage Ticket Program
	*/

    @FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:setTicketProgram']/span")
    public WebElement manageTicketPrograms;

    @FindBy(how = How.ID, using = "layoutForm:createProgram")
    public WebElement createTicketProgramLink;

    @FindBy(how = How.ID, using = "layoutForm:saveButton")
	public WebElement saveTicketProgram;
		
    @FindBy(how = How.ID, using = "layoutForm:name")
	public WebElement ticketprogramName;
	
    @FindBy(how = How.ID, using = "layoutForm:tag1_input")
	public WebElement ticketprogramTag1Input;
	
    @FindBy(how = How.ID, using = "layoutForm:btnAdd0")
	public WebElement addticketProgramTagButton;
	
    @FindBy(how = How.ID, using = "layoutForm:tag2_input")
	public WebElement ticketprogramTag1Input2;

    @FindBy(how = How.ID, using = "layoutForm:btnDelete2")
	public WebElement deleteticketProgramTag3Button;
    
    @FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:showDisplayPanel']/div/span")
	public WebElement seasonsTypeDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:showDisplayPanel_panel']/div/ul/li[2]")
	public WebElement selectTicketProgramSeasonType;
	
	@FindBy(how = How.ID, using = "layoutForm:bookStart_input")
	public WebElement bookingStartDate;
	
	@FindBy(how = How.ID, using = "layoutForm:bookEnd_input")
	public WebElement bookingEndDate;
	
	@FindBy(how = How.ID, using = "layoutForm:eventStartM_input")
	public WebElement performanceStartDateInRestriction;
	
	@FindBy(how = How.ID, using = "layoutForm:eventEndM_input")
	public WebElement performanceEndDateInRestriction;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:showDisplayPanel']/div[3]/span")
	public WebElement seasons;
	 
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:showDisplayPanel_panel']/div/ul/li[2]")
	public WebElement seasonsSelect;

   /*
   *  Edit ticket program
   */
	
	@FindBy(how = How.ID, using = "layoutForm:ticketProgramTable:0:editLink")
	public WebElement editManageTicketProgramLink;

	/*
	 * Delete ticket program
	 */

	/*@FindBy(how = How.ID, using = "layoutForm:ticketProgramTable:0:deleteButton")
	public WebElement deleteManageTicketProgramLink;*/
	
	@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:j_idt59:region']/ul/li[1]")
	public WebElement clickregion_LasVegas;
	
	@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:j_idt59:propertyList']/ul/li[1]")
	public WebElement clickproperty_delano;
	
	@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:searchButton']")
	public WebElement allProgramSearchBtn;
	
	@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:allProgramList']/div[1]/a")
	public WebElement allProgramExportlnk;
	
	@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:alertDialogVal']/div[1]")
	public WebElement alertDialogbox;
	
	@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:alertDialogVal']/div[1]/a/span")
	public WebElement alertCloseBtn;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:priceRuleDTOList_data']/tr/td[5]/a")
	public WebElement editPricingRule;
	
	@FindBy(how = How.ID, using = "layoutForm:suppressRate")
	public WebElement supressRate;
	
	@FindBy(how = How.ID, using = "layoutForm:printRate")
	public WebElement printRate;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:showInICE']/div[2]")
	public WebElement ShowinICE_checkbox;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:fieldSource_data']/tr[1]/td[1]/div/div[2]")
	public WebElement FormFields_checkbox;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:messages_container']/div/div/div[2]/span")
	public WebElement validation_cca_save;
 
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:ltr']/span[1]")
	public WebElement FormFields_singlemovearrow;
	
	@FindBy(how = How.ID, using = "layoutForm:faxNumber")
	public WebElement faxnumber;
	
	@FindBy(how = How.ID, using = "layoutForm:saveButton")
	public WebElement savebtn_cca;
	
	@FindBy(how = How.XPATH, using = "/html/body")
	public WebElement headerinput;
	
	@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:fieldSource_paginator_bottom']/span[3]/span[1]")
	public WebElement header_cca;
	
 

	
} 

