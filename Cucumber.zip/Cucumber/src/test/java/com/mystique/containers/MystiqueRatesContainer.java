package com.mystique.containers;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
public class MystiqueRatesContainer {
	
	/*
	 * Manage Spreads test
	 */
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:ratesMenu']/a/span[2]")
	public WebElement rates;
	
	@FindBy(how = How.ID, using = "layoutForm:ratesMenu")
	public WebElement ratesMenu;

	@FindBy(how = How.ID, using = "layoutForm:manageSpread")
	public WebElement manageSpreads;
	
	@FindBy(how = How.ID, using = "layoutForm:selectDate_input")
	public WebElement selectDate;
	
	@FindBy(how = How.ID, using = "layoutForm:activeFlag_label")
	public WebElement searchBystatusDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:activeFlag_panel']/div/ul/li[2]")
	public WebElement selectSearchByStatus2;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:activeFlag_panel']/div/ul/li[3]")
	public WebElement selectSearchByStatus3;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:activeFlag_panel']/div/ul/li[1]")
	public WebElement selectSearchByStatus1;

	@FindBy(how = How.ID, using = "layoutForm:btnSearch")
	public WebElement searchRateSpreads;
	
	@FindBy(how = How.ID, using = "layoutForm:dataTable:0:editButton")
	public WebElement editRateTableSpread;
	
	@FindBy(how = How.ID, using = "layoutForm:createRateTableSpreadBtn")
	public WebElement createRateTableSpread;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateTable']/tbody/tr/td/ul/li[2]")
	public WebElement rateTableSelect;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:roomPickList']/tbody/tr/td/ul/li[1]")
	public WebElement syncRoomToOperaSelect;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:roomPickList']/tbody/tr/td[2]/button")
	public WebElement manageRateTableActiveButton;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateTable']/tbody/tr/td[2]/button")
	public WebElement rateTableActiveButton;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateTable']/tbody/tr[1]/td[2]/button[4]")
	public WebElement rateTableDeactiveButton;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:baseRoomType']/div[3]")
	public WebElement baseRoomTypeDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:baseRoomType_panel']/div/ul/li[6]")
	public WebElement baseRoomTypeSelection;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:baseRoomType_panel']/div/ul/li[4]")
	public WebElement identicalBaseRoomRoom;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:roomType']/div[3]")
	public WebElement roomTypeDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:roomType_panel']/div/ul/li[7]")
	public WebElement roomTypeSelection;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:roomType_panel']/div/ul/li[12]")
	public WebElement identicalRoomBaseRoom;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:selectedSpreadBy']/tbody/tr[1]/td[1]/div/div[2]")
	public WebElement selectedRateSpreadBy;
	
	@FindBy(how = How.ID, using = "layoutForm:travelFrom_input")
	public WebElement travelFromInput;
	
	@FindBy(how = How.ID, using = "layoutForm:travelTo_input")
	public WebElement travelToInput;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:daysOfWeek']/tbody/tr[1]/td[1]/div/div[2]")
	public WebElement selectSundayRate;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:daysOfWeek']/tbody/tr[1]/td[3]/div/div[2]")
	public WebElement selectMondayRate;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:daysOfWeek']/tbody/tr[1]/td[11]/div/div[2]")
	public WebElement selectFridayRate;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:daysOfWeek']/tbody/tr[1]/td[13]/div/div[2]")
	public WebElement selectSaturdayRate;
	
	@FindBy(how = How.ID, using = "layoutForm:baseRateFrom")
	public WebElement baseRateFrom;
	
	@FindBy(how = How.ID, using = "layoutForm:baseRateTo")
	public WebElement baseRateTo;
	
	@FindBy(how = How.ID, using = "layoutForm:conflictingSprd")
	public WebElement conflictingSpread;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:spreadRadio']/tbody/tr[1]/td[1]/div/div[2]")
	public WebElement selectRateSpreadAmount;
	
	@FindBy(how = How.ID, using = "layoutForm:spreadValue")
	public WebElement rateSpreadValue;
	
	@FindBy(how = How.ID, using = "layoutForm:testDate_input")
	public WebElement testDateInput;
	
	/*@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:testRate']/tbody/tr[1]/td[1]/div/div[2]")
	public WebElement rateTestRate;*/
	
	@FindBy(how = How.ID, using = "layoutForm:testRate")
	public WebElement rateTestRate;
	
	@FindBy(how = How.ID, using = "layoutForm:previewBtn")
	public WebElement previewRateButton;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:alertDialogVal']/div/div[2]/button/span")
	public WebElement alertButton;
	
	/*@FindBy(how = How.ID, using = "layoutForm:previewBtn")
	public WebElement alertButton;
	*/
	@FindBy(how = How.ID, using = "layoutForm:applySpreadBtn")
	public WebElement reviewRateSpreadButton;
	
	@FindBy(how = How.ID, using= "layoutForm:applySpreadBtn")
	public WebElement applySpreadButton;
	
	/*
	 * Delete Rate Spread
	 */
	
	@FindBy(how = How.ID, using= "layoutForm:dataTable:0:deleteButton")
	public WebElement deleteRateSpread;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:confirmDialogVal']/div[3]/div/button/span")
	public WebElement confirmDialoge;
	
	/*
	 * Manage Change Set
	 */
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:manageChangeSet']/span")
	public WebElement manageChangeSet;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateTable']/tbody/tr/td[2]/button[2]")
	public WebElement activateRateButton;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateTable']/tbody/tr/td[2]/button[4]")
	public WebElement deactivateRateButton;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:status']/tbody/tr/td[2]/button[2]")
	public WebElement activateStatusButton;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:status']/tbody/tr/td[2]/button[4]")
	public WebElement deactivateStatusButton;
	
	@FindBy(how = How.ID, using = "layoutForm:fromInputDate_input")
	public WebElement fromInputDate;
	
	@FindBy(how = How.ID, using = "layoutForm:toInputDate_input")
	public WebElement toInputDate;
	
	@FindBy(how = How.ID, using = "layoutForm:fromScheduleDate_input")
	public WebElement fromScheduleDate;
	
	@FindBy(how = How.ID, using = "layoutForm:toScheduleDate_input")
	public WebElement toScheduleDate;
	
	@FindBy(how = How.ID, using = "layoutForm:fromStayDate_input")
	public WebElement fromStayDate;
	
	@FindBy(how = How.ID, using = "layoutForm:toStayDate_input")
	public WebElement toStayDate;
	
	@FindBy(how = How.ID, using = "layoutForm:comments")
	public WebElement manageChangeSetComments;
	
	@FindBy(how = How.ID, using = "layoutForm:users_input")
	public WebElement manageChangeSetUsers;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:users_panel']/ul/li[1]")
	public WebElement selectUser;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:users']/ul/li[1]/span[2]")
	public WebElement deselectUser;
	
	@FindBy(how = How.ID, using = "layoutForm:changeSet_input")
	public WebElement changeSetName;
	
	@FindBy(how = How.ID, using = "layoutForm:btnGo")
	public WebElement btnGo;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:roomType']/div[3]")
	public WebElement filterRoom;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:roomType_panel']/div/ul/li[2]")
	public WebElement roomDropDown;
	
	@FindBy(how = How.ID, using = "layoutForm:changeSetGrid:1:editLink")
	public WebElement changeSetEditLink;
	
	@FindBy(how = How.ID, using = "layoutForm:changeSetGrid:filterRateTable:filter")
	public WebElement filterChangeSet;
	
	//@FindBy(how = How.ID, using = "layoutForm:changeSetGrid:changeSetColumn:filter")
	//public WebElement changeRates;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:fromDate']/button")
	public WebElement changeRatesFromDateButton;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='ui-datepicker-div']/div/a[2]/span")
	public WebElement nextMonthFrom;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='ui-datepicker-div']/table/tbody/tr[1]/td[5]")
	public WebElement changeRatesFromDate;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:toDate']/button")
	public WebElement changeRatesToDateButton;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='ui-datepicker-div']/div/a[1]/span")
	public WebElement previousMonthTo;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='ui-datepicker-div']/div/a[2]/span")
	public WebElement nextMonthTo;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='ui-datepicker-div']/table/tbody/tr[4]/td[3]")
	public WebElement changeRatesToDate;
	
	@FindBy(how = How.ID, using = "layoutForm:cancelChange")
	public WebElement cancelChangeBtn;
	
	@FindBy(how = How.ID, using = "layoutForm:editDerivedValue")
	public WebElement editDerivedValue;
	
	@FindBy(how = How.ID, using = "layoutForm:editArcValue")
	public WebElement editArcValue;
	
	//@FindBy(how = How.ID, using = "layoutForm:rateGrid:0:roomType0Val")
	//public WebElement roomType0Val0;
	
	//@FindBy(how = How.ID, using = "layoutForm:rateGrid:0:lb11")
	//public WebElement roomType1Val1Click;
	
	//@FindBy(how = How.ID, using = "layoutForm:rateGrid:0:roomType1Val")
	//public WebElement roomType1Val1;
	
	//@FindBy(how = How.ID, using = "layoutForm:rateGrid:1:lb10")
	//public WebElement roomType1Val4Click;
	
	//@FindBy(how = How.ID, using = "layoutForm:rateGrid:1:roomType0Val")
	//public WebElement roomType1Val4;
	
	//@FindBy(how = How.ID, using = "layoutForm:rateGrid:0:roomType0ArcFlag")
	//public WebElement roomType0ArcFlag0;
	
	//@FindBy(how = How.ID, using = "layoutForm:rateGrid:0:roomType1ArcFlag")
	//public WebElement roomType0ArcFlag1;
	
	//@FindBy(how = How.ID, using = "layoutForm:rateGrid:1:roomType0ArcFlag")
	//public WebElement roomType1ArcFlag0;
	
	@FindBy(how = How.ID, using = "layoutForm:btnSave")
	public WebElement saveRates;
	
	@FindBy(how = How.ID, using = "layoutForm:submitNowButton")
	public WebElement reviewRates;
	
	@FindBy(how = How.ID, using = "layoutForm:btnSubmit")
	public WebElement changeReviewedRates;
	
	@FindBy(how = How.ID, using = "layoutForm:gobackButton")
	public WebElement backButton;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:successDisplay']/tbody/tr[1]/td/a")
	public WebElement gobackButton;
	
	
	
	@FindBy(how = How.ID, using = "layoutForm:scheduleLaterButton")
	public WebElement scheduleLaterButton;
	
	@FindBy(how = How.ID, using = "layoutForm:scheduleDateTime_input")
	public WebElement scheduleDateTime;
	
	@FindBy(how = How.ID, using = "layoutForm:schedule_btn")
	public WebElement scheduleBtn;
	
	@FindBy(how = How.ID, using = "layoutForm:btnSchedule")
	public WebElement btnSchedule;
	
	@FindBy(how = How.ID, using = "layoutForm:rate_label")
	public WebElement massRateChangeLink;
	
	@FindBy(how = How.ID, using = "layoutForm:fromDateRange_input")
	public WebElement massDateRangeFrom;
	
	@FindBy(how = How.ID, using = "layoutForm:toDateRange_input")
	public WebElement massDateRangeTo;
	
	@FindBy(how = How.ID, using = "layoutForm:cancelBtn")
	public WebElement massDateRateCancel;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:daysSelected']/tbody/tr[1]/td[1]/div/div[2]")
	public WebElement selectSunday;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:daysSelected']/tbody/tr[1]/td[3]/div/div[2]")
	public WebElement selectMonday;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:daysSelected']/tbody/tr[1]/td[5]/div/div[2]")
	public WebElement selectTuesday;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:daysSelected']/tbody/tr[1]/td[7]/div/div[2]")
	public WebElement selectWednesday;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:daysSelected']/tbody/tr[1]/td[9]/div/div[2]")
	public WebElement selectThusday;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:daysSelected']/tbody/tr[1]/td[11]/div/div[2]")
	public WebElement selectFriday;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:daysSelected']/tbody/tr[1]/td[13]/div/div[2]")
	public WebElement selectSaturday;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:roomType']/tbody/tr[1]/td[1]/ul/li[1]")
	public WebElement massRoomTypeSelection1;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:roomType']/tbody/tr[1]/td[1]/ul/li[2]")
	public WebElement massRoomTypeSelection2;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:roomType']/tbody/tr[1]/td[2]/button[1]")
	public WebElement massRoomTypeActivation;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateCalcType']/tbody/tr[3]/td[1]/div/div[2]")
	public WebElement massRateType;
	
	@FindBy(how = How.ID, using = "layoutForm:rateAmount")
	public WebElement massRateAmount;
	
	@FindBy(how = How.ID, using = "layoutForm:applyBtn")
	public WebElement applyMassRateChange;
	
	/*
	 * Manage Rate Table
	 */
	@FindBy(how = How.ID, using = "layoutForm:rateTables")
	public WebElement manageRateTable;
	
	@FindBy(how = How.ID, using = "layoutForm:rateDataTable:TableName:filter")
	public WebElement filterRateTable;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateDataTable_data']/tr[1]/td[4]/a")
	public WebElement editRateTable;
	
	/*@FindBy(how = How.ID, using = "layoutForm:description_iframe")
	public WebElement rateDescription;
	*/
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateDataTable_data']/tr[1]/td[5]/a")
	public WebElement editRatesLink;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:activeRoomType\"]/tbody/tr/td[2]/button[4]")
	public WebElement deselectEditRates;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:activeRoomType\"]/tbody/tr/td[1]/ul/li[1]")
	public WebElement roomSelectEditRates;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:activeRoomType\"]/tbody/tr/td[2]/button[1]")
	public WebElement roomSelectedForEditRates;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:fromDate_input\"]")
	public WebElement fromDateEditRates;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:toDate_input\"]")
	public WebElement toDateForEditRates;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:clickGo\"]")
	public WebElement goBtnForEditRates;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:rateGrid:0:lb10\"]/div[1]/span")
	public WebElement changeEditRates;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:rateGrid:0:lb10\"]/div[2]/input")
	public WebElement changeInputEditRates;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:submitNowButton\"]")
	public WebElement submitNowBtnForEditRates;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:btnSubmit\"]")
	public WebElement submitBtnForEditRates;
	
	@FindBy(how = How.ID, using = "layoutForm:description")
	public WebElement rateDescription;
	
	@FindBy(how = How.ID, using = "layoutForm:shortDescription")
	public WebElement rateShortDescription;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:checkbox']/div[2]")
	public WebElement rateTableActiveCheck;
	
	@FindBy(how = How.ID, using = "layoutForm:description")
	public WebElement rateTableDescription;
	
	
	@FindBy(how = How.ID, using = "layoutForm:shortDescription")
	public WebElement shortDescription;
	
	
	@FindBy(how = How.ID, using = "layoutForm:category_label")
	public WebElement categoryDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:category_panel']/div[1]/ul/li[2]")
	public WebElement selectCategory;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:checkbox\"]/div[2]")
	public WebElement selectActiveCheckbox;
	
	@FindBy(how = How.ID, using = "layoutForm:from_input")
	public WebElement rateTableFromDate;
	
	@FindBy(how = How.ID, using = "layoutForm:to_input")
	public WebElement rateTableToDate;
	
	@FindBy(how = How.ID, using = "layoutForm:operaRatecategory_input")
	public WebElement operaRateCategory;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:operaRatecategory_panel']/ul/li[1]")
	public WebElement selectOperaRateCategory;
		
	@FindBy(how = How.ID, using = "layoutForm:transactionCode_input")
	public WebElement transactionCode;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:transactionCode_panel']/ul/li[1]")
	public WebElement selectTransactionCode;
	
	@FindBy(how = How.ID, using = "layoutForm:marketCode_input")
	public WebElement marketCode;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:marketCode_panel']/ul/li[1]")
	public WebElement selectMarketCode;
	
	@FindBy(how = How.ID, using = "layoutForm:componentCode_input")
	public WebElement packageComponent;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:componentCode_panel']/ul/li[1]")
	public WebElement selectPackageComponent;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:componentCode_panel']/ul/li[2]")
	public WebElement selectPackageComponent2;
	
	
	
	@FindBy(how = How.ID, using = "layoutForm:saveButton")
	public WebElement saveRateTable;
	
	/*@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:growl_container']/div/div/div[1]")
	public WebElement closeGrowl;*/
	
	@FindBy(how = How.ID, using = "layoutForm:createRateTable")
	public WebElement createRateTable;
	
	@FindBy(how = How.ID, using = "layoutForm:rateTableName")
	public WebElement rateTableName;
	
	@FindBy(how = How.ID, using = "layoutForm:cancel")
	public WebElement cancelButton;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateDataTable_data']/tr[1]/td[5]/a")
	public WebElement editRatesRateTableLink;
	
	@FindBy(how = How.ID, using = "layoutForm:fromDate_input")
	public WebElement rateTableChangeRatesFromDate;
	
	@FindBy(how = How.ID, using = "layoutForm:toDate_input")
	public WebElement rateTableChangeRatesToDate;
	
	@FindBy(how = How.ID, using = "layoutForm:clickGo")
	public WebElement editRTBtnGo;
	/*
	 * Edit Rates of Manage Rate Table
	 */
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:0:lb10")
	public WebElement rateGrid0lb10Click;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:0:roomType0Val")
	public WebElement rateGrid0roomType0Val;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:0:roomType0ArcFlag")
	public WebElement rateGrid0roomType0ArcFlag;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:0:lb11")
	public WebElement rateGrid0lb11Click;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:0:roomType1Val")
	public WebElement rateGrid0roomType1Val;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:0:roomType1ArcFlag")
	public WebElement rateGrid0roomType1ArcFlag;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:1:lb10")
	public WebElement rateGrid1lb10Click;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:1:roomType0Val")
	public WebElement rateGrid1roomType0Val;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:1:roomType0ArcFlag")
	public WebElement rateGrid1roomType0ArcFlag;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:1:lb11")
	public WebElement rateGrid1lb11Click;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:1:roomType1Val")
	public WebElement rateGrid1roomType1Val;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:1:roomType1ArcFlag")
	public WebElement rateGrid1roomType1ArcFlag;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:2:lb10")
	public WebElement rateGrid2lb10Click;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:2:roomType0Val")
	public WebElement rateGrid2roomType0Val;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:2:roomType0ArcFlag")
	public WebElement rateGrid2roomType0ArcFlag;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:2:lb11")
	public WebElement rateGrid2lb11Click;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:2:roomType1Val")
	public WebElement rateGrid2roomType1Val;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:2:roomType1ArcFlag")
	public WebElement rateGrid2roomType1ArcFlag;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:3:lb10")
	public WebElement rateGrid3lb10Click;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:3:roomType0Val")
	public WebElement rateGrid3roomType0Val;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:3:roomType0ArcFlag")
	public WebElement rateGrid3roomType0ArcFlag;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:3:lb11")
	public WebElement rateGrid3lb11Click;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:3:roomType1Val")
	public WebElement rateGrid3roomType1Val;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:3:roomType1ArcFlag")
	public WebElement rateGrid3roomType1ArcFlag;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:4:lb10")
	public WebElement rateGrid4lb10Click;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:4:roomType0Val")
	public WebElement rateGrid4roomType0Val;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:4:roomType0ArcFlag")
	public WebElement rateGrid4roomType0ArcFlag;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:4:lb11")
	public WebElement rateGrid4lb11Click;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:4:roomType1Val")
	public WebElement rateGrid4roomType1Val;
	
	@FindBy(how = How.ID, using = "layoutForm:rateGrid:4:roomType1ArcFlag")
	public WebElement rateGrid4roomType1ArcFlag;
	
	@FindBy(how = How.ID, using = "layoutForm")
	public WebElement validFloorCeiling;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:alertDialogVal']/div[3]/div/button/")
	public WebElement clickAlertOk;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:alertDialogVal']/div[3]/div/button/span")
	public WebElement afterSaveClickAlertOk;
	
	@FindBy(how = How.ID, using = "layoutForm:rateDataTable:TableName:filter")
	public WebElement searchRates;

	/*
	 * Manage Rate Modifier
	 */	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:manageRateModifier']/span")
	public WebElement selectManageRateModifier;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:ratesMenu']/ul/li[4]")
	public WebElement manageRateModifierPage;
	
	@FindBy(how = How.XPATH, xpath = "//*[contains(text(),'OK')]")
	public WebElement clickDialogOk;
	
	/*
	 * Export Rates
	 */	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:importExportRate']")
	public WebElement clickExportRatesLink;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rate_upload:j_idt56:rateTableInput']")
	public WebElement rateTableSelectDropdown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:selectedRateTable']")
	public WebElement rateModifierRateTableSelectDropdown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rate_upload:j_idt56:rateTableInput_panel']/div/ul/li[7]")
	public WebElement selectPrevailRateTable;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:selectedRateTable_panel']/div/ul/li[6]")
	public WebElement rateModifierSelectPrevailRateTable;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rate_upload:j_idt56:roomTypeInput']/tbody/tr/td[2]/button[4]")
	public WebElement roomDeselectPicklist;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:roomType']/tbody/tr/td[2]/button[4]")
	public WebElement rateModifierRoomDeselectPicklist;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rate_upload:j_idt56:roomTypeInput']/tbody/tr/td[1]/ul/li[1]")
	public WebElement roomSelect;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rate_upload:j_idt56:roomTypeInput']/tbody/tr/td[2]/button[1]")
	public WebElement roomSelected;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:roomType']/tbody/tr/td[1]/ul/li[1]")
	public WebElement rateModifierRoomSelect;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:roomType']/tbody/tr/td[2]/button[1]")
	public WebElement rateModifierRoomSelected;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rate_upload:j_idt56:fromDateInput_input']")
	public WebElement fromDate;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rate_upload:j_idt56:toDateInput_input']")
	public WebElement toDate;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:fromDate_input']")
	public WebElement rateModifierFromDate;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:toDate_input']")
	public WebElement rateModifierToDate;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rate_upload:j_idt56:exportRate']") //*[@id="layoutForm:rate_upload:j_idt56:exportRate"]
	public WebElement exportButton;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:clickGo']")
	public WebElement rateModifierGoButton;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateGrid:0:output_date']")
	public WebElement rateModifierFirstRow;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=['layoutForm:rateGrid_data']/tr/td[2]")
	public WebElement rateModifierBaseRate;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateGrid_data']/tr/td[7]")
	public WebElement rateModifierTotalRate;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateGrid_data']/tr/td[5]")
	public WebElement clickRateModifierField;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:modifierroomlistselect\"]/div[3]/span")//*[@id="layoutForm:modifierroomlistselect"]/div[3]/span
	public WebElement rateModifierDropdown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:modifierroomlistselect_panel\"]/div/ul/li[5]") //*[@id="layoutForm:modifierroomlistselect_panel"]/div/ul/li[4]
	public WebElement clickRateModifierDropdown;
		
	@FindBy(how = How.XPATH, xpath = "//li[@data-label='DLAV']")
	public WebElement selectRoomDLAV;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateGrid_data']/tr/td[6]")
	public WebElement clickRateModifier;
	
	@FindBy(how = How.XPATH, xpath = "//input[@name='modifierType' and @value='$']")
	public WebElement selectAmountRateModifier;
	
	@FindBy(how = How.XPATH, xpath = "//input[@name='modifierType' and @value='%']")
	public WebElement selectPercentRateModifier;
	
	@FindBy(how = How.XPATH, xpath = "//input[@id='rate']")
	public WebElement valueRateModifier;
	
	@FindBy(how = How.XPATH, xpath = "//span[contains(text(),'Review')]") //*[@id="layoutForm:j_idt99"]
	public WebElement rateModifierReview;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:submitNowButton']") //*[@id="layoutForm:submitNowButton"]
	public WebElement rateModifierSubmit;
	
	/*
	 * Dashboard Property Menu
	 */
	
	@FindBy(how = How.XPATH, xpath = "(//*[@class='dropdown propertyLogo'])[4]")
	public WebElement propMenuBellagio;
	
	@FindBy(how = How.XPATH, xpath = "(//a[contains(@id,'PropertyNavigation')])[4]")
	public WebElement subMenuBellagio;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='quickNavDiv']/div[4]/div[1]/div[1]")
	public WebElement activeRateTable;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='DPRPO']/div[1]")
	public WebElement activeRateTableText;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='DPRPO-RateTable']/a[1]")
	public WebElement editRatesMenu;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='DPRPO-RateTable']/a[2]")
	public WebElement mngRateModifierMenu;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='DPRPO-RateTable']/a[3]")
	public WebElement rateImportExport;
	
	@FindBy(how = How.XPATH, xpath = "(//*[contains(text(),'DPRPO')])[1]")
	public WebElement editRatechkDPRPO;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:selectedRateTable_label']")
	public WebElement mngRateModifierchkDPRPO;
	
	@FindBy(how = How.XPATH, xpath = "//*[contains(@id,'rateTableInput_label')]")
	public WebElement rateImportExportchkDPRPO;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:home']")
	public WebElement clickHome;
	
	/* Feature File: 17_search_rate.feature */
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:manageRateSearchSet\"]")
	public WebElement selectRateSearch;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:roomType\"]/ul/li[1]")
	public WebElement selectRoomType;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:channelType\"]/div[3]/span")
	public WebElement channelDropdown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:checkIn_input\"]")
	public WebElement stayDate;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:channelType_panel\"]/div/ul/li[3]")
	public WebElement selectMlife;	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:searchRate\"]")
	public WebElement searchRate;
	
	
}
