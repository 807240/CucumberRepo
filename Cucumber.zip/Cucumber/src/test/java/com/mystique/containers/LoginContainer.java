package com.mystique.containers;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
public class LoginContainer {
	@FindBy(how = How.ID, using = "loginForm:submitForm")
	public WebElement loginPageDiv;
	
	@FindBy(how = How.ID, using = "loginForm:username")
	public WebElement usernameInput;
	
	@FindBy(how = How.ID, using = "loginForm:Password")
	public WebElement passwordInput;
	
	@FindBy(how = How.ID, using = "loginForm:submitButton")
	public WebElement submitButton;
}
