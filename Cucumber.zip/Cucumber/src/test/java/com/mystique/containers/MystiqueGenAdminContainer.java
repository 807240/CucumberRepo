package com.mystique.containers;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MystiqueGenAdminContainer {
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:menuBar']/ul/li[5]/a/span[2]")
	public WebElement operaDataHover;
	
	@FindBy(how = How.XPATH, xpath = "//*[contains(text(),'Static data')]")
	public WebElement operaMenuStaticData;
	
	@FindBy(how = How.XPATH, xpath = "//*[contains(text(),'Dynamic data')]")
	public WebElement operaMenuDynamicData;

	@FindBy(how = How.XPATH, xpath = "//span[contains(text(),'Alert Area Codes')]")
	public WebElement operaStaticDataPage;
	

	@FindBy(how = How.XPATH, xpath = "//span[contains(text(),'Routing Authorizers')]")
	public WebElement operaDynamicDataPage;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView']/ul/li[1]/a")
	public WebElement AlertAreaCode;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dynamicDataTabView']/ul/li[2]/a")
	public WebElement RoutingCode;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dynamicDataTabView']/ul/li[3]/a")
	public WebElement CancellationCode;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dynamicDataTabView']/ul/li[4]/a")
	public WebElement PromoCode;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dynamicDataTabView']/ul/li[5]/a")
	public WebElement TravelAgent;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dynamicDataTabView']/ul/li[6]/a")
	public WebElement ZipCode;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dynamicDataTabView']/ul/li[7]/a")
	public WebElement MarketCode;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dynamicDataTabView']/ul/li[8]/a")
	public WebElement CompanyProfiles;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dynamicDataTabView']/ul/li[9]/a")
	public WebElement SourceCode;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:alertareacodesPropertyId']/div[3]/span")
	public WebElement AlertAreaCodePropertydropdown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dynamicDataTabView:marketcodesPropertyId']/div[3]/span")
	public WebElement MarketCodePropertydropdown;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dynamicDataTabView:sourcecodePropertyId']/div[3]/span")
	public WebElement SourceCodePropertydropdown;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dynamicDataTabView:routingcodePropertyId']/div[3]/span")
	public WebElement RoutingCodePropertydropdown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:alertareacodesPropertyId_panel']/div/ul/li[5]")
	public WebElement AlertAreaCodePropertyBellagio;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dynamicDataTabView:routingcodePropertyId_panel']/div/ul/li[5]")
	public WebElement RoutingCodePropertyBellagio;
	
	@FindBy(how = How.XPATH, xpath = "//*[contains(text(),'No Alert Area Codes were found')]")
	public WebElement NodataAlertAreaCode;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView']/ul/li[2]/a")
	public WebElement AlertCodes;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:alertcodesPropertyId']/div[3]/span")
	public WebElement AlertCodesPropertydropdown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:alertcodesPropertyId_panel']/div/ul/li[5]")
	public WebElement AlertCodesPropertyBellagio;
	
	@FindBy(how = How.XPATH, xpath = "//*[contains(text(),'No Alert Area Codes were found')]")
	public WebElement NodataAlertCodes;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView']/ul/li[3]/a")
	public WebElement CountryCodes;
	
	@FindBy(how = How.XPATH, xpath = "//*[contains(text(),'No Alert Area Codes were found')]")
	public WebElement NodataCountryCodes;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView']/ul/li[4]/a")
	public WebElement ReservationTypes;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:reservationtypePropertyId']/div[3]/span")
	public WebElement ReservationTypesPropertydropdown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:reservationtypePropertyId_panel']/div/ul/li[5]")
	public WebElement ReservationTypesPropertyBellagio;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView']/ul/li[5]/a")
	public WebElement DepositRules;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:depositrulePropertyId']/div[3]/span")
	public WebElement DepositRulesPropertydropdown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:depositrulePropertyId_panel']/div/ul/li[5]")
	public WebElement DepositRulesPropertyBellagio;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView']/ul/li[6]/a")
	public WebElement CancellationRules;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:cancellationrulePropertyId']/div[3]/span")
	public WebElement CancellationRulesPropertydropdown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:cancellationrulePropertyId_panel']/div/ul/li[5]")
	public WebElement CancellationRulesPropertyBellagio;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dynamicDataTabView:marketcodesPropertyId_panel']/div/ul/li[5]")
	public WebElement MarketCodePropertyBellagio;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dynamicDataTabView:sourcecodePropertyId_panel']/div/ul/li[5]")
	public WebElement SourceCodePropertyBellagio;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView']/ul/li[7]/a")
	public WebElement OperaRateCategory;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:ratecategoryPropertyId']/div[3]/span")
	public WebElement OperaRateCategoryPropertydropdown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:ratecategoryPropertyId_panel']/div/ul/li[5]")
	public WebElement OperaRateCategoryPropertyBellagio;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView']/ul/li[8]/a")
	public WebElement PlayerTier;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView']/ul/li[9]/a")
	public WebElement PromotionGroup;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:promotiongroupPropertyId']/div[3]/span")
	public WebElement PromotionGroupPropertydropdown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:promotiongroupPropertyId_panel']/div/ul/li[5]")
	public WebElement PromotionGroupPropertyBellagio;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView']/ul/li[10]/a")
	public WebElement TransactionCodes;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:transactioncodesPropertyId']/div[3]/span")
	public WebElement TransactionCodesPropertydropdown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:transactioncodesPropertyId_panel']/div/ul/li[5]")
	public WebElement TransactionCodesPropertyBellagio;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView']/ul/li[11]/a")
	public WebElement TurnawayCodes;
	
	
	//soumen bose
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView']/ul/li[10]/a")
	public WebElement TracedepartmentCodes;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:tracedepertmentcodePropertyId']/div[3]/span")
	public WebElement TraceanddepartmentCodesPropertydropdown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:staticDataTabView:tracedepertmentcodePropertyId_panel']/div/ul/li[5]")
	public WebElement TraceanddepartmentCodesPropertyBellagio;
	
	//Soumen Bose
	//@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:saveButton']/span[2]")
	//public WebElement saveButton;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:activeFlag']/div[2]")
	public WebElement activeMedia;
	
	
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dynamicDataTabView:authorizersPropertyId']/div[3]/span")
	public WebElement AuthorizersPropertydropdown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dynamicDataTabView:authorizersPropertyId_panel']/div/ul/li[5]")
	public WebElement AuthorizersPropertyBellagio;
	
	/*@FindBy(how = How.ID, using = "layoutForm:applicationSelectMenu")
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:applicationSelectMenu']/div[3]/span")
	public WebElement applicationSelectionDropDown;*/
		
	
	
	
	
	
 

 

	
} 

