package com.mystique.containers;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MystiqueMomentContainer {
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:manageMoments\"]")
	public WebElement manageMomentsTab;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:momentDataTable:0:editButton\"]")
	public WebElement editLink;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:checkbox_enableBestOffer\"]/div[2]")
	public WebElement enableBestOffer;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:bookingWindows_id\"]/div/div/div[10]/div[2]")
	public WebElement showSourceBookingWindow;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:bookingWindows_id_input\"]")
	public WebElement textareaBookingWindow;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:corporatesortorder\"]")
	public WebElement corporatesortorder;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:executionProcess_id\"]/div/div/div[10]/div[2]")
	public WebElement showSourceExecutionProcess;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:executionProcess_id_input\"]")
	public WebElement textareaExecutionProcess;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:saveButton\"]")
	public WebElement saveMomentBtn;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:messages_container\"]")
	public WebElement saveMomentDialogbox;

}
