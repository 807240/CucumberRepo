package com.mystique.containers;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MystiqueComponentContainer {
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:manageComponents']")
	public WebElement manageComponentTab;	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:componentTable:name:filter']")
	public WebElement filterComponentInput;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:componentTable:0:editButton']")
	public WebElement editLink;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:activeFlag']/div[2]")
	public WebElement isActive_checkbox;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:availableInIce']/div[2]")
	public WebElement isAvailableInICE;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:shortDescription\"]")
	public WebElement shortDescriptionComponent;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:messages_container\"]")
	public WebElement saveDialogbox;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:saveButton']")
	public WebElement saveComponentBtn;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:learnMoreDescription\"]/div/div/div[10]/div[2]")
	public WebElement showSource;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:learnMoreDescription_input\"]")
	public WebElement textareaLearnMoreDescription;
	
}
