package com.mystique.containers;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MystiqueRestrictionsContainer {
	
	@FindBy(how = How.ID, using = "layoutForm:menuPanel")
	public WebElement menuPanel;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:restrictions']/a/span[1]")
	public WebElement restrictions;
	
	//@FindBy(how = How.ID, using = "layoutForm:manageRescriction")
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:manageRescriction']")
	public WebElement manageRestrictions;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:generateReport']/span")
	public WebElement viewRestrictions;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:searchRescriction']/span")
	public WebElement searchRestrictions;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:channel']/ul/li[3]")
	public WebElement channel1;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:programSource_data']/tr[1]/td[1]/div/div[2]")
	public WebElement program1;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:roomType']/ul/li[1]")
	public WebElement roomType1;

	@FindBy(how = How.ID, using = "layoutForm:channelSelectAll")
	public WebElement selectAllChannel;
	
	@FindBy(how = How.ID, using = "layoutForm:programSourceSelectAll")
	public WebElement selectAllPrograms;
	
	@FindBy(how = How.ID, using = "layoutForm:channelReset")
	public WebElement channelReset;
	
	@FindBy(how = How.ID, using = "layoutForm:progromSelect")
	public WebElement selectAllProgram;
	
	@FindBy(how = How.ID, using = "layoutForm:progromReset")
	public WebElement programReset;
	
	@FindBy(how = How.ID, using = "layoutForm:roomTypeSelect")
	public WebElement selectAllRoomType;
	
	@FindBy(how = How.ID, using = "layoutForm:roomTypeReset")
	public WebElement roomTypeReset;
	
	@FindBy(how = How.ID, using = "layoutForm:programTags_input")
	public WebElement programTagInput;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:programTags_panel']/ul/li[1]/span")
	public WebElement selectProgramTag;
	
	@FindBy(how = How.ID, using = "layoutForm:filterProgram")
	public WebElement filterProgram;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dateTypeSelection']/tbody/tr/td[1]/div/div[2]/span")
	public WebElement selectByMonth;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dateTypeSelection']/tbody/tr/td[3]/div/div[2]")
	public WebElement selectByTravelWindow;
	
	
	
	@FindBy(how = How.ID, using = "layoutForm:fromDateRangeRestriction_input")
	public WebElement selectByRestrictionfromDate;
	
	@FindBy(how = How.ID, using = "layoutForm:toDateRangeRestriction_input")
	public WebElement selectByRestrictionToDate;
	
	@FindBy(how = How.ID, using = "layoutForm:selectHouseRestriction")
	public WebElement houseRestrictionsCheck;
	
	@FindBy(how = How.ID, using = "layoutForm:buttonSearch")
	public WebElement clickonSearch;
	
	
	@FindBy(how = How.ID, using = "layoutForm:month_label")
	public WebElement monthDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:month_panel']/div/ul/li[2]")
	public WebElement selectMonth;
	
	@FindBy(how = How.ID, using = "layoutForm:year_label")
	public WebElement yearDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:year_panel']/div/ul/li[8]")
	public WebElement selectYear;
	
	@FindBy(how = How.ID, using = "layoutForm:buttonGo")
	public WebElement goButtonMonth;
	
	@FindBy(how = How.ID, using = "layoutForm:fromDate_input")
	public WebElement RestrictionDateFrom;
	
	@FindBy(how = How.ID, using = "layoutForm:fromDate_input")
	public WebElement travelWindowFrom;
	
	@FindBy(how = How.ID, using = "layoutForm:toDate_input")
	public WebElement travelWindowTo;
	
	@FindBy(how = How.ID, using = "layoutForm:clickGo2")
	public WebElement goButtonTravelWindow;
	
	/*@FindBy(how = How.XPATH, xpath = "//*[@id='span_closeValue_1_6']/span")
	public WebElement closeCheck1;*/
	
	/*@FindBy(how = How.XPATH, xpath = "//*[@id='	span_cta_1_30']/span")
	public WebElement closeCheck1*/

	
	@FindBy(how = How.XPATH, xpath = "//*[@id='span_los_1_6']/span")
	public WebElement losCheck1;
	
	@FindBy(how = How.ID, using = "layoutForm:losValue_1_6")
	public WebElement losValue1DropDown1;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:losValue_1_6']/option[7]")
	public WebElement losValue1;
	
	@FindBy(how = How.ID, using = "layoutForm:theoLabel_1_6")
	public WebElement theo1;
	
	@FindBy(how = How.ID, using = "layoutForm:theoType_1_6")
	public WebElement theoTypeDropDown1;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:theoType_1_6']/option[1]")
	public WebElement theoType1Option1;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:theoType_1_6']/option[2]")
	public WebElement theoType1Option2;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:theoType_1_6']/option[3]")
	public WebElement theoType1Option3;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:theoType_1_6']/option[4]")
	public WebElement theoType1Option4;
	
	@FindBy(how = How.ID, using = "layoutForm:save_btn_1_6")
	public WebElement saveTheo1;
	
	@FindBy(how = How.ID, using = "layoutForm:cancel_btn_1_6")
	public WebElement cancelTheo1;
	
	@FindBy(how = How.ID, using = "layoutForm:theoMinValue_1_6")
	public WebElement theoType1Option2MinValue1;
	
	@FindBy(how = How.ID, using = "layoutForm:theoMaxValue_1_6")
	public WebElement theoType1Option2MaxValue1;
	
	@FindBy(how = How.ID, using = "layoutForm:theoValue_1_6")
	public WebElement theoType1Option3Value1;
	
	@FindBy(how = How.ID, using = "layoutForm:theoValue_1_6")
	public WebElement theoType1Option4Value1;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='span_cta_1_32']/span")
	public WebElement ctaCheck2;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='span_ctd_1_7']/span")
	public WebElement ctdCheck2;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='span_los_1_8']/span")
	public WebElement allCheck3;
	
	@FindBy(how = How.ID, using = "layoutForm:losValue_1_8")
	public WebElement losValue2DropDown2;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:losValue_1_8']/option[7]")
	public WebElement losValue2;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:id_allclose']/span")
	public WebElement allCloseCheck;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:id_allcta']/span")
	public WebElement allCtaCheck;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:id_allctd']/span")
	public WebElement allCtdCheck;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:id_alllos']/span")
	public WebElement allLossCheck;
	
	@FindBy(how = How.ID, using = "layoutForm:alllosValue")
	public WebElement allLosValueDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:alllosValue']/option[5]")
	public WebElement allLosValue;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:id_allclear']/span")
	public WebElement allClearCheck;
	
	@FindBy(how = How.ID, using = "layoutForm:comments")
	public WebElement comments;
	
	@FindBy(how = How.ID, using = "layoutForm:reviewButton")
	public WebElement reviewButton;
	
	@FindBy(how = How.ID, using = "layoutForm:gobackButton")
	public WebElement backReviewed;
	
	@FindBy(how = How.ID, using = "layoutForm:btnSchedule")
	public WebElement saveReviewed;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:programTags_panel']/ul/li[1]/span")
	public WebElement programTagSelect1;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:programTags_panel']/ul/li[35]")
	public WebElement programTagSelect2;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:from_input']")
	public WebElement restriction_from;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:to_input']")
	public WebElement restriction_to;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:buttonSearch']")
	public WebElement restriction_search;
}
