package com.mystique.containers;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MystiqueChannelContainer {
	/*
	 * Channel Administration Navigation
	 */
	



	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:j_idt232\"]")
	public WebElement clickAlertOk;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:j_idt69\"]")
	public WebElement confirmDialoge;
	

	/*
	 * Internal Channel
	 */
	@FindBy(how = How.ID, using = "layoutForm:applicationSelectMenu_label")
	public WebElement channelAdminDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:applicationSelectMenu_panel']/div[1]/ul/li[4]")
	public WebElement selectChannelAdmin;
	
	@FindBy(how = How.ID, using = "layoutForm:menuPanel")
	public WebElement channelMenu;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:manageChannel']")
	//@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:manageChannel']/span")
	public WebElement selectManageChannel;
	
	
	@FindBy(how = How.ID, using = "layoutForm:partnerTxnDataTable:propertyId")
	//@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:manageChannel']/span")
	public WebElement PropertyField;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:channelDataTable_data']/tr[1]/td[6]/a")
	public WebElement editPartnerChannelLink;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:channelDataTable_data']/tr[1]/td[6]/a")
	public WebElement editInternalChannelLink;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:channelType']/div[3]/span")
	public WebElement channelTypeDropDown;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:activeFlag']/div[2]/")
	public WebElement channelActivecheck;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:channelType_panel']/div/ul/li[1]")
	public WebElement selectChannelType;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:channelType_panel']/div/ul/li[2]")
	public WebElement selectInternalChannelType;
	
	@FindBy(how = How.ID, using = "layoutForm:channelName")
	public WebElement channelName;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:resortFeeApplicable']/tbody/tr/td[1]/div/div[2]")
	public WebElement resortFeeApplicable;
	
	@FindBy(how = How.ID, using = "layoutForm:programTag_input")
	public WebElement programTagInput;
	
	/*@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:programTag_panel']/ul/li[1]")*/
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:programTag']/ul/li[1]")
	public WebElement selectInternalProgramTag;
	
	@FindBy(how = How.ID, using = "layoutForm:programDTOList:0:viewable")
	//@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:programDTOList:0:viewable']/div[2]")
	public WebElement viewable0;
	
	@FindBy(how = How.ID, using = "layoutForm:programDTOList:1:viewable")
	//@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:programDTOList:2:viewable']/div[2]")
	public WebElement viewable2;
	
	@FindBy(how = How.ID, using = "layoutForm:programDTOList:0:bookable")
	//@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:programDTOList:0:bookable']/div[2]")
	public WebElement bookable0;
	
	@FindBy(how = How.ID, using = "layoutForm:btnSave")
	public WebElement saveEditedChannel;
	
	@FindBy(how = How.ID, using = "layoutForm:btnSave")
	public WebElement saveChannel;
	
	
	@FindBy(how = How.ID, using = "layoutForm:cancelBtn")
	public WebElement cancelChannelEdit;
	
	@FindBy(how = How.ID, using = "layoutForm:createChannel")
	public WebElement createChannel;

	
	/*
	 * Partner Channel
	 * 
	 * 
	 */
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:activeFlag\"]/div[2]")
	public WebElement checkActive;
		
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:programDTOList_head']/tr/th[3]/input")
	public WebElement filterManageProgram;	
	
	@FindBy(how = How.ID, using = "layoutForm:programDTOList:0:viewable")
	public WebElement checkManageProgram;
	
	@FindBy(how = How.ID, using = "layoutForm:createChannel")
	public WebElement createPartnerChannel;

	@FindBy(how = How.ID, using = "layoutForm:partnerName")
	public WebElement partnerName;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:channelType_panel']/div/ul/li[3]")
	public WebElement selectPartnerChannelType;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerName']/div[3]/span")
	public WebElement partnerNameDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerName_panel']/div/ul/li[1]")
	public WebElement deselectPartnerName;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerName_panel']/div/ul/li[2]")
	public WebElement selectPartnerName;
	
	/*@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:companyID_input']/div/ul/li[2]")
	public WebElement corporateId;*/
	
	@FindBy(how = How.ID, using = "layoutForm:companyID_input")
	public WebElement corporateId;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:companyID_panel']/ul/li[1]")
	public WebElement selectCorporateId;
	
	/*@FindBy(how = How.ID, using = "layoutForm:marketCode_input")
	public WebElement corporateId;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:marketCode_panel']/ul/li[1]")
	public WebElement selectMarketCode;
	
	*/
	/*
	 * property mapping partner channel
	 */
	
	@FindBy(how = How.ID, using = "layoutForm:partnerPropertyMappingDTOList:0:deleteProperty")
	public WebElement partnerChannelDeleteNewProperty;
	
	
	@FindBy(how = How.ID, using = "layoutForm:addNewProperty")
	public WebElement partnerChannelAddNewProperty;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:operaPropertyCode\"]/div[3]/span")
	public WebElement partnerChannelOperaPropertyDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:channelCodeProperty\"]")
	public WebElement partnerChannelCodeProperty;
	
	@FindBy(how=How.XPATH,xpath="//*[@id=\"layoutForm:operaPropertyCode_panel\"]/div/ul/li[1]")
	public WebElement selectoOeraPropertyCode;
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:saveProperty\"]")
	public WebElement partnerChannelSaveProperty;
	
	
	@FindBy(how = How.ID, using = "layoutForm:cancel_property")
	public WebElement partnerChannelCancel_property;
	
	
	/*
	 * 
	 */
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:category']/tbody/tr/td/ul/li[1]")
	public WebElement selectCategory;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:category']/tbody/tr/td[2]/button")
	public WebElement activateCategory;
	
	@FindBy(how = How.ID, using = "layoutForm:companyID_input")
	public WebElement companyID;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:companyID_panel']/ul/li[2]")
	public WebElement selectCompanyID;
	
	@FindBy(how = How.ID, using = "layoutForm:companyProfile")
	public WebElement companyProfile;
	
	@FindBy(how = How.ID, using = "layoutForm:defaultMargin")
	public WebElement defaultMargin;
	
	@FindBy(how = How.ID, using = "layoutForm:fromDate1_input")
	public WebElement marginFromDate1;
	
	@FindBy(how = How.ID, using = "layoutForm:toDate1_input")
	public WebElement marginToDate1;
	
	@FindBy(how = How.ID, using = "layoutForm:marginValue1")
	public WebElement marginValue1;
	
	@FindBy(how = How.ID, using = "layoutForm:btnAdd0")
	public WebElement addMargin;
	
	@FindBy(how = How.ID, using = "layoutForm:fromDate2_input")
	public WebElement marginFromDate2;
	
	@FindBy(how = How.ID, using = "layoutForm:toDate2_input")
	public WebElement marginToDate2;
	
	@FindBy(how = How.ID, using = "layoutForm:marginValue2")
	public WebElement marginValue2;
	
	@FindBy(how = How.ID, using = "layoutForm:fromDate3_input")
	public WebElement marginFromDate3;
	
	@FindBy(how = How.ID, using = "layoutForm:toDate3_input")
	public WebElement marginToDate3;
	
	@FindBy(how = How.ID, using = "layoutForm:marginValue3")
	public WebElement marginValue3;
	
	@FindBy(how = How.ID, using = "layoutForm:btnDelete1")
	public WebElement deleteMargin;
	
	@FindBy(how = How.ID, using = "layoutForm:sourceCode_input")
	public WebElement sourceCode;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:sourceCode_panel']/ul/li[1]")
	public WebElement selectSourceCode;
	
	@FindBy(how = How.ID, using = "layoutForm:marketCode_input")
	public WebElement marketCode;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:marketCode_panel']/ul/li[1]")
	public WebElement selectMarketCode;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:billingType1\"]/div[3]")
	public WebElement billingTypeDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:billingType1_panel']/div[1]/ul/li[2]")
	public WebElement selectBillingType;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:billingType1_panel']/div[1]/ul/li[4]")
	public WebElement selectBillingTypeEdit;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:routingcodes1']/div[3]/span")
	public WebElement routingCodesDropDown;
	
    @FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:routingcodes1_panel']/div/ul/li[3]")
    public WebElement selectroutingCodes;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:ariPush']/tbody/tr/td[1]/div/div[2]")
	public WebElement ariPush;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:programDTOList_data']/tr/td[4]/a")
	public WebElement editChannelProgram;
	
	@FindBy(how = How.ID, using = "layoutForm:createChannelProgram")
	public WebElement createChannelProgramLink;
	
	
	/*
	 * Channel Program
	 */
	
	@FindBy(how = How.ID, using = "layoutForm:programName")
	public WebElement programName;
	
	/*@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:programTag']/div[3]/span")
	public WebElement programTagDropDown;*/
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:programTag_panel']")
	public WebElement selectProgramTag;
	
	//@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:baseProgram']/div[3]/span")
	@FindBy(how = How.ID, using = "layoutForm:baseProgram_label")
	public WebElement baseProgramDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:baseProgram_panel']/div/ul/li[2]")
	public WebElement selectBaseProgram;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:reservationType']/div[3]/span")
	public WebElement reservationTypeDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:reservationType_panel']/div/ul/li[2]")
	public WebElement selectReservationType;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:depositRule']/div[3]/span")
	public WebElement depositRuleDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:depositRule_panel']/div/ul/li[2]")
	public WebElement selectDepositRule;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:cancellationPolicy']/div[3]/span")
	public WebElement cancellationPolicyDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:cancellationPolicy_panel']/div/ul/li[2]")
	public WebElement selectCancellationPolicy;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateView']/div[3]/span")
	public WebElement rateViewDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateView_panel']/div/ul/li[2]")
	public WebElement selectRateView;
	
	@FindBy(how = How.ID, using = "layoutForm:btnSave")
	public WebElement saveChannelProgram;
	
	@FindBy(how = How.ID, using = "layoutForm:back")
	public WebElement backChannelProgram;
	
	@FindBy(how = How.ID, using = "layoutForm:roomRelationTable")
	public WebElement clickHereProgramChannel;
	
	@FindBy(how = How.ID, using = "layoutForm:channelDataTable:0:deleteButton")
	public WebElement deleteChannel;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:channelDataTable:channelName:filter\"]")
	public WebElement channelNameFilter;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:channelDataTable:channelKey:filter\"]")
	public WebElement channelKeyFilter;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:channelDataTable:channelType:filter\"]")
	public WebElement channelTypeFilter;
	
	/*
	 * Channel Mapping
	 */
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:channelMapping\"]/span")
	public WebElement selectChannelMapping;
	
	//@FindBy(how = How.XPATH, using = "[@id='layoutForm:channel']/div[3]/span")
	//public WebElement ChannelKeyDropDown ;
	
	@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:channel_panel']/div/ul/li[2]")
	public WebElement selectChannelKey;
	
	
	
	//@FindBy(how = How.ID, using = "[@id='layoutForm:channelMapping']/div[2]/li/div/span")
	//public WebElement PropertyName ;
	
	@FindBy(how = How.ID, using = "layoutForm:btnSave")
	public WebElement saveChannelMapping;
	
	/*
	 * Property Mapping
	 */
	
	
	//@FindBy(how = How.ID, using = "layoutForm:channel_label")
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:channel']/div[3]/span")
	public WebElement channelKeyDropDown;
	
	@FindBy(how = How.ID, using = "	layoutForm:channel_label")
	public WebElement channelKeyClick;
	

	
	/*@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:channel_panel']/div/ul/li[2]")
	public WebElement selectChannelKey;*/
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerPropertyMappingDTOList:0:editProperty']/span[1]")
	public WebElement propertyMappingEdit0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerPropertyMappingDTOList:0:edit_propertyCode_label")
	public WebElement propertyCode0DropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerPropertyMappingDTOList:0:edit_propertyCode_panel']/div/ul/li[1]")
	public WebElement selectPropertyCode0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerPropertyMappingDTOList:0:edit_partnerPropertyCode")
	public WebElement partnerPropertyCode0;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerPropertyMappingDTOList:0:editProperty']/span[2]")
	public WebElement propertySave0;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerPropertyMappingDTOList:0:editProperty']/span[3]")
	public WebElement propertyCancel0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerPropertyMappingDTOList:0:deleteProperty")
	public WebElement deleteProperty0;
	
	@FindBy(how = How.ID, using = "layoutForm:addNewProperty")
	public WebElement addNewProperty;
	
	@FindBy(how = How.ID, using = "layoutForm:operaPropertyCode_label")
	public WebElement propertyCodeNewDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:operaPropertyCode_panel']/div/ul/li[2]")
	public WebElement selectPropertyCodeNew;
	
	@FindBy(how = How.ID, using = "layoutForm:channelCodeProperty")
	public WebElement partnerPropertyCodeNew;
	
	@FindBy(how = How.ID, using = "layoutForm:saveProperty")
	public WebElement savePropertyNew;
	
	@FindBy(how = How.ID, using = "layoutForm:cancel_property")
	public WebElement cancelPropertyNew;
	
	/*
	 * Room Type Mapping
	 */
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:propertyID']/div[3]/span")
	public WebElement propertyNameDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:propertyID_panel']/div/ul/li[2]")
	public WebElement selectPropertyName;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerRoomMappingDTOList:0:editRoomType']/span[1]")
	public WebElement roomTypeMappingEdit0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerRoomMappingDTOList:0:edit_roomType_input")
	public WebElement roomType0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerRoomMappingDTOList:0:edit_partnerRoomType")
	public WebElement partnerRoomType0;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerRoomMappingDTOList:0:editRoomType']/span[2]")
	public WebElement roomTypeSave0;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerRoomMappingDTOList:0:editRoomType']/span[3]")
	public WebElement roomTypeCancel0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerRoomMappingDTOList:0:deleteRoomType")
	public WebElement deleteRoomType1;
	
	@FindBy(how = How.ID, using = "layoutForm:addNewRoom")
	public WebElement addNewRoom;
	
	@FindBy(how = How.ID, using = "layoutForm:operaRoomCode_input")
	public WebElement roomCodeNew;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:operaRoomCode_panel']/ul/li[15]")
	public WebElement selectRoomCodeNew;
	
	@FindBy(how = How.ID, using = "layoutForm:channelCodeRoom")
	public WebElement partnerRoomCodeNew;
	
	@FindBy(how = How.ID, using = "layoutForm:saveRoomCode")
	public WebElement saveRoomNew;
	
	@FindBy(how = How.ID, using = "layoutForm:cancelRoomCode")
	public WebElement cancelRoomNew;
	
	/*
	 * Guarantee mapping
	 */
	
	@FindBy(how = How.ID, using = "layoutForm:reservationPropertyID_label")
	public WebElement reservationDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:reservationPropertyID_panel']/div/ul/li[4]")
	public WebElement selectReservationPropertyName;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerReservationMappingDTOList:0:editGuarantee']/span[1]")
	public WebElement reservationMappingEdit0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerReservationMappingDTOList:0:edit_reservationType_input")
	public WebElement reservationType0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerReservationMappingDTOList:0:edit_partnerGuaranteeCode")
	public WebElement partnerReservationCode0;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerReservationMappingDTOList:0:editGuarantee']/span[2]")
	public WebElement reservationSave0;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerReservationMappingDTOList:0:editGuarantee']/span[3]")
	public WebElement reservationCancel0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerReservationMappingDTOList:0:deleteGuarantee")
	public WebElement deleteReservation1;
	
	@FindBy(how = How.ID, using = "layoutForm:addNewReservation")
	public WebElement addNewReservation;
	
	@FindBy(how = How.ID, using = "layoutForm:reservationCode_input")
	public WebElement reservationTypeNew;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:reservationCode_panel']/ul/li[1]")
	public WebElement selectReservationTypeNew;
	
	@FindBy(how = How.ID, using = "layoutForm:channelCodeReservation")
	public WebElement partnerReservationCodeNew;
	
	@FindBy(how = How.ID, using = "layoutForm:saveGuaranteeCode")
	public WebElement saveReservationNew;
	
	@FindBy(how = How.ID, using = "layoutForm:cancelGuaranteeCode")
	public WebElement cancelReservationNew;
	
	/*
	 * Special Request mapping
	 */
	
	@FindBy(how = How.ID, using = "layoutForm:specialRequestPropertyID_label")
	public WebElement specialRequestDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:specialRequestPropertyID_panel']/div/ul/li[4]")
	public WebElement selectSpecialRequest;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerSpecialRequestMappingDTOList:0:editRequest']/span[1]")
	public WebElement requestMappingEdit0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerSpecialRequestMappingDTOList:0:edit_requestCode_input")
	public WebElement requestCode0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerSpecialRequestMappingDTOList:0:edit_partnerRequestCode")
	public WebElement partnerRequestCode0;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerSpecialRequestMappingDTOList:0:editRequest']/span[2]")
	public WebElement requestSave0;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerSpecialRequestMappingDTOList:0:editRequest']/span[3]")
	public WebElement requestCancel0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerSpecialRequestMappingDTOList:0:deleteRequest")
	public WebElement deleteRequest1;
	
	@FindBy(how = How.ID, using = "layoutForm:addNewSpecialRequest")
	public WebElement addNewSpecialRequest;
	
	@FindBy(how = How.ID, using = "layoutForm:specialReqCode_input")
	public WebElement specialReqCodeNew;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:specialReqCode_panel']/ul/li[1]")
	public WebElement selectspecialReqCodeNew;
	
	@FindBy(how = How.ID, using = "layoutForm:channelCodeSpecialRequest")
	public WebElement partnerSpecialReqCodeNew;
	
	@FindBy(how = How.ID, using = "layoutForm:saveSpecialRequest")
	public WebElement saveSpecialRequestNew;
	
	@FindBy(how = How.ID, using = "layoutForm:cancelSpecialRequest")
	public WebElement cancelSpecialRequestNew;
	
	/*
	 * Payment Type Mapping
	 */
	
	@FindBy(how = How.ID, using = "layoutForm:paymentTypePropertyID_label")
	public WebElement paymentTypeDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:paymentTypePropertyID_panel']/div/ul/li[4]")
	public WebElement selectPaymentType;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerPaymentTypeMappingDTOList:0:editPaymentType']/span[1]")
	public WebElement paymentTypeEdit0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerPaymentTypeMappingDTOList:0:edit_paymentTypeCode_label")
	public WebElement paymentTypeCode0DropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerPaymentTypeMappingDTOList:0:edit_paymentTypeCode_panel']/div/ul/li[2]")
	public WebElement selectPaymentTypeCode0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerPaymentTypeMappingDTOList:0:edit_partnerPaymentTypeCode")
	public WebElement partnerPaymentTypeCode0;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerPaymentTypeMappingDTOList:0:editPaymentType']/span[2]")
	public WebElement paymentTypetSave0;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerPaymentTypeMappingDTOList:0:editPaymentType']/span[3]")
	public WebElement paymentTypeCancel0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerPaymentTypeMappingDTOList:0:deletePaymentType")
	public WebElement deletePaymentType1;
	
	@FindBy(how = How.ID, using = "layoutForm:addNewPaymentType")
	public WebElement addNewPaymentType;
	
	@FindBy(how = How.ID, using = "layoutForm:paymentTypeCode_label")
	public WebElement paymentTypeCodeNewDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:paymentTypeCode_panel']/div/ul/li[1]")
	public WebElement selectPaymentTypeCodeNew;
	
	@FindBy(how = How.ID, using = "layoutForm:channelCodePaymentType")
	public WebElement partnerPaymentTypeCodeNew;
	
	@FindBy(how = How.ID, using = "layoutForm:savePaymentType")
	public WebElement savePaymentTypeNew;
	
	@FindBy(how = How.ID, using = "layoutForm:cancelPaymentType")
	public WebElement cancelPaymentTypeNew;
	
	/*
	 * Rate Plan Code Mapping
	 */
	
	@FindBy(how = How.ID, using = "layoutForm:rateCodePropertyID_label")
	public WebElement ratePlanDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:rateCodePropertyID_panel']/div/ul/li[4]")
	public WebElement selectRatePlan;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerRateCodeMappingDTOList:0:editRatePlan']/span[1]")
	public WebElement ratePlanEdit0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerRateCodeMappingDTOList:0:edit_programName_input")
	public WebElement programName0;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerRateCodeMappingDTOList:0:edit_programName_panel']/ul/li[1]")
	public WebElement selectProgramName0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerRateCodeMappingDTOList:0:edit_partnerRatePlanCode")
	public WebElement partnerRatePlanCode0;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerRateCodeMappingDTOList:0:editRatePlan']/span[2]")
	public WebElement ratePlanSave0;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:partnerRateCodeMappingDTOList:0:editRatePlan']/span[3]")
	public WebElement ratePlanCancel0;
	
	@FindBy(how = How.ID, using = "layoutForm:partnerRateCodeMappingDTOList:0:deleteRatePlan")
	public WebElement deleteRatePlan1;
	
	@FindBy(how = How.ID, using = "layoutForm:addNewRateCode")
	public WebElement addNewRateCode;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:programName_input\"]")
	public WebElement programIdNew;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:programName_panel']/ul/li[1]")
	public WebElement selectProgramIdNew;
	
	@FindBy(how = How.ID, using = "layoutForm:channelCodeRatePlanCode")
	public WebElement partnerRateCodeNew;
	
	@FindBy(how = How.ID, using = "layoutForm:saveRateCode")
	public WebElement saveRateCodeNew;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:cancelRateCode\"]")
	public WebElement cancelRateCodeNew;

	
	/*START: Add - New elements introduced in new page - AGM #3831*/
	
	//Partner Sync menu option under Channel sub-menu
	@FindBy(how = How.ID, using = "layoutForm:externalSync")
	public WebElement menuPartnerReport;
		
	//Channel selection drop-down arrow in Partner Report page
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:channel\"]/div[3]/span")
	
	public WebElement clickChannelSelect;
	
	//Channel selection drop-down list in Partner Report page
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:channel_panel\"]/div/ul/li[2]")
	public WebElement dropdownChannelSelect;
	
	//Property selection drop-down menu arrow in Partner Report page
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:property']/div[3]/span")
	public WebElement clickPropertySelect;
	
	//Property selection drop-down menu arrow in Partner Report page
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:property_panel']/div/ul/li[2]")
	public WebElement dropdownPropertySelect;
		
	//From date value
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:fromDate_input\"]")
	public WebElement fromDateSelect;
	
	//To date value
		@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:toDate_input\"]")
		public WebElement toDateSelect;
	
	//Search button
	@FindBy(how = How.ID, using = "layoutForm:btnFetch")
	public WebElement buttonSearch;
	
	//Export button
	@FindBy(how = How.ID, using = "layoutForm:btnExport")
	public WebElement buttonExport;
	
	
	@FindBy(how = How.XPATH, xpath = "(//*[contains(@style,'background-color:#f58782')])[1]")
	public WebElement PCS_Aurora_Deviation;
	
	@FindBy(how = How.XPATH, xpath = "(//*[@class='restrictionColor  custom-grid-cell' and not(contains(@style,'background-color:#f58782'))])[1]")
	public WebElement no_PCS_Aurora_Deviation;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:partnerRateSync\"]")
	public WebElement partnerRateSync;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:fromDate_input\"]")
	public WebElement fromdate_input;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:toDate_input\"]")
	public WebElement todate_input;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:rateFlag\"]/div[2]")
	public WebElement rateCheckbox;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:restrictionFlag\"]/div[2]")
	public WebElement restrictionsCheckbox;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:btnSync\"]")
	public WebElement syncButton;	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id=\"layoutForm:btnSyncYes\"]")
	public WebElement syncAlertButton;
	
	/*END: Add - New elements introduced in new page - AGM #3831*/

}
