package com.mystique.containers;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MystiqueDashboardContainer {
	@FindBy(how = How.ID, using = "layoutForm:pgHeaderLayoutTwo")
	public WebElement mainPageDiv;

	//@FindBy(how = How.ID, using = "layoutForm:applicationSelectMenu")
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:applicationSelectMenu']/div[3]/span")
	public WebElement applicationSelectionDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:applicationSelectMenu_panel']/div/ul/li[1]")
	public WebElement applicationSelection;

	//@FindBy(how = How.ID, using = "layoutForm:propertySelectMenu")
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:propertySelectMenu']/div[3]/span")
	public WebElement propertyMenuSelectionDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@data-label='General Administration']")
	public WebElement UserAdminSelection;
	
	@FindBy(how = How.XPATH, xpath = "//*[contains(text(),'Manage Users')]")
	public WebElement ManageUsers;
	
	@FindBy(how = How.XPATH, xpath = "//*[contains(text(),'Manage Properties')]")
	public WebElement ManageProperties;
	
	@FindBy(how = How.XPATH, xpath = "//*[contains(text(),'Manage Cuisine Types')]")
	public WebElement ManageCuisineTypes;
	
	@FindBy(how = How.XPATH, xpath = "//*[contains(text(),'Categories')]")
	public WebElement Categories;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dataTable_paginator_bottom']/span[1]")
	public WebElement CountUsers;
	
	@FindBy(how = How.XPATH, xpath = "//*[@data-label='General Administration']")
	public WebElement generalAdminSelection;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:propertySelectMenu_panel']/div/ul/li[2]")
	public WebElement propertyMenuSelection;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:propertySelectMenu_panel']/div/ul/li[4]")
	public WebElement propertyMenuSelectionDropDownForBellagio;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:propertySelectMenu_panel']/div/ul/li[8]")
	public WebElement propertyMenuSelectionDellano;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:propertySelectMenu_panel']/div/ul/li[10]")
	public WebElement propertyMenuSelectionMB;
	

	/*
	 * Default Rate Spread Amount and Base Room Type Validation
	 */
	
	/*@FindBy(how = How.ID, using = "layoutForm:j_idt76:0:spdRadio")
	public WebElement selectRadioSpread1;*/
	
	//@FindBy(how = How.ID, using = "layoutForm:j_idt76:0:base_room_type")
	// WebElement selectBaseRoomType1;
	
	/*
	 * Room Media
	 */
	
	@FindBy(how = How.ID, using = "layoutForm:dataTable:0:mediaButton")
	public WebElement MediaLink;
	
	@FindBy(how = How.ID, using = "layoutForm:createMediaButton")
	public WebElement createrNewMediaLink;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:mediaType']/div[3]/span")
	public WebElement mediaTypeDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:mediaType_panel']/div/ul/li[1]")
	public WebElement selectMediaType;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:group']/div[3]/span")
	public WebElement groupDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:group_panel']/div/ul/li[1]")
	public WebElement selectGroup;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:subGroup']/div[3]/span")
	public WebElement subGroupDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:subGroup_panel']/div/ul/li[1]")
	public WebElement selectSubGroup;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:scope']/div[3]/span")
	public WebElement scopeDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:scope_panel']/div/ul/li[1]")
	public WebElement selectScope;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:activeFlag']/div[2]")
	public WebElement activeMedia;
	
	@FindBy(how = How.ID, using = "layoutForm:mediaAltText_text")
	public WebElement mediaAlertText;
	
	@FindBy(how = How.ID, using = "layoutForm:saveButton")
	public WebElement saveMedia;
	
	/*
	 * Edit Media
	 */
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:mediaTree_node_0']/td[1]/span[1]")
	public WebElement logoTree;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:mediaTree_node_0_0']/td[1]/span[2]")
	public WebElement monochromeTree;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:mediaTree_node_0_0_0']/td[1]/span[3]")
	public WebElement tinyTree;
	
	@FindBy(how = How.ID, using = "layoutForm:mediaTree:0_0_0_0:editButton")
	public WebElement editMedia;
	
}
