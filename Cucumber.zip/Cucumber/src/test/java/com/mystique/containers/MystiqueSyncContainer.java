package com.mystique.containers;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MystiqueSyncContainer {	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:applicationSelectMenu']/div[3]/span")
	public WebElement generalAdminDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:applicationSelectMenu_panel']/div[1]/ul/li[3]")
	public WebElement selectGeneralAdmin;
	
	@FindBy(how = How.ID, using = "layoutForm:syncChannel")
	public WebElement clickSyncToPartner;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:channel']/div[3]/span")
	public WebElement clickOnChannelDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:channel_panel']/div[1]/ul/li[2]")
	public WebElement SelectChannel;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:property']/div[3]/span")
	public WebElement clickOnPropertyDropDown;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:property_panel']/div/ul/li[14]")
	public WebElement selectPropertyDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:resrce']/tbody/tr/td/ul/li")
	public WebElement clickAvailableResource;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:resrce']/tbody/tr/td/button/span")
	public WebElement activateAvailableResource;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:resrce']/tbody/tr/td/button[4]/span")
	public WebElement deactivateAvailableResource;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:resrce']/tbody/tr/td/button[2]/span")
	public WebElement activateAllAvailableResource;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:syncChannel']/span")
	public WebElement selectAvailableResourceDropDown;

	@FindBy(how = How.ID, using = "layoutForm:btnSave")
	public WebElement clickOnSync;
}
