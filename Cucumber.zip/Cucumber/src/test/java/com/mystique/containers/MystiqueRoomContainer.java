package com.mystique.containers;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MystiqueRoomContainer {
	
	@FindBy(how = How.ID, using = "layoutForm:manageRoom")
	public WebElement manageRoomsTab;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:contentPanel']/table/tbody/tr[1]/td/table/tbody/tr/td/table/tbody/tr[2]/td/span")
	public WebElement roomLibrary;
	
//	@FindBy(how = How.ID, using = "layoutForm:dataTable:roomCodeColumn:filter")
//	public WebElement filterRoomInput;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dataTable:roomCodeColumn:filter']")
	public WebElement filterRoomInput;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dataTable_data']/tr/td[1]")
	public WebElement filterRoomResult;
	
	@FindBy(how = How.ID, using = "layoutForm:dataTable:roomActiveColumn:filter")
	public WebElement filterRoomStatus;
	
	@FindBy(how = How.ID, using = "layoutForm:dataTable:associationType:filter")
	public WebElement filterAssociationStatus;
	
	@FindBy(how = How.ID, using = "layoutForm:dataTable:0:editButton")
	public WebElement editLink;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:activeFlag']/tbody/tr/td[1]/div/div[2]")
	public WebElement changeActive;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:activeFlag']/tbody/tr/td[3]/div/div[2]")
	public WebElement changeInactive;
	
	
	
	/*
	 * Room Edit Page Elements
	 */

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:shortDescription_iframe']/document/html/body")
	public WebElement roomShortDescription;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:description_iframe']/document/html/body")
	public WebElement roomLongDescription;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:agentSendToCustomerText_iframe']/document/html/body")
	public WebElement customerTextDescription;

	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:next']")
	public WebElement roomNextButton;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:activeFlag']/tbody/tr/td[1]/div/div[2]")
	public WebElement isActive;
	
	@FindBy(how = How.XPATH, xpath = "//*[contains(text(),'Expand All')]")
	public WebElement expandAll;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:attribute_id']/tbody/tr/td[1]/ul/li[1]")
	public WebElement selectAttribute;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:attribute_id']/tbody/tr/td[2]/button[1]")
	public WebElement activateAttribute;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:connectedRoom']/div[3]/span")
	public WebElement connectedRoomDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:connectedRoom_panel']/div/ul/li[2]")
	public WebElement selectConnetedRoom;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:program']/tbody/tr/td[1]/ul/li[1]")
	public WebElement selectProgram;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:program']/tbody/tr/td[2]/button[1]")
	public WebElement activateProgram;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:channel']/tbody/tr/td[1]/ul/li[1]")
	public WebElement selectChannel;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:channel']/tbody/tr/td[2]/button[1]")
	public WebElement activateChannel;
	
	@FindBy(how = How.ID, using = "layoutForm:rateHurdle")
	public WebElement rateFloor;
	
	@FindBy(how = How.ID, using = "layoutForm:rateCeilingValue")
	public WebElement rateCeiling;
	
	@FindBy(how = How.ID, using = "layoutForm:extraGuestCharge")
	public WebElement extraGuestCharge;
	
	@FindBy(how = How.ID, using = "layoutForm:extraGuestChargeThreshold")
	public WebElement extraGuestChangeThreshold;
	
	@FindBy(how = How.ID, using = "layoutForm:resortFee")
	public WebElement resortFee;
	
	@FindBy(how = How.ID, using = "layoutForm:agentText_iframe")
	public WebElement agentText;
	
	@FindBy(how = How.ID, using = "layoutForm:agentSendToCustomerText_iframe")
	public WebElement agentSendToText;
	
	@FindBy(how = How.XPATH, xpath = "//li[contains(text(),'Programs')]")
	public WebElement collapseProgram;
	
	@FindBy(how = How.XPATH, xpath = "//li[contains(text(),'Channels')]")
	public WebElement collapseChannel;
	
	@FindBy(how = How.XPATH, xpath = "//li[contains(text(),'Room Configuration')]")
	public WebElement collapseRoomConfig;
	
	@FindBy(how = How.XPATH, xpath = "//li[contains(text(),'Basic Settings')]")
	public WebElement collapseBasicSetting;
	
	@FindBy(how = How.XPATH, xpath = "//li[contains(text(),'Rate Settings')]")
	public WebElement collapseRateSetting;
	
	@FindBy(how = How.XPATH, xpath = "//li[contains(text(),'Fee Table')]")
	public WebElement collapseFeeTable;
	
	
	
	/*Config
	 * Default Rate Spread Page Elements
	 */
	@FindBy(how = How.XPATH, xpath = "//*[@value='Add Spread']")
	public WebElement addSpread;
	
	@FindBy(how = How.ID, using = "layoutForm:btnA1dd0")
	public WebElement addSeason0;
	
	@FindBy(how = How.ID, using = "layoutForm:backButton")
	public WebElement backButton;
	
	@FindBy(how = How.ID, using = "layoutForm:CancelButton")
	public WebElement cancelButton;
	
	@FindBy(how = How.ID, using = "layoutForm:spreadNameValue0")
	public WebElement spreadNameValue0;
	
	@FindBy(how = How.ID, using = "layoutForm:startDate0")
	public WebElement seasonStartDate0;
	
	@FindBy(how = How.ID, using = "layoutForm:endDate0")
	public WebElement seasonEndDate0;
	
	@FindBy(how = How.ID, using = "layoutForm:next")
	public WebElement clickNext;
	
	@FindBy(how = How.ID, using = "layoutForm:submitButton")
	public WebElement clickSubmit;	
	
	@FindBy(how = How.ID, using = "layoutForm:yesButton")
	public WebElement clickAlertBox;
	
	

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:item0daysSelected']/tbody/tr/td[1]/div/div[2]")
	public WebElement selectSunday0;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:item0daysSelected']/tbody/tr/td[3]/div/div[2]")
	public WebElement selectMonday0;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:item0daysSelected']/tbody/tr/td[5]/div/div[2]")
	public WebElement selectTuesday0;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:item0daysSelected']/tbody/tr/td[7]/div/div[2]")
	public WebElement selectWednesday0;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:item0daysSelected']/tbody/tr/td[9]/div/div[2]")
	public WebElement selectThursday0;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:item0daysSelected']/tbody/tr/td[11]/div/div[2]")
	public WebElement selectFriday0;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:item0daysSelected']/tbody/tr/td[13]/div/div[2]")
	public WebElement selectSaturday0;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:seasonalSpreadType0:0']")
	public WebElement selectRadioAmt0;

	@FindBy(how = How.ID, using = "layoutForm:amountValue0")
	public WebElement amountValue0;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:spdRadio0']/div[2]")
	public WebElement selectRadioSpread0;
	
	@FindBy(how = How.ID, using = "layoutForm:base_room_type0")
	public WebElement baseRoomTypeDropDown0;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:base_room_type0']/option[1]")
	public WebElement selectBaseRoomType0;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:base_room_type0']/option[4]")
	public WebElement selectBaseRoomTypeDown0;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:percent0']/div[2]")
	public WebElement selectPercentRadio0;
	
	@FindBy(how = How.ID, using = "layoutForm:spreadPercent0")
	public WebElement percentValue0;

	@FindBy(how = How.ID, using = "layoutForm:submitButton")
	public WebElement saveButton;
	
	/*
	 * Add Season
	 */
	@FindBy(how = How.ID, using = "layoutForm:btnA1dd0")
	public WebElement addAnotherSeason;
	
	@FindBy(how = How.ID, using = "layoutForm:startDate1")
	public WebElement seasonStartDate1;
	
	@FindBy(how = How.ID, using = "layoutForm:endDate1")
	public WebElement seasonEndDate1;
	
	/*@FindBy(how = How.ID, using = "layoutForm:endDate1_input")
	public WebElement seasonEndtDate1;*/
	
	@FindBy(how = How.ID, using = "layoutForm:spreadNameValue1")
	public WebElement spreadNameValue1;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:item1daysSelected']/tbody/tr/td[1]/div/div[2]")
	public WebElement selectSunday1;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:item1daysSelected']/tbody/tr/td[3]/div/div[2]")
	public WebElement selectMonday1;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:item1daysSelected']/tbody/tr/td[5]/div/div[2]")
	public WebElement selectTuesday1;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:item1daysSelected']/tbody/tr/td[7]/div/div[2]")
	public WebElement selectWednesday1;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:item1daysSelected']/tbody/tr/td[9]/div/div[2]")
	public WebElement selectThursday1;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:item1daysSelected']/tbody/tr/td[11]/div/div[2]")
	public WebElement selectFriday1;

	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:item1daysSelected']/tbody/tr/td[13]/div/div[2]")
	public WebElement selectSaturday1;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:amtRadio1']/div[2]/span")
	public WebElement selectRadioAmt1;

	@FindBy(how = How.ID, using = "layoutForm:amountValue1")
	public WebElement amountValue1;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:spdRadio1']/div[2]")
	public WebElement selectRadioSpread1;
	
	@FindBy(how = How.ID, using = "layoutForm:base_room_type1")
	public WebElement baseRoomTypeDropDown1;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:base_room_type1']/option[1]")
	public WebElement selectBaseRoomType1;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:percent1']/div[2]")
	public WebElement selectPercentRadio1;
	
	@FindBy(how = How.ID, using = "layoutForm:spreadPercent1")
	public WebElement percentValue1;
	
	@FindBy(how = How.ID, using = "layoutForm:bt1nDelete0")
	public WebElement deleteSeason0;
	
	@FindBy(how = How.ID, using = "layoutForm:bt1nDelete1")
	public WebElement deleteSeason1;
	
	/*
	 * Room Sync
	 */
	@FindBy(how = How.ID, using = "layoutForm:syncOperaButton")
	public WebElement syncRoom;
	/*
	 * Pop up alert element
	 */
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:confirmDialogVal']/div[3]/div/button")
	public WebElement clickAlertOk;
	
/*	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:confirmDialogVal']/div[3]/div/button[2]")
	public WebElement clickAlertNo;*/
	
/*	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:j_idt212']/span")
	public WebElement clickAlertNo;*/
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:confirmDialogVal']/div[3]/div/button[2]/span")
	public WebElement clickAlertNo;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:alertDialogVal']/div[3]/div/button/span")
	public WebElement clickAlertOkMessage;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:pseudo']/div[2]")
	public WebElement pseudocheckbox;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:pseudo']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")
	public WebElement pseudocheckboxchkd;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:pseudo']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default']")
	public WebElement pseudocheckboxunchkd;
	
	@FindBy(how = How.ID, using = "layoutForm:next")
	public WebElement roomNxtButton;
	
	@FindBy(how = How.ID, using = "layoutForm:submitButton")
	public WebElement roomSubmitButton;
	
	@FindBy(how = How.ID, using = "layoutForm:dataTable:0:editButton")
	public WebElement editRoomlink;
	
} 

