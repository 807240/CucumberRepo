package com.mystique.containers;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MystiquePropertyContainer {

	@FindBy(how = How.ID, using = "layoutForm:setProperty")
	public WebElement propertySettingsMenu;
	
	@FindBy(how = How.ID, using = "layoutForm:powerRank")
	public WebElement BookingLimitations;
		
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:propertyList']/tbody/tr/td[1]/ul/li[1]")
	public WebElement selectProperty;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:propertyList']/tbody/tr/td[3]/ul/li[1]")
	public WebElement selectBackProperty;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:propertyList']/tbody/tr/td[2]/button[4]")
	public WebElement selectAllPropertyArrow;
	
//	@FindBy(how = How.ID, using = "layoutForm:saveButton")
//	public WebElement propertySaveButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:saveButton']")
	public WebElement propertySaveButton;
	
	@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:propertyRegion']")
	public WebElement propertyRegionDropdown;
	
	@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:syncRatesToOpera']/div[2]")
	public WebElement syncRatesToOpera;
	
	@FindBy(how = How.XPATH, using = "//*[@id='layoutForm:syncProgramsToOpera']/div[2]")
	public WebElement syncProgramsToOpera;
	
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:propertyList']/tbody/tr/td[2]/button[1]")
	public WebElement selectPropertyArrow;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:propertyList']/tbody/tr/td[2]/button[3]")
	public WebElement selectBackPropertyArrow;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:options']/tbody/tr/td[5]/div/div[2]")
	public WebElement propertySpecifiedRadioButton;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:filterDisplay']/div[3]")
	public WebElement displayDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:filterDisplay_panel']/div/ul/li[2]")
	public WebElement displayTotalPriceSelect;
	
	@FindBy(how = How.XPATH, xpath = "//*[contains(text(),'Expand All')]")
	public WebElement propertyExpandAll;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:resortFee']")
	public WebElement propertyResortFee;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:pwrRank']/div[3]/span")
	public WebElement powerRankSelectionDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:pwrRank_panel']/div/ul/li[2]")
	public WebElement powerRankMenuSelection;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dominantPlay']/div[3]/span")
	public WebElement dominantplaySelectionDropDown;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dominantPlay_panel']/div/ul/li[2]")
	public WebElement dominantplayMenuSelection;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:dominantPlay_panel']/div/ul/li[3]")
	public WebElement dominantplayMenuSelectionPoker;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:bookingLimitationsTable_data']/tr/td[1]")
	public WebElement CompMax;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:bookingLimitationsTable_data']/tr/td[2]")
	public WebElement RateMax;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:bookingLimitationsTable_data']/tr/td[3]")
	public WebElement WeeklyLimit;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:bookingLimitationsTable_data']/tr/td[4]")
	public WebElement DailyLimit;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:bookingLimitationsTable_data']/tr/td[5]")
	public WebElement BookingWindowCompLimit;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:bookingLimitationsTable_data']/tr/td[6]")
	public WebElement CompMaxConfig;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:bookingLimitationsTable_data']/tr/td[7]")
	public WebElement BookWindowRainLimit;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:saveButton']")
	public WebElement SaveBtn;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:messages_container']/div")
	public WebElement SaveConfirmation;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:backwardBookingLimits']")
	public WebElement LookBackDays; 
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:forwardBookingLimits']")
	public WebElement LookForwardDays; 
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:alertDialogVal']")
	public WebElement alertdialog;
	
	@FindBy(how = How.XPATH, xpath = "//*[@id='layoutForm:j_idt282']/span")
	public WebElement alertdialog_ok;
	
	@FindBy(how = How.XPATH, xpath = "//*[@class='ui-growl-message']/span")
	public WebElement confirmationonsave; 
}
