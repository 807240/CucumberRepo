package com.mystique.propertysteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueProgramView;
import com.mystique.view.MystiquePropertyView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PropertySettingsNavigationsSteps {
	private static final Logger LOGGER = Logger.getLogger(PropertySettingsNavigationsSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	@Given("^I click on the Drop Down to Select Property$")
	public void I_click_on_the_Drop_Down_to_Select_Property() {
		MystiqueProgramView.selectARIAfromDropDown();
	}

	@When("^I try to select any Property$")
	public void I_try_to_select_Property() {
		MystiquePropertyView.hoverOnPropertyTab();
		MystiquePropertyView.clickOnPropertySettingsTab();
	}
	@Then("^I should see Property related tabs$")
	public void I_should_see_Property_related_tabs() {
		LOGGER.info("I am seeing Property related tabs"); 
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/

}
