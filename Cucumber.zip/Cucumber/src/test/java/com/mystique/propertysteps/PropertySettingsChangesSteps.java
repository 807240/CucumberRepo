package com.mystique.propertysteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiquePropertyView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PropertySettingsChangesSteps {
	private static final Logger LOGGER = Logger.getLogger(PropertySettingsChangesSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();
	

	@Given("^I make changes in Selected Property$")
	public void I_make_changes_in_Selected_Property() {
		MystiquePropertyView.clickOnSelectPropertyTab();
	}

	@When("^I try to save Property$")
	public void I_try_to_save_Property() {
		MystiquePropertyView.clickOnSaveProperty();
	}
	@Then("^I should see relative changes in the Property$")
	public void I_should_see_relative_changes_in_the_Property() {
		LOGGER.info("I am seeing Property related tabs"); 
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/

}
