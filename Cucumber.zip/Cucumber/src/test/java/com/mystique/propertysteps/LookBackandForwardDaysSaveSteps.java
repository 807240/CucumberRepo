package com.mystique.propertysteps;

import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiquePropertyView;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LookBackandForwardDaysSaveSteps {
	private static final Logger LOGGER = Logger.getLogger(LookBackandForwardDaysSaveSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();
	

	//Scenario: Look back days and look forward days accept value from 0 to 999
	@Given("^I enter any value between zero and 999 in both the field$")
	public void I_enter_any_value_between_zero_and_999_in_both_the_field() {
		MystiquePropertyView.ExpandAll_RateSettings();
		MystiquePropertyView.LookBackDays_RateSettings();
		MystiquePropertyView.LookForwardDays_RateSettings();
		
	}
	@When("^I click on the save button$")
	public void I_click_on_the_save_button() {
		MystiquePropertyView.clickOnSaveProperty();
		
	}
	@Then("^I should see that the value get saved$")
	public void I_should_see_that_the_value_get_saved() {
		MystiquePropertyView.confirmation_on_save();
		
		
	}


	//Scenario: If look back days is provide then look forward days should also need to be provided 
		@Given("^I enter any value between zero and 999 in look back days$")
		public void I_enter_any_value_between_zero_and_999_in_look_back_days() {
			MystiquePropertyView.ExpandAll_RateSettings();
			MystiquePropertyView.LookBackDays_RateSettings();
			MystiquePropertyView.ClearLookForwardDaysvalue();
			
		}
		@When("^clicked on the save button$")
		public void clicked_on_the_save_button() {
			MystiquePropertyView.clickOnSaveProperty();
			
		}
		@Then("^I should see that the alert message asking to provide look forward days$")
		public void I_should_see_that_the_alert_message_asking_to_provide_look_forward_days() {
			MystiquePropertyView.alertdialogbox_LookForwardDays();
			
			
		}


	
	//Scenario: If look forward days is provide then look back days should also need to be provided 
		@Given("^I enter any value between zero and 999 in look forward days$")
		public void I_enter_any_value_between_zero_and_999_in_look_forward_days() {
			//MystiquePropertyView.ExpandAll_RateSettings();
			MystiquePropertyView.LookForwardDays_RateSettings();		
			MystiquePropertyView.ClearLookBackDaysvalue();
			
		}
		@When("^I click on the save$")
		public void I_click_on_the_save() {
			MystiquePropertyView.clickOnSaveProperty();
			
		}
		@Then("^I should see that the alert message asking to provide look back days$")
		public void I_should_see_that_the_alert_message_asking_to_provide_look_back_days() {
			MystiquePropertyView.alertdialogbox_LookBackDays();
			
			
		}

//Scenario: Look back days cannot accept value more than 999 
		@Given("^I enter any value more than 999 in look back days$")
		public void I_enter_any_value_more_than_999_in_look_back_days() {
			//MystiquePropertyView.ExpandAll_RateSettings();
			MystiquePropertyView.LookBackDays_RateSettings_morethan999();
			MystiquePropertyView.LookForwardDays_RateSettings();		
			
			
		}
		@When("^I try to save$")
		public void I_try_to_save () {
			MystiquePropertyView.clickOnSaveProperty();
			
		}
		@Then("^I should see that the alert message asking to provide look back days values from 0 to 999$")
		public void I_should_see_that_the_alert_message_asking_to_provide_look_back_days_values_from_0_to_999() {
			MystiquePropertyView.alertdialogbox_valuemorethan999();
			
			
		}

	
	//Scenario: Look forward days cannot accept value more than 999 
		@Given("^I enter any value more than 999 in look forward days$")
		public void  I_enter_any_value_more_than_999_in_look_forward_days() {
			//MystiquePropertyView.ExpandAll_RateSettings();
			MystiquePropertyView.LookBackDays_RateSettings();
			MystiquePropertyView.LookForwardDays_RateSettings_morethan999();		
			
			
		}
		@When("^I try to save the changes$")
		public void I_try_to_save_the_changes () {
			MystiquePropertyView.clickOnSaveProperty();
			
		}
		@Then("^I should see that the alert message asking to provide look forward days values from 0 to 999$")
		public void I_should_see_that_the_alert_message_asking_to_provide_look_forward_days_values_from_0_to_999() {
			MystiquePropertyView.alertdialogbox_valuemorethan999();
			
			
		}

}
