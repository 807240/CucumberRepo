package com.mystique.propertysteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueProgramView;
import com.mystique.view.MystiquePropertyView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BookingLimitationsNavigationsSteps {
	private static final Logger LOGGER = Logger.getLogger(BookingLimitationsNavigationsSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	@Given("^I am on the Property menu$")
	public void I_am_on_the_Property_menu() {
		MystiqueProgramView.selectBORGATAfromDropDown();
	}

	@When("^I click on the Booking Limitations link$")
	public void I_click_on_the_Booking_Limitations_link() {
		MystiquePropertyView.hoverOnPropertyTab();
		MystiquePropertyView.clickOnBookingLimitationsTab();
	}
	@Then("^I should see Booking Limitations related tabs$")
	public void I_should_see_Booking_Limitations_related_tabs() {
		LOGGER.info("I am seeing Booking Limitations related tabs"); 
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/

}
