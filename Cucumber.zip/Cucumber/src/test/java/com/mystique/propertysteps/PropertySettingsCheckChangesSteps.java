package com.mystique.propertysteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiquePropertyView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PropertySettingsCheckChangesSteps {
	private static final Logger LOGGER = Logger.getLogger(PropertySettingsCheckChangesSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();
	

	@Given("^I check and make changes in Selected Property$")
	public void I_check_and_make_changes_in_Selected_Property() {
		MystiquePropertyView.hoverOnPropertyTab();
		MystiquePropertyView.clickOnPropertySettingsTab();
		MystiquePropertyView.clickOnSelectPropertyCheckChangeTab();
	}

	@When("^I try to save changes in Property$")
	public void I_try_to_save_changes_Property() {
		MystiquePropertyView.clickOnSaveProperty();
	}
	@Then("^I should see again relative changes in the Property$")
	public void I_should_see_again_relative_changes_in_the_Property() {
		LOGGER.info("I am seeing Property related tabs and corresponding changes."); 
	}
	
	@Given("^I enter a value with less than 3 decimal places$")
	public void I_enter_a_value_with_less_than_3_decimal_places() {
		MystiquePropertyView.hoverOnPropertyTab();
		//MystiquePropertyView.clickOnPropertySettingsTab();
		
		
	}

	@When("^I move focus from the Resort fee field$")
	public void I_move_focus_from_the_Resort_fee_field() {
		MystiquePropertyView.provideResortFeeValue2();
	}
	@Then("^I should see that Resort fee is trailed with 0 till 3 decimal places$")
	public void I_should_see_that_Resort_fee_is_trailed_with_0_till_3_decimal_places() {
		MystiquePropertyView.checkResortFeeValue2TabOut();
		LOGGER.info("PASS,The value is rounded to 3 decimal places."); 
	}

	
	
	
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/


}
