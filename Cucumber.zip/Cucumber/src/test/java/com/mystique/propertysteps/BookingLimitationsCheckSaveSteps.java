package com.mystique.propertysteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiquePropertyView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BookingLimitationsCheckSaveSteps {
	private static final Logger LOGGER = Logger.getLogger(BookingLimitationsCheckSaveSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();
	
	
//Scenario: Booking Limitations Check Save Scenario for Table and Comp Max
@Given("^I select Power Rank value and Dominant Play as Table for Comp Max$")
public void I_select_Power_Rank_value_and_Dominant_Play_as_Table_for_Comp_Max() {
	MystiquePropertyView.selectPowerRank();
	MystiquePropertyView.selectDominantPlay();
	
}

@When("^I enter the value for Comp Max and save it$")
public void I_enter_the_value_for_Comp_Max_and_save_it() {
	MystiquePropertyView.provideCompMaxValue();
	MystiquePropertyView.clickSaveBookingLimitations();
	
}

@Then("^I should see that the Comp Max value get saved$")
public void I_should_see_that_the_Comp_Max_value_get_saved() {
	MystiquePropertyView.saveConfirmationBookingLimitations_CompMax();
	
	
}

//Scenario: Booking Limitations Check Save Scenario for Table and Rate Max
@Given("^I select Power Rank value and Dominant Play as Table for Rate Max$")
public void I_select_Power_Rank_value_and_Dominant_Play_as_Table_for_Rate_Max() {
	MystiquePropertyView.selectPowerRank();
	MystiquePropertyView.selectDominantPlay();
		
}

@When("^I enter the value for Rate Max and save it$")
public void I_enter_the_value_for_Rate_Max_and_save_it() {
	MystiquePropertyView.provideRateMaxValue();
	MystiquePropertyView.clickSaveBookingLimitations();
		
}
	
@Then("^I should see that the Rate Max value get saved$")
public void I_should_see_that_the_Rate_Max_value_get_saved() {
	MystiquePropertyView.saveConfirmationBookingLimitations_RateMax();
}


//**Scenario: Booking Limitations Check Save Scenario for Table and Weekly Limit
@Given("^I select Power Rank value and Dominant Play as Table for Weekly Limit$")
public void I_select_Power_Rank_value_and_Dominant_Play_as_Table_for_Weekly_Limit() {
	MystiquePropertyView.selectPowerRank();
	MystiquePropertyView.selectDominantPlay();
		
}

@When("^I enter the value for Weekly Limit and save it$")
public void I_enter_the_value_for_Weekly_Limit_and_save_it() {
	MystiquePropertyView.provideWeeklyLimitValue();
	MystiquePropertyView.clickSaveBookingLimitations();
		
}
	
@Then("^I should see that the Weekly Limit value get saved$")
public void I_should_see_that_the_Weekly_Limit_value_get_saved() {
	MystiquePropertyView.saveConfirmationBookingLimitations_WeeklyLimit();
		
	//LOGGER.info("I am seeing Property related tabs and corresponding changes."); 
}
	
//**Scenario: Booking Limitations Check Save Scenario for Table and Daily Limit
@Given("^I select Power Rank value and Dominant Play as Table for Daily Limit$")
public void I_select_Power_Rank_value_and_Dominant_Play_as_Table_for_Daily_Limit() {
	MystiquePropertyView.selectPowerRank();
	MystiquePropertyView.selectDominantPlay();
		
}

@When("^I enter the value for Daily Limit and save it$")
public void I_enter_the_value_for_Daily_Limit_and_save_it() {
	MystiquePropertyView.provideDailyLimitValue();
	MystiquePropertyView.clickSaveBookingLimitations();
		
}
	
@Then("^I should see that the Daily Limit value get saved$")
public void I_should_see_that_the_Daily_Limit_value_get_saved() {
	MystiquePropertyView.saveConfirmationBookingLimitations_DailyLimit();
		
	//LOGGER.info("I am seeing Property related tabs and corresponding changes."); 
}

//**Scenario: Booking Limitations Check Save Scenario for Table and Booking Window Comp Limit
@Given("^I select Power Rank value and Dominant Play as Table for Booking Window Comp Limit$")
public void I_select_Power_Rank_value_and_Dominant_Play_as_Table_for_Booking_Window_Comp_Limit() {
	MystiquePropertyView.selectPowerRank();
	MystiquePropertyView.selectDominantPlay();
		
}

@When("^I enter the value for Booking Window Comp Limit and save it$")
public void I_enter_the_value_for_Booking_Window_Comp_Limit_and_save_it() {
	MystiquePropertyView.provideBookingWindowCompLimitValue();
	MystiquePropertyView.clickSaveBookingLimitations();
		
}
	
@Then("^I should see that the Booking Window Comp Limit value get saved$")
public void I_should_see_that_the_Booking_Window_Comp_Limit_value_get_saved() {
	MystiquePropertyView.saveConfirmationBookingLimitations_BookingWindowCompLimit();
		
	//LOGGER.info("I am seeing Property related tabs and corresponding changes."); 
}


//**Scenario: Booking Limitations Check Save Scenario for Table and Comp Max Config
@Given("^I select Power Rank value and Dominant Play as Table for Comp Max Config$")
public void I_select_Power_Rank_value_and_Dominant_Play_as_Table_for_Comp_Max_Config() {
	MystiquePropertyView.selectPowerRank();
	MystiquePropertyView.selectDominantPlay();
		
}

@When("^I enter the value for Comp Max Config and save it$")
public void I_enter_the_value_for_Comp_Max_Config_and_save_it() {
	MystiquePropertyView.provideCompMaxConfigValue();
	MystiquePropertyView.clickSaveBookingLimitations();
		
}
	
@Then("^I should see that the Comp Max Config value get saved$")
public void I_should_see_that_the_Comp_Max_Config_value_get_saved() {
	MystiquePropertyView.saveConfirmationBookingLimitations_CompMaxConfig();
		
	//LOGGER.info("I am seeing Property related tabs and corresponding changes."); 
}
//**Scenario: Booking Limitations Check Save Scenario for Table and Booking Window Rain Limit
@Given("^I select Power Rank value and Dominant Play as Table for Booking Window Rain Limit$")
public void I_select_Power_Rank_value_and_Dominant_Play_as_Table_for_Booking_Window_Rain_Limit() {
	MystiquePropertyView.selectPowerRank();
	MystiquePropertyView.selectDominantPlay();
		
}

@When("^I enter the value for Booking Window Rain Limit and save it$")
public void I_enter_the_value_for_Booking_Window_Rain_Limit_and_save_it() {
	MystiquePropertyView.provideBookWindowRainLimitValue();
	MystiquePropertyView.clickSaveBookingLimitations();
		
}
	
@Then("^I should see that the Booking Window Rain Limit value get saved$")
public void I_should_see_that_the_Booking_Window_Rain_Limit_value_get_saved() {
	MystiquePropertyView.saveConfirmationBookingLimitations_BookWindowRainLimit();
		
	//LOGGER.info("I am seeing Property related tabs and corresponding changes."); 
}

//Scenario:I select Power Rank value and Dominant Play as Poker for Comp Max
@Given("^I select Power Rank value and Dominant Play as Poker for Comp Max$")
public void I_select_Power_Rank_value_and_Dominant_Play_as_Poker_for_Comp_Max() {
	MystiquePropertyView.selectPowerRank();
	MystiquePropertyView.selectDominantPlayAsPoker();
	
}

@When("^Dominant Play was selected as Poker and I enter the value for Comp Max and save it$")
public void Dominant_Play_was_selected_as_Poker_and_I_enter_the_value_for_Comp_Max_and_save_it() {
	MystiquePropertyView.provideCompMaxValue();
	MystiquePropertyView.clickSaveBookingLimitations();
	
}
@Then("^I should see that the Comp Max value get saved for Poker$")
public void I_should_see_that_the_Comp_Max_value_get_saved_for_Poker (){
	MystiquePropertyView.saveConfirmationBookingLimitations_CompMax();
	
	
}


//Scenario: Booking Limitations Check Save Scenario for Poker and Rate Max
@Given("^I select Power Rank value and Dominant Play as Poker for Rate Max$")
public void I_select_Power_Rank_value_and_Dominant_Play_as_Poker_for_Rate_Max() {
	MystiquePropertyView.selectPowerRank();
	MystiquePropertyView.selectDominantPlayAsPoker();
		
}

@When("^Dominant Play was selected as Poker and I enter the value for Rate Max and save it$")
public void Dominant_Play_was_selected_as_Poker_and_I_enter_the_value_for_Rate_Max_and_save_it() {
	MystiquePropertyView.provideRateMaxValue();
	MystiquePropertyView.clickSaveBookingLimitations();
		
}
	
@Then("^I should see that the Rate Max value get saved for Poker$")
public void I_should_see_that_the_Rate_Max_value_get_saved_for_Poker (){
	MystiquePropertyView.saveConfirmationBookingLimitations_RateMax();
}	
	

//**Scenario: Booking Limitations Check Save Scenario for Poker and Weekly Limit
@Given("^I select Power Rank value and Dominant Play as Poker for Weekly Limit$")
public void I_select_Power_Rank_value_and_Dominant_Play_as_Poker_for_Weekly_Limit()  {
	MystiquePropertyView.selectPowerRank();
	MystiquePropertyView.selectDominantPlayAsPoker();
		
}

@When("^Dominant Play was selected as Poker and I enter the value for Weekly Limit and save it$")
public void Dominant_Play_was_selected_as_Poker_and_I_enter_the_value_for_Weekly_Limit_and_save_it(){
	MystiquePropertyView.provideWeeklyLimitValue();
	MystiquePropertyView.clickSaveBookingLimitations();
		
}
	
@Then("^I should see that the Weekly Limit value get saved for Poker$")
public void I_should_see_that_the_Weekly_Limit_value_get_saved_for_Poker (){
	MystiquePropertyView.saveConfirmationBookingLimitations_WeeklyLimit();
		
	//LOGGER.info("I am seeing Property related tabs and corresponding changes."); 
}


//**Scenario: Booking Limitations Check Save Scenario for Poker and Daily Limit
@Given("^I select Power Rank value and Dominant Play as Poker for Daily Limit$")
public void I_select_Power_Rank_value_and_Dominant_Play_as_Poker_for_Daily_Limit()  {
	MystiquePropertyView.selectPowerRank();
	MystiquePropertyView.selectDominantPlayAsPoker();
		
}

@When("^Dominant Play was selected as Poker and I enter the value for Daily Limit and save it$")
public void Dominant_Play_was_selected_as_Poker_and_I_enter_the_value_for_Daily_Limit_and_save_it(){
	MystiquePropertyView.provideDailyLimitValue();
	MystiquePropertyView.clickSaveBookingLimitations();
		
}
	
@Then("^I should see that the Daily Limit value get saved for Poker$")
public void I_should_see_that_the_Daily_Limit_value_get_saved_for_Poker (){
	MystiquePropertyView.saveConfirmationBookingLimitations_DailyLimit();
		
	//LOGGER.info("I am seeing Property related tabs and corresponding changes."); 
}


//**Scenario: Booking Limitations Check Save Scenario for Poker and Booking Window Comp Limit
@Given("^I select Power Rank value and Dominant Play as Poker for Booking Window Comp Limit$")
public void I_select_Power_Rank_value_and_Dominant_Play_as_Poker_for_Booking_Window_Comp_Limit()  {
	MystiquePropertyView.selectPowerRank();
	MystiquePropertyView.selectDominantPlayAsPoker();
		
}
@When("^Dominant Play was selected as Poker and I enter the value for Booking Window Comp Limit and save it$")
public void Dominant_Play_was_selected_as_Poker_and_I_enter_the_value_for_Booking_Window_Comp_Limit_and_save_it(){
	MystiquePropertyView.provideBookingWindowCompLimitValue();
	MystiquePropertyView.clickSaveBookingLimitations();
		
}
	
@Then("^I should see that the Booking Window Comp Limit value get saved for Poker$")
public void I_should_see_that_the_Booking_Window_Comp_Limit_value_get_saved_for_Poker (){
	MystiquePropertyView.saveConfirmationBookingLimitations_BookingWindowCompLimit();
		
	//LOGGER.info("I am seeing Property related tabs and corresponding changes."); 
}


//**Scenario: Booking Limitations Check Save Scenario for Poker and Comp Max Config
@Given("^I select Power Rank value and Dominant Play as Poker for Comp Max Config$")
public void I_select_Power_Rank_value_and_Dominant_Play_as_Poker_for_Comp_Max_Config() {
	MystiquePropertyView.selectPowerRank();
	MystiquePropertyView.selectDominantPlayAsPoker();
		
}

@When("^Dominant Play was selected as Poker and I enter the value for Comp Max Config and save it$")
public void Dominant_Play_was_selected_as_Poker_and_I_enter_the_value_for_Comp_Max_Config_and_save_it(){
	MystiquePropertyView.provideCompMaxConfigValue();
	MystiquePropertyView.clickSaveBookingLimitations();
		
}
	
@Then("^I should see that the Comp Max Config value get saved for Poker$")
public void I_should_see_that_the_Comp_Max_Config_value_get_saved_for_Poker (){
	MystiquePropertyView.saveConfirmationBookingLimitations_CompMaxConfig();
		
	//LOGGER.info("I am seeing Property related tabs and corresponding changes."); 
}


//**Scenario: Booking Limitations Check Save Scenario for Poker and Booking Window Rain Limit
@Given("^I select Power Rank value and Dominant Play as Poker for Booking Window Rain Limit$")
public void I_select_Power_Rank_value_and_Dominant_Play_as_Poker_for_Booking_Window_Rain_Limit() {
	MystiquePropertyView.selectPowerRank();
	MystiquePropertyView.selectDominantPlayAsPoker();
		
}

@When("^Dominant Play was selected as Poker and I enter the value for Booking Window Rain Limit and save it$")
public void Dominant_Play_was_selected_as_Poker_and_I_enter_the_value_for_Booking_Window_Rain_Limit_and_save_it() {
	MystiquePropertyView.provideBookWindowRainLimitValue();
	MystiquePropertyView.clickSaveBookingLimitations();
		
}
	
@Then("^I should see that the Booking Window Rain Limit value get saved for Poker$")
public void I_should_see_that_the_Booking_Window_Rain_Limit_value_get_saved_for_Poker () {
	MystiquePropertyView.saveConfirmationBookingLimitations_BookWindowRainLimit();
		
	//LOGGER.info("I am seeing Property related tabs and corresponding changes."); 
}

}
