package com.mystique.generaladministration;

import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.cucumber.listener.ExtentCucumberFormatter;
import com.mystique.application.BrowserDriver;
import com.mystique.utils.CommonUtils;
import com.mystique.view.MystiqueGeneralAdministrationView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OperaDataSync {

	private static final Logger LOGGER = Logger
			.getLogger(OperaDataSync.class.getName());

	/*
	 * private static final MystiqueProgramContainer programContainer =
	 * PageFactory .initElements(BrowserDriver.getCurrentDriver(),
	 * MystiqueProgramContainer.class);
	 * 
	 * ValidateSearchByCustomerValue obj = new ValidateSearchByCustomerValue();
	 * 
	 * 
	 * 
	 * boolean validate;
	 */

	/*
	 * private static final MystiqueDashboardContainer dashboardContainer =
	 * PageFactory .initElements(BrowserDriver.getCurrentDriver(),
	 * MystiqueDashboardContainer.class);
	 */

	BrowserDriver bd = new BrowserDriver();
	static WebDriver wd = BrowserDriver.getCurrentDriver();
	static CommonUtils Util = new CommonUtils();
	// MystiqueProgramContainer programContainer = new
	// MystiqueProgramContainer();

	// static String count=wd.findElement(By.xpath(
	// "//*[@id='layoutForm:dataTable_paginator_bottom']/span[1]")).getText();
	/*static Integer totalcount1;
	static Integer activecount1;
	static Integer inactivecount1;*/

	@Given("^I navigate to General Administration page$")
	public void I_navigate_to_General_Administration_page() {
		MystiqueGeneralAdministrationView.hoverOnOperaData();
		
	}

	@When("^I click on the Opera Data_Static pages$")
	public void I_click_on_the_Opera_Data_Static_pages() {

		MystiqueGeneralAdministrationView.selectStaticData();
	}

	@Then("^I should see the Opera Static pages$")
	public void I_should_see_the_Opera_Static_pages() {
		MystiqueGeneralAdministrationView.verifyStaticDataPage();		
	}


	@When("^I click on the Opera Data_Dynamic pages$")
	public void I_click_on_the_Opera_Data_Dynamic_pages() {

		MystiqueGeneralAdministrationView.selectDynamicData();
	}

	@Then("^I should see the Opera Dynamic pages$")
	public void I_should_see_the_Opera_Dynamic_pages() {
		MystiqueGeneralAdministrationView.verifyDynamicDataPage();		
	}
	
	
	@Given("^I navigate to Alert Area Code tab$")
	public void I_navigate_to_Alert_Area_Code_tab() {
		MystiqueGeneralAdministrationView.hoverOnOperaData();
		MystiqueGeneralAdministrationView.selectStaticData();
		MystiqueGeneralAdministrationView.clickOnAlertAreaCode();
		
	}

	@When("^I select a property$")
	public void I_select_a_property() {

		MystiqueGeneralAdministrationView.selectPropertyforAlertArea();
	}

	@Then("^I should see the Data for Alert Area Code$")
	public void I_should_see_the_Data_for_Alert_Area_Code() {
		MystiqueGeneralAdministrationView.verifyAlertAreaData();		
	}
	
	
	@Given("^I navigate to Alert Codes tab$")
	public void I_navigate_to_Alert_Codes_tab() {
		//MystiqueGeneralAdministrationView.hoverOnOperaData();
		//MystiqueGeneralAdministrationView.selectStaticData();
		MystiqueGeneralAdministrationView.clickOnAlertCodes();
		
	}

	@When("^I select a property for Alert Codes$")
	public void I_select_a_property_for_Alert_Codes() {

		MystiqueGeneralAdministrationView.selectPropertyforAlertCodes();
	}

	@Then("^I should see the Data for Alert Codes$")
	public void I_should_see_the_Data_for_Alert_Codes() {
		MystiqueGeneralAdministrationView.verifyAlertCodesData();		
	}
	
	
	
	@Given("^I navigate to Opera Static page$")
	public void I_navigate_to_Opera_Static_page() {
		MystiqueGeneralAdministrationView.hoverOnOperaData();
		MystiqueGeneralAdministrationView.selectStaticData();
		
	}

	@When("^I select  Country Codes tab$")
	public void I_select_Country_Codes_tab() {

		MystiqueGeneralAdministrationView.clickOnCountryCodestab();
	}

	@Then("^I should see the Data for Country Codes$")
	public void I_should_see_the_Data_for_Country_Codes() {
		MystiqueGeneralAdministrationView.verifyCountryCodesData();		
	}
	
	@Given("^I select Reservation Types tab$")
	public void I_select_Reservation_Types_tab() {
		MystiqueGeneralAdministrationView.clickOnRevervationTypestab();	
	}

	
	@When("^I select  a property for Reservation Types")
	public void I_select_a_property_for_Reservation_Types() {

		MystiqueGeneralAdministrationView.selectPropertyforRevervationTypes();
	}

	@Then("^I should see the Data for Reservation Types$")
	public void I_should_see_the_Data_for_Reservation_Types() {
		MystiqueGeneralAdministrationView.verifyReservationTypesData();		
	}
	
	
	@Given("^I select Deposit Rules tab$")
	public void I_select_Deposit_Rules_tab() {
		MystiqueGeneralAdministrationView.clickOnDepositRulestab();	
	}

	
	@When("^I select  a property for Deposit Rules")
	public void I_select_a_property_for_Deposit_Rules() {

		MystiqueGeneralAdministrationView.selectPropertyforDepositRules();
	}

	@Then("^I should see the Data for Deposit Rules$")
	public void I_should_see_the_Data_for_Deposit_Rules() {
		MystiqueGeneralAdministrationView.verifyDepositRulesData();		
	}
	
	
	@Given("^I select Cancellation Rules tab$")
	public void I_select_Cancellation_Rules_tab() {
		MystiqueGeneralAdministrationView.clickOnCancellationRulestab();	
	}

	
	@When("^I select  a property for Cancellation Rules")
	public void I_select_a_property_for_Cancellation_Rules() {

		MystiqueGeneralAdministrationView.selectPropertyforCancellationRules();
	}

	@Then("^I should see the Data for Cancellation Rules$")
	public void I_should_see_the_Data_for_Cancellation_Rules() {
		MystiqueGeneralAdministrationView.verifyCancellationRulesData();		
	}
	
	
	@Given("^I select Opera Rate Category tab$")
	public void I_select_Opera_Rate_Category_tab() {
		MystiqueGeneralAdministrationView.clickOnOperaRateCategorytab();	
	}

	
	@When("^I select  a property for Opera Rate Category")
	public void I_select_a_property_for_Opera_Rate_Category() {

		MystiqueGeneralAdministrationView.selectPropertyforOperaRateCategory();
	}

	@Then("^I should see the Data for Opera Rate Category$")
	public void I_should_see_the_Data_for_Opera_Rate_Category() {
		MystiqueGeneralAdministrationView.verifyOperaRateCategoryData();		
	}
	
	
	@Given("^I navigate to Opera Static page for Player Tier$")
	public void I_navigate_to_Opera_Static_page_for_Player_Tier() {
		MystiqueGeneralAdministrationView.hoverOnOperaData();
		MystiqueGeneralAdministrationView.selectStaticData();	
		
	}

	
	@When("^I  select Player Tier")
	public void I_select_Player_Tier() {

		MystiqueGeneralAdministrationView.clickOnPlayerTiertab();		
	}

	@Then("^I should see the Data for Player Tier$")
	public void I_should_see_the_Data_for_Player_Tier() {
		MystiqueGeneralAdministrationView.verifyPlayerTierData();		
	}
	
	
	@Given("^I select Promotion Group tab$")
	public void I_select_Promotion_Group_tab() {
		MystiqueGeneralAdministrationView.clickOnPromotionGrouptab();	
	}

	
	@When("^I select  a property for Promotion Group")
	public void I_select_a_property_for_Promotion_Group() {

		MystiqueGeneralAdministrationView.selectPropertyforPromotionGroup();
	}

	@Then("^I should see the Data for Promotion Group$")
	public void I_should_see_the_Data_for_Promotion_Group() {
		MystiqueGeneralAdministrationView.verifyPromotionGroupData();		
	}
	
	
	@Given("^I select Trace and Department Codes tab$")
	public void I_select_Transaction_Codes_tab() {
		MystiqueGeneralAdministrationView.clickOnTraceAndDepartmentCodestab();	
	}

	
	@When("^I select  a property for Trace and Department Codes")
	public void I_select_a_property_for_Transaction_Codes() {

		MystiqueGeneralAdministrationView.selectPropertyforTraceDepartmentCodes();
	}

	@Then("^I should see the Data for Trace and Department Codes$")
	public void I_should_see_the_Data_for_Transaction_Codes() {
		MystiqueGeneralAdministrationView.verifyTraceDepartmentCodesData();		
	}
	
	
	
	//Soumen Bose 
	
	@Given("^I select Routing Authorizers tab$")
	public void I_select_Routing_Authorizers_tab() {
		System.out.println("inside routing authorizers....");
		MystiqueGeneralAdministrationView.clickOnRoutingAuthorizersTab();	
	}

	
	@When("^I select  a property for Routing Authorizers")
	public void I_select_a_property_for_Routing_Authorizers() {

		MystiqueGeneralAdministrationView.selectPropertyforRoutingAuthorizers();
	}

	@Then("^I should see the Data for Routing Authorizers$")
	public void I_should_see_the_Data_for_Routing_Authorizers() {
		MystiqueGeneralAdministrationView.verifyRoutingAuthorizersData();		
	}
	
	
	@Given("^I select Routing Codes tab$")
	public void I_select_Routing_Codes_tab() {
		MystiqueGeneralAdministrationView.clickOnRoutingCodesTab();	
	}

	
	@When("^I select  a property for Routing Codes$")
	public void I_select_a_property_for_Routing_Codes() {

		MystiqueGeneralAdministrationView.selectPropertyforRoutingCodes();
	}

	@Then("^I should see the Data for Routing Codes$")
	public void I_should_see_the_Data_for_Routing_Codes() {
		MystiqueGeneralAdministrationView.verifyRoutingCodesData();		
	}
	
	
	
	@Given("^I navigate to Opera Dynamic page$")
	public void I_navigate_to_Opera_Dynamic_page() {
		MystiqueGeneralAdministrationView.hoverOnOperaData();
		MystiqueGeneralAdministrationView.selectDynamicData();
		
	}

	@When("^I select Cancellation codes tab$")
	public void I_select_Cacellation_Codes_tab() {

		MystiqueGeneralAdministrationView.clickOnCancellationCodestab();
	}

	@Then("^I should see the Data for Cancellation codes$")
	public void I_should_see_the_Data_for_Cancellation_Codes() {
		MystiqueGeneralAdministrationView.verifyCancellationCodesData();		
	}
	
	
	@When("^I select Promo codes tab$")
	public void I_select_Promo_Codes_tab() {

		MystiqueGeneralAdministrationView.clickOnPromoCodestab();
	}

	@Then("^I should see the Data for Promo codes$")
	public void I_should_see_the_Data_for_Promo_Codes() {
		MystiqueGeneralAdministrationView.verifyPromoCodesData();		
	}
	
	
	
	@When("^I select Travel Agents tab$")
	public void I_select_Travel_Agents_tab() {

		MystiqueGeneralAdministrationView.clickOnTravelAgentstab();
	}

	@Then("^I should see the Data for Travel Agents$")
	public void I_should_see_the_Data_for_Travel_Agents() {
		MystiqueGeneralAdministrationView.verifyTravelAgentsData();		
	}
	
	
	
	@When("^I select Zip codes tab$")
	public void I_select_Zip_Codes_tab() {

		MystiqueGeneralAdministrationView.clickOnZipCodestab();
	}

	@Then("^I should see the Data for Zip codes$")
	public void I_should_see_the_Data_for_Zip_Codes() {
		MystiqueGeneralAdministrationView.verifyZipCodesData();		
	}
	
	
	
	@When("^I select Company Profiles tab$")
	public void I_select_Company_Profiles_tab() {

		MystiqueGeneralAdministrationView.clickOnCompanyProfilestab();
	}

	@Then("^I should see the Data for Company Profiles$")
	public void I_should_see_the_Data_for_Company_Profiles() {
		MystiqueGeneralAdministrationView.verifyCompanyProfilesData();		
	}
	
	
	
	@Given("^I select Market Codes tab$")
	public void I_select_Market_Codes_tab() {
		MystiqueGeneralAdministrationView.clickOnMarketCodesTab();	
	}

	
	@When("^I select  a property for Market Codes$")
	public void I_select_a_property_for_Market_Codes() {

		MystiqueGeneralAdministrationView.selectPropertyforMarketCodes();
	}

	@Then("^I should see the Data for Market Codes$")
	public void I_should_see_the_Data_for_Market_Codes() {
		MystiqueGeneralAdministrationView.verifyMarketCodesData();		
	}
	
	
	
	@Given("^I select Source Codes tab$")
	public void I_select_Source_Codes_tab() {
		MystiqueGeneralAdministrationView.clickOnSourceCodesTab();	
	}

	
	@When("^I select  a property for Source Codes$")
	public void I_select_a_property_for_Source_Codes() {

		MystiqueGeneralAdministrationView.selectPropertyforSourceCodes();
	}

	@Then("^I should see the Data for Source Codes$")
	public void I_should_see_the_Data_for_Source_Codes() {
		MystiqueGeneralAdministrationView.verifySourceCodesData();		
	}
	
	
	/*@Given("^I select Transaction Codes tab$")
	public void I_select_Transaction_Codes_tab() {
		MystiqueGeneralAdministrationView.clickOnTransactionCodestab();	
	}

	
	@When("^I select  a property for Transaction Codes")
	public void I_select_a_property_for_Transaction_Codes() {

		MystiqueGeneralAdministrationView.selectPropertyforTransactionCodes();
	}

	@Then("^I should see the Data for Transaction Codes$")
	public void I_should_see_the_Data_for_Transaction_Codes() {
		MystiqueGeneralAdministrationView.verifyTransactionCodesData();		
	}*
	
	/*@Given("^I navigate to Opera Static page for Turnaway Codes$")
	public void I_navigate_to_Opera_Static_page_for_Turnaway_Codes() {
		MystiqueGeneralAdministrationView.hoverOnOperaData();
		MystiqueGeneralAdministrationView.selectStaticData();	
		
	}

	
	@When("^I  select Turnaway Codes")
	public void I_select_Turnaway_Codes() {

		MystiqueGeneralAdministrationView.clickOnTurnawayCodestab();		
	}

	@Then("^I should see the Data for Turnaway Codes$")
	public void I_should_see_the_Data_for_Turnaway_Codes() {
		MystiqueGeneralAdministrationView.verifyTurnawayCodesData();		
	}*/
	
	
	
	
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }
*/
}
