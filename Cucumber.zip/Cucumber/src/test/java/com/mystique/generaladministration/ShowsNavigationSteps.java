package com.mystique.generaladministration;

import java.util.List;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.MystiqueDashboardContainer;
import com.mystique.utils.CommonUtils;
import com.mystique.view.MystiqueGeneralAdministrationView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class ShowsNavigationSteps {
	private static final Logger LOGGER = Logger.getLogger(ShowsNavigationSteps.class.getName());
	BrowserDriver bd = new BrowserDriver();
	private static final MystiqueDashboardContainer dashboardContainer = PageFactory
			.initElements(BrowserDriver.getCurrentDriver(),
					MystiqueDashboardContainer.class);
	static WebDriver wd=BrowserDriver.getCurrentDriver();
	static CommonUtils Util=new CommonUtils();
	static Integer totalcount1;
	
	 @Given("^I click on the Shows Drop Down$")
	  public void I_click_on_the_Drop_Down_to_Select_Program_and_Select_Property_Administration() {
		
		  ShowsDropDown();
	  }

	 @When("^I try to select Categories$")
	 public void I_try_to_select_Manage_Properties() {
		 NavigateCategories();
	 }
	 @Then("^I should see all Show Category$")
	 public void I_should_see_allCategory() {
		Boolean isCategoryDisplayed=wd.findElements(By.xpath("//*[contains(text(),'Show Category Library')]")).size()>0;
		 totalcount1 = MystiqueGeneralAdministrationView.totalShowCategoryCalc();
		if(isCategoryDisplayed)
		{
		LOGGER.info("I am seeing all Categories"); 
	 }
		else
		{
			LOGGER.info("I am unable to see all Categories");	
		}
	 }


public static void ShowsDropDown(){
	
	try {
		Thread.sleep(5000);
		LOGGER.info("Selecting Shows");

		Util.waitTimeElementVisibility(wd.findElement(By.xpath("//*[contains(text(),'Shows')]")));
		Actions action = new Actions(wd);
		WebElement we =wd.findElement(By.xpath("//*[contains(text(),'Shows')]"));
		List<WebElement> listwe =wd.findElements(By.xpath("//*[contains(text(),'Shows')]"));
		Assert.assertTrue("Failed, Shows text is not present",listwe.size() > 0);
		//Assert.assertTrue("PASS, User Administration text is present",we.isDisplayed());
		action.moveToElement(we).build().perform();
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

public static void NavigateCategories(){
	LOGGER.info("Selecting Manage Users");
	 try {
		 Thread.sleep(10000);
		 int intTest = wd.findElements(By.xpath("//*[contains(text(),'Categories')]")).size();
		 Assert.assertTrue("Failed, Categories element is not present",intTest > 0);
		// Assert.assertTrue("PASS, Manage Users element is present",dashboardContainer.ManageUsers.isDisplayed());
		dashboardContainer.Categories.click();
		Thread.sleep(10000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

}