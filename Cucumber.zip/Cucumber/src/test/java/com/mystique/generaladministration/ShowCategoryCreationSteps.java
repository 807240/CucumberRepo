package com.mystique.generaladministration;

import java.util.List;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.cucumber.listener.ExtentCucumberFormatter;
import com.mystique.application.BrowserDriver;
import com.mystique.utils.CommonUtils;
import com.mystique.view.MystiqueGeneralAdministrationView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ShowCategoryCreationSteps {

	private static final Logger LOGGER = Logger
			.getLogger(ShowCategoryCreationSteps.class.getName());

	/*
	 * private static final MystiqueProgramContainer programContainer =
	 * PageFactory .initElements(BrowserDriver.getCurrentDriver(),
	 * MystiqueProgramContainer.class);
	 * 
	 * ValidateSearchByCustomerValue obj = new ValidateSearchByCustomerValue();
	 * 
	 * 
	 * 
	 * boolean validate;
	 */

	/*
	 * private static final MystiqueDashboardContainer dashboardContainer =
	 * PageFactory .initElements(BrowserDriver.getCurrentDriver(),
	 * MystiqueDashboardContainer.class);
	 */

	BrowserDriver bd = new BrowserDriver();
	static WebDriver wd = BrowserDriver.getCurrentDriver();
	static CommonUtils Util = new CommonUtils();
	JavascriptExecutor executor = (JavascriptExecutor) wd; 
	// MystiqueProgramContainer programContainer = new
	// MystiqueProgramContainer();

	// static String count=wd.findElement(By.xpath(
	// "//*[@id='layoutForm:dataTable_paginator_bottom']/span[1]")).getText();
	static Integer totalcount1;
	static Integer activecount1;
	static Integer inactivecount1;

	

	@Given("^I see all Show Category$")
	public void viewRestaurant() { 
		
		
		try {
			LOGGER.info("Selecting Shows Category Administration");

			Util.waitTimeElementVisibility(wd.findElement(By.xpath("//*[contains(text(),'Shows')]")));
			Actions action = new Actions(wd);
			WebElement we =wd.findElement(By.xpath("//*[contains(text(),'Shows')]"));
			List<WebElement> listwe =wd.findElements(By.xpath("//*[contains(text(),'Shows')]"));
			Assert.assertTrue("Failed, Shows text is not present",listwe.size() > 0);
			//Assert.assertTrue("PASS, User Administration text is present",we.isDisplayed());
			action.moveToElement(we).build().perform();
			
			LOGGER.info("Validating Restaurant counts");
			totalcount1 = MystiqueGeneralAdministrationView.totalShowCategoryCalc();
				

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@When("^I create new Show Category$")
	public void createShowategory() throws InterruptedException {

		LOGGER.info("Clicking on create new show category button");
		Thread.sleep(3000);
		// new WebDriverWait(wd,
		// 60).until(ExpectedConditions.elementToBeClickable(By.id("layoutForm:dataTable:0:editButton")));
		wd.findElement(By.xpath("//*[@id='layoutForm:createShowCategoryDTOButton']"))
				.click();
		
		WebElement element = wd.findElement(By.xpath("//*[@id='layoutForm:name']"));
		WebElement element1 = wd.findElement(By.xpath("//*[@id='layoutForm:description']"));
		element.sendKeys("testname");
		element1.sendKeys("testdesc");
		
		
		executor.executeScript("arguments[0].click();",	wd.findElement(
				By.xpath("//*[@id='layoutForm:saveButton']"))); 
		Thread.sleep(5000);
		
		//*[@id="layoutForm:saveButton"]
	}

	@Then("^I should see total number of Show Category get increased$")
	public void chkTotalShowCategory() {
		LOGGER.info("Validating Changes and New counts");
		totalcount1 = MystiqueGeneralAdministrationView.totalShowCategoryCalc();
	}

	
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }
*/
}
