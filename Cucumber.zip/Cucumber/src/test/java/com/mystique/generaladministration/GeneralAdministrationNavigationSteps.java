package com.mystique.generaladministration;

import java.util.List;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.MystiqueDashboardContainer;
import com.mystique.utils.CommonUtils;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GeneralAdministrationNavigationSteps {
	private static final Logger LOGGER = Logger.getLogger(GeneralAdministrationNavigationSteps.class.getName());
	BrowserDriver bd = new BrowserDriver();
	private static final MystiqueDashboardContainer dashboardContainer = PageFactory
			.initElements(BrowserDriver.getCurrentDriver(),
					MystiqueDashboardContainer.class);
	static WebDriver wd=BrowserDriver.getCurrentDriver();
	static JavascriptExecutor executor = (JavascriptExecutor) wd; 
	static CommonUtils Util=new CommonUtils();
	
	 @Given("^I click on the Drop Down to Select Program$")
	  public void I_click_on_the_Drop_Down_to_Select_Program() {
		 SelectApplicationDropDown();
	  }

	 @When("^I try to select General Administration$")
	 public void I_try_to_select_General_Administration() {
		 ClickGenAdmin();
	 }
	 @Then("^I should see all General Administration options$")
	 public void I_should_see_General_Administration_Options() {
		Boolean isUserAdminDisplayed=wd.findElements(By.xpath("//*[contains(text(),'User Administration')]")).size()>0;
		Assert.assertNotEquals(wd.findElements(By.xpath("//*[contains(text(),'User Administration')]")).size(),0);
		if(isUserAdminDisplayed)
		{
		LOGGER.info("I am seeing General Administration options"); 
		
	 }
		else
		{
			LOGGER.info("I am unable to see General Administration options");	
		}
	 }


public static void SelectApplicationDropDown(){
	LOGGER.info("Selecting general Administration");
	 try {
		 Thread.sleep(5000);
		 Util.waitTimeElementVisibility(dashboardContainer.applicationSelectionDropDown);
		 executor.executeScript("arguments[0].click()", dashboardContainer.applicationSelectionDropDown);
		 int intTest = wd.findElements(By.xpath("//*[@id=\"layoutForm:applicationSelectMenu\"]/div[3]/span")).size();
		 Assert.assertTrue("Failed, Application Selection DropDown is not present",intTest > 0);
		 Assert.assertTrue("PASS, Application Selection DropDown is present",dashboardContainer.applicationSelectionDropDown.isDisplayed());
		// dashboardContainer.applicationSelectionDropDown.click();
		
		 Thread.sleep(5000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

public static void ClickGenAdmin(){
	LOGGER.info("Selecting general Administration");
	 try {
		 Thread.sleep(2000);
		 Util.waitTimeElementVisibility(dashboardContainer.generalAdminSelection);
		// List <WebElement> Test =  (List<WebElement>) dashboardContainer.generalAdminSelection;
		 int intTest = wd.findElements(By.xpath("//*[@data-label='General Administration']")).size();
		 
		 Assert.assertTrue("Failed, General Admin Selection text is not present",intTest > 0);
		 
		 dashboardContainer.generalAdminSelection.click();
		 Thread.sleep(5000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

/*public static void NavigateManageUser(){
	LOGGER.info("Selecting Manage Users");
	 try {
		 Thread.sleep(5000);
		 Actions action = new Actions(BrowserDriver.getCurrentDriver());
			WebElement we =BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:j_idt39']/ul/li[1]/a"));
			action.moveToElement(we).build().perform();
			Thread.sleep(5000);
			dashboardContainer.ManageUsers.click();
			Thread.sleep(5000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}*/
/*@After
public void tearDown(Scenario scenario) {

    if (scenario.isFailed()) {
        byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
        scenario.embed(screenshotBytes, "image/png");
    }

}*/


}