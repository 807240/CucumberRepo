package com.mystique.generaladministration;

import java.util.List;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.MystiqueDashboardContainer;
import com.mystique.utils.CommonUtils;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class UserAdministrationNavigationSteps {
	private static final Logger LOGGER = Logger.getLogger(UserAdministrationNavigationSteps.class.getName());
	BrowserDriver bd = new BrowserDriver();
	private static final MystiqueDashboardContainer dashboardContainer = PageFactory
			.initElements(BrowserDriver.getCurrentDriver(),
					MystiqueDashboardContainer.class);
	static WebDriver wd=BrowserDriver.getCurrentDriver();
	static CommonUtils Util=new CommonUtils();
	
	 @Given("^I click on the User Administration Drop Down$")
	  public void I_click_on_the_Drop_Down_to_Select_Program_and_Select_General_Administration() {
		  UserAdminDropDown();
	  }

	 @When("^I try to select Manage Users$")
	 public void I_try_to_select_Manage_Users() {
		 NavigateManageUser();
	 }
	 @Then("^I should see all Users$")
	 public void I_should_see_allUsers() {
		Boolean isUsersDisplayed=wd.findElements(By.xpath("//*[contains(text(),'Users Library')]")).size()>0;
		if(isUsersDisplayed)
		{
		LOGGER.info("I am seeing all Users"); 
	 }
		else
		{
			LOGGER.info("I am unable to see all Users");	
		}
	 }


public static void UserAdminDropDown(){
	
	try {
		Thread.sleep(5000);
		LOGGER.info("Selecting User Administration");

		Util.waitTimeElementVisibility(wd.findElement(By.xpath("//*[contains(text(),'User Administration')]")));
		Actions action = new Actions(wd);
		WebElement we =wd.findElement(By.xpath("//*[contains(text(),'User Administration')]"));
		List<WebElement> listwe =wd.findElements(By.xpath("//*[contains(text(),'User Administration')]"));
		Assert.assertTrue("Failed, User Administration text is not present",listwe.size() > 0);
		//Assert.assertTrue("PASS, User Administration text is present",we.isDisplayed());
		action.moveToElement(we).build().perform();
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

public static void NavigateManageUser(){
	LOGGER.info("Selecting Manage Users");
	 try {
		 Thread.sleep(10000);
		 int intTest = wd.findElements(By.xpath("//*[contains(text(),'Manage Users')]")).size();
		 Assert.assertTrue("Failed, Manage Users element is not present",intTest > 0);
		// Assert.assertTrue("PASS, Manage Users element is present",dashboardContainer.ManageUsers.isDisplayed());
		dashboardContainer.ManageUsers.click();
		Thread.sleep(10000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}
/*@After
public void tearDown(Scenario scenario) {

    if (scenario.isFailed()) {
        byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
        scenario.embed(screenshotBytes, "image/png");
    }

}*/


}