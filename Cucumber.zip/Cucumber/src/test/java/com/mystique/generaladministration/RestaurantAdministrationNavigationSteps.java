package com.mystique.generaladministration;

import java.util.List;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.MystiqueDashboardContainer;
import com.mystique.utils.CommonUtils;
import com.mystique.view.MystiqueGeneralAdministrationView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class RestaurantAdministrationNavigationSteps {
	private static final Logger LOGGER = Logger.getLogger(RestaurantAdministrationNavigationSteps.class.getName());
	BrowserDriver bd = new BrowserDriver();
	private static final MystiqueDashboardContainer dashboardContainer = PageFactory
			.initElements(BrowserDriver.getCurrentDriver(),
					MystiqueDashboardContainer.class);
	static WebDriver wd=BrowserDriver.getCurrentDriver();
	static CommonUtils Util=new CommonUtils();
	static Integer totalcount1;
	
	 @Given("^I click on the Restaurant Administration Drop Down$")
	  public void I_click_on_the_Drop_Down_to_Select_Program_and_Select_Property_Administration() {
		  RestaurantAdminDropDown();
	  }

	 @When("^I try to select Manage Restaurant$")
	 public void I_try_to_select_Manage_Properties() {
		 NavigateManageCuisineTypes();
	 }
	 @Then("^I should see all Restaurant$")
	 public void I_should_see_allProperty() {
		Boolean isPropertyDisplayed=wd.findElements(By.xpath("//*[contains(text(),'Restaurant Cuisine Type Library')]")).size()>0;
		totalcount1 = MystiqueGeneralAdministrationView.totalRestaurantCalc();
		
		if(isPropertyDisplayed)
		{
		LOGGER.info("I am seeing all Restaurant"); 
	 }
		else
		{
			LOGGER.info("I am unable to see all Restaurant");	
		}
	 }


public static void RestaurantAdminDropDown(){
	
	try {
		Thread.sleep(5000);
		LOGGER.info("Selecting Restaurant Administration");

		Util.waitTimeElementVisibility(wd.findElement(By.xpath("//*[contains(text(),'Restaurants')]")));
		Actions action = new Actions(wd);
		WebElement we =wd.findElement(By.xpath("//*[contains(text(),'Restaurants')]"));
		List<WebElement> listwe =wd.findElements(By.xpath("//*[contains(text(),'Restaurants')]"));
		Assert.assertTrue("Failed, Propery Administration text is not present",listwe.size() > 0);
		//Assert.assertTrue("PASS, User Administration text is present",we.isDisplayed());
		action.moveToElement(we).build().perform();
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

public static void NavigateManageCuisineTypes(){
	LOGGER.info("Selecting Manage Users");
	 try {
		 Thread.sleep(10000);
		 int intTest = wd.findElements(By.xpath("//*[contains(text(),'Manage Cuisine Types')]")).size();
		 Assert.assertTrue("Failed, Manage Users element is not present",intTest > 0);
		// Assert.assertTrue("PASS, Manage Users element is present",dashboardContainer.ManageUsers.isDisplayed());
		dashboardContainer.ManageCuisineTypes.click();
		Thread.sleep(10000);
	} catch (InterruptedException e) {

		e.printStackTrace();
	}
}

}