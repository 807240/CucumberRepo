package com.mystique.generaladministration;

import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.cucumber.listener.ExtentCucumberFormatter;
import com.mystique.application.BrowserDriver;
import com.mystique.utils.CommonUtils;
import com.mystique.view.MystiqueGeneralAdministrationView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserLibraryListSteps {

	private static final Logger LOGGER = Logger
			.getLogger(UserLibraryListSteps.class.getName());

	/*
	 * private static final MystiqueProgramContainer programContainer =
	 * PageFactory .initElements(BrowserDriver.getCurrentDriver(),
	 * MystiqueProgramContainer.class);
	 * 
	 * ValidateSearchByCustomerValue obj = new ValidateSearchByCustomerValue();
	 * 
	 * 
	 * 
	 * boolean validate;
	 */

	/*
	 * private static final MystiqueDashboardContainer dashboardContainer =
	 * PageFactory .initElements(BrowserDriver.getCurrentDriver(),
	 * MystiqueDashboardContainer.class);
	 */

	BrowserDriver bd = new BrowserDriver();
	static WebDriver wd = BrowserDriver.getCurrentDriver();
	static CommonUtils Util = new CommonUtils();
	JavascriptExecutor executor = (JavascriptExecutor) wd; 
	// MystiqueProgramContainer programContainer = new
	// MystiqueProgramContainer();

	// static String count=wd.findElement(By.xpath(
	// "//*[@id='layoutForm:dataTable_paginator_bottom']/span[1]")).getText();
	static Integer totalcount1;
	static Integer activecount1;
	static Integer inactivecount1;

	@Given("^I filter the users with status as Active$")
	public void filterActiveUsers() {

		try {
			totalcount1 = MystiqueGeneralAdministrationView.totalUserCalc();
			activecount1 = MystiqueGeneralAdministrationView.activeUserCalc();

			Thread.sleep(5000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	@When("^I filter the users with status as Inactive$")
	public void filterInactiveUsers() {

		inactivecount1 = MystiqueGeneralAdministrationView.inactiveUserCalc();
	}

	@Then("^I should see all Users as sum of Active Users and Inactive Users$")
	public void checkTotalUsers() {
		LOGGER.info("Validating Changes");

		ExtentCucumberFormatter.setTestRunnerOutput("Validating Counts");
		LOGGER.info(totalcount1 == activecount1 + inactivecount1 ? "Test Passed"
				: "Test Failed");
		try {
			Assert.assertTrue("Test Passed:Counts match ", totalcount1 == activecount1 + inactivecount1);
	    }
	    catch (AssertionError e) {
	        Assert.fail("Test Failed:Counts don't match " + e.getMessage());
	    }
		

	}

	@Given("^I change an User status from Active to Inactive$")
	public void userStatusActiveToInactive() { 

		try {
			Thread.sleep(3000);
			totalcount1 = MystiqueGeneralAdministrationView.totalUserCalc();
			Thread.sleep(3000);
			LOGGER.info("Count of Active Users before change");
			activecount1 = MystiqueGeneralAdministrationView.activeUserCalc();
			LOGGER.info("Changing User Status from Active to Inactive");
			Thread.sleep(3000);
			// new WebDriverWait(wd,
			// 60).until(ExpectedConditions.elementToBeClickable(By.id("layoutForm:dataTable:0:editButton")));
			//wd.findElement(By.xpath("(//*[contains(@id,':editButton')])[1]"))
			//		.click();
			executor.executeScript("arguments[0].click();", wd.findElement(By.xpath("(//*[contains(@id,':editButton')])[1]")));
			Util.waitTimeElementVisibility(wd.findElement(By
					.xpath("//*[@id='layoutForm:activeFlag']/div[2]")));
			Boolean ischkboxchkd = wd
					.findElements(
							By.xpath("//*[@id='layoutForm:activeFlag']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']"))
					.size() > 0;
			Thread.sleep(5000);
			if (ischkboxchkd) {
				wd.findElement(
						By.xpath("//*[@id='layoutForm:activeFlag']/div[2]"))
						.click();
				Thread.sleep(5000);
				/*wd.findElement(
						By.xpath("//*[@id='layoutForm:saveButton']"))
						.click();*/
				
				executor.executeScript("arguments[0].click();",	wd.findElement(
						By.xpath("//*[@id='layoutForm:saveButton']"))); 
				Thread.sleep(5000);
				/*wd.findElement(
						By.xpath("//*[@id='layoutForm:cancelButton']/span[2]"))
						.click();*/
				
				//executor.executeScript("arguments[0].click();",	wd.findElement(
					//	By.xpath("//*[@id='layoutForm:cancelButton']"))); 
				//Thread.sleep(15000);
			}
			Util.waitTimeElementVisibility(wd.findElement(By
					.id("layoutForm:dataTable:0:editButton")));
			LOGGER.info("Count of Active Users after change");
			// Thread.sleep(10000);
			activecount1 = MystiqueGeneralAdministrationView.activeUserCalc();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@When("^I filter the users with status as Active and Inactive$")
	public void userStatusInactive() {

		LOGGER.info("Count of Inactive Users after change");
		inactivecount1 = MystiqueGeneralAdministrationView.inactiveUserCalc();

	}

	@Then("^I should see all Users as sum of new Active Users and new Inactive Users$")
	public void chkTotalUsers() {
		LOGGER.info("Validating Changes and New counts");
		ExtentCucumberFormatter.setTestRunnerOutput("Validating Counts");
		try {
			Thread.sleep(5000);

		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info(totalcount1 == activecount1 + inactivecount1 ? "Test Passed"
				: "Test Failed");
		try {
			Assert.assertTrue("Test Passed:Counts match ", totalcount1 == activecount1 + inactivecount1);
	    }
	    catch (AssertionError e) {
	        Assert.fail("Test Failed:Counts don't match " + e.getMessage());
	    }
	}

	@Given("^I change an User status from Inactive to Active$")
	public void userStatusInactiveToActive() {
		try {
			Thread.sleep(3000);
			totalcount1 = MystiqueGeneralAdministrationView.totalUserCalc();
			Thread.sleep(3000);
			LOGGER.info("Count of Inactive Users before change");
			inactivecount1 = MystiqueGeneralAdministrationView
					.inactiveUserCalc();
			LOGGER.info("Changing User Status from Inactive to Active");
			Thread.sleep(3000);
			// new WebDriverWait(wd,
			// 60).until(ExpectedConditions.elementToBeClickable(By.id("layoutForm:dataTable:0:editButton")));
			wd.findElement(By.xpath("(//*[contains(@id,':editButton')])[1]"))
					.click();
			Util.waitTimeElementVisibility(wd.findElement(By
					.xpath("//*[@id='layoutForm:activeFlag']/div[2]")));
			Boolean ischkboxchkd = wd
					.findElements(
							By.xpath("//*[@id='layoutForm:activeFlag']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']"))
					.size() > 0;
			if (!ischkboxchkd) {
				wd.findElement(
						By.xpath("//*[@id='layoutForm:activeFlag']/div[2]"))
						.click();
				executor.executeScript("arguments[0].click();", wd.findElement(By.xpath("//*[@id='layoutForm:activeFlag']/div[2]")));
				Thread.sleep(5000);
				/*wd.findElement(
						By.xpath("//*[@id='layoutForm:saveButton']/span[2]"))
						.click();*/
				executor.executeScript("arguments[0].click();",	wd.findElement(
						By.xpath("//*[@id='layoutForm:saveButton']"))); 
				
				Thread.sleep(3000);
				/*wd.findElement(
						By.xpath("//*[@id='layoutForm:cancelButton']/span[2]"))
						.click();*/
				
				//executor.executeScript("arguments[0].click();",	wd.findElement(
					//	By.xpath("//*[@id='layoutForm:cancelButton']"))); 

				//Thread.sleep(15000);
			}
			Util.waitTimeElementVisibility(wd.findElement(By
					.id("layoutForm:dataTable:0:editButton")));
			LOGGER.info("Count of Inactive Users after change");
			inactivecount1 = MystiqueGeneralAdministrationView
					.inactiveUserCalc();

		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

	@When("^I filter the users with status as Inactive and Active$")
	public void userStatusActive() {

		LOGGER.info("Count of Inactive Users after change");
		activecount1 = MystiqueGeneralAdministrationView.activeUserCalc();

	}

	@Then("^I should see all Users as sum of Active Users and new Inactive Users$")
	public void CheckTotalUsers() {
		LOGGER.info("Validating Changes and New counts");
		ExtentCucumberFormatter.setTestRunnerOutput("Validating Counts");
		try {
			Thread.sleep(5000);

		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		LOGGER.info(totalcount1 == activecount1 + inactivecount1 ? "Test Passed"
				: "Test Failed");
		try {
			Assert.assertTrue("Test Passed:Counts match ", totalcount1 == activecount1 + inactivecount1);
	    }
	    catch (AssertionError e) {
	        Assert.fail("Test Failed:Counts don't match " + e.getMessage());
	    }
}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }
*/
}
