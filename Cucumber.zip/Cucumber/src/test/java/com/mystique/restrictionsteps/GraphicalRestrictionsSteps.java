package com.mystique.restrictionsteps;

import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueRestrictionsView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GraphicalRestrictionsSteps {
	private static final Logger LOGGER = Logger
			.getLogger(GraphicalRestrictionsSteps.class.getName());
	BrowserDriver bd = new BrowserDriver();
	static WebDriver wd = BrowserDriver.getCurrentDriver();

	@Given("^I click on View Restrictions tab$")
	public void I_click_on_View_Restrictions_tab() {
		MystiqueRestrictionsView.hoverOnRestrictionsTab();
		MystiqueRestrictionsView.selectViewRestrictions();
	}

	@When("^I set a date range and select channels$")
	public void I_select_date_range(){ 	
		MystiqueRestrictionsView.selectDateRange();
		MystiqueRestrictionsView.selectALLChannels();
		MystiqueRestrictionsView.selectALLPrograms();
		MystiqueRestrictionsView.ClickSearchButton();
		LOGGER.info("Clicked on the Search button");
	}

	@Then("^I should be able to view the restrictions for those days$")
	public void I_should_be_able_to_see_restrictions() {
		//int isnorestriction=wd.findElements(By.className("norestrictiontext")).size();
		int isnorestriction=wd.findElements(By.className("fn-gantt")).size();
		System.out.println("Size if gantt : "+isnorestriction);
		Assert.assertNotEquals(isnorestriction,0);
		if(isnorestriction>0)
		{
			LOGGER.info("Restrictions are shown on the graph,PASS");
		}
		else
			LOGGER.info("Restrictions are not shown on the graph,FAIL");
		
	
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) bd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }
*/

}
