package com.mystique.restrictionsteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueRestrictionsView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ManageRestrictionsSteps {
	private static final Logger LOGGER = Logger
			.getLogger(ManageRestrictionsSteps.class.getName());
	BrowserDriver bd = new BrowserDriver();
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	@Given("^I click on Manage Restrictions tab to View$")
	public void I_click_on_Manage_Restrictions_tab_to_View() {
		MystiqueRestrictionsView.hoverOnRestrictionsTab();
		MystiqueRestrictionsView.selectManageRestrictions();
	}

	@When("^I Edit Restrictions calendar by selecting Travel Window$")
	public void I_Edit_Restrictions_calendar_by_selecting_Travel_Window(){ 	
		MystiqueRestrictionsView.viewRestrictionsByTravelWindow();
		MystiqueRestrictionsView.editRestrictionsByTravelWindow();
		MystiqueRestrictionsView.editingComments();
		MystiqueRestrictionsView.reviewEditedRestrictions();
		MystiqueRestrictionsView.saveReviewedRestrictions();
		LOGGER.info("I Review and then Save the Edited Restrictions");
	}

	@Then("^I Review and then Save the Edited Restrictions$")
	public void I_Review_and_then_Save_the_Edited_Restrictions() {
		MystiqueRestrictionsView.hoverOnRestrictionsTab();	
		MystiqueRestrictionsView.selectSearchRestrictions();
		MystiqueRestrictionsView.addRestrictionDate();
		MystiqueRestrictionsView.houseRestrictionsCheck(); 
		MystiqueRestrictionsView.clickOnSearch();
	
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/


}
