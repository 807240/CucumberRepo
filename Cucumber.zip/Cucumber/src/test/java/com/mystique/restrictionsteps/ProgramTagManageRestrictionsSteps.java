package com.mystique.restrictionsteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueRestrictionsView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class ProgramTagManageRestrictionsSteps {
	private static final Logger LOGGER = Logger.getLogger(ProgramTagManageRestrictionsSteps.class.getName());
	BrowserDriver bd = new BrowserDriver();
	static WebDriver wd=BrowserDriver.getCurrentDriver();
	
	 @Given("^I click on Manage Restrictions tab to View Program Tags$")
	  public void I_click_on_Manage_Restrictions_tab_to_View_Program_Tags() {
		  MystiqueRestrictionsView.hoverOnRestrictionsTab();
		  MystiqueRestrictionsView.selectManageRestrictions();
		
	  }

	 @When("^I select Program Tags in Program Window$")
	 public void I_select_Program_Tags_in_Program_Window() {
		MystiqueRestrictionsView.programTagInputManage();
		MystiqueRestrictionsView.hoverOnRestrictionsTab();	
		MystiqueRestrictionsView.selectSearchRestrictions();
		MystiqueRestrictionsView.programTagInputSearch();
	 }
	 @Then("^I select tabs and review Restrictions$")
	 public void I_select_tabs_and_review_Restrictions() {
		LOGGER.info("I am seeing same Program list in manage and search page!"); 
	 }
	/* @After
	    public void tearDown(Scenario scenario) {

	        if (scenario.isFailed()) {
	            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
	            scenario.embed(screenshotBytes, "image/png");
	        }

	    }*/

}
