package com.mystique.restrictionsteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueDashboardView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class PropertyNavigationSteps {
	private static final Logger LOGGER = Logger.getLogger(PropertyNavigationSteps.class.getName());
	BrowserDriver bd = new BrowserDriver();
	static WebDriver wd=BrowserDriver.getCurrentDriver();
	
	 @Given("^I click on the Property Down$")
	  public void I_click_on_the_Property_Down() {
		 MystiqueDashboardView.selectPropertyDropDown();
	  }

	 @When("^I try to select ARIA$")
	 public void I_try_to_select_ARIA() {
		 MystiqueDashboardView.selectARIAfromDropDown();
	 }
	 
	 @Then("^I should see that i see ARIA related info$")
	 public void I_should_see_that_i_see_ARIA_related_info() {
		LOGGER.info("I am seeing ARIA related Info"); 
	 }
	 /*@After
	    public void tearDown(Scenario scenario) {

	        if (scenario.isFailed()) {
	            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
	            scenario.embed(screenshotBytes, "image/png");
	        }

	    }*/

}
