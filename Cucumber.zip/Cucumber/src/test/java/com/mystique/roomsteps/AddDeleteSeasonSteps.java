package com.mystique.roomsteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueRoomView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddDeleteSeasonSteps {

	private static final Logger LOGGER = Logger.getLogger(AddDeleteSeasonSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	@Given("^I provide data for first Season and click Add Spread button$")
	public void I_provide_data_for_first_Season_and_click_Add_Spread_button() {
		MystiqueRoomView.filterRoom();
		MystiqueRoomView.clickOnEditLink();
		MystiqueRoomView.clickNextOnRoomConfigPage();
		MystiqueRoomView.addAnotherDefaultRateSpread();
		MystiqueRoomView.addSeasonProvideData();
		MystiqueRoomView.clickSaveRoomButton();
		MystiqueRoomView.popUpAlertAcceptMessage();
		
		LOGGER.info("I provide data for first Season and click Add Spread button");  
	}

	@When("^I provide valid data for Added Season and click on save button$")
	public void I_provide_valid_data_for_Added_Season_and_click_on_save_button() {
		//MystiqueRoomView.deleteSeason();
		MystiqueRoomView.deleteSeason1();
		MystiqueRoomView.clickSaveRoomButton();
		
	}

	@Then("^I Delete added Season and click on Save button$")
	public void I_Delete_added_Season_and_click_on_Save_button() {
		//MystiqueRoomView.saveAfterDeleteData();
		//MystiqueRoomView.clickSaveRoomButton();
		//MystiqueRoomView.popUpAlertAccept();
		LOGGER.info("I Delete added Season and click on Save button"); 
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/

}
