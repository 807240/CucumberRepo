package com.mystique.roomsteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueRoomView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RoomSyncSteps {
	private static final Logger LOGGER = Logger.getLogger(RoomSyncSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	@Given("^I can see the Room listing page$")
	public void I_can_see_the_Room_listing_page() {
		MystiqueRoomView.selectRoomTab();
	}

	@When("^I click on Room Sync link$")
	public void I_click_on_Room_Sync_link() {
		MystiqueRoomView.roomSync();
	}

	@Then("^I should see the SuccessOrError growl message$")
	public void I_should_see_the_SuccessOrError_growl_message() {
		LOGGER.info("I should see Error or Success growl message");
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/


}
