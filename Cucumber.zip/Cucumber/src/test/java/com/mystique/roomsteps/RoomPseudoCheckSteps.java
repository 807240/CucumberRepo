package com.mystique.roomsteps;

import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueRoomView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RoomPseudoCheckSteps {

	private static final Logger LOGGER = Logger.getLogger(RoomPseudoCheckSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	//Check
	@Given("^I Check the Pseudo checkbox for a room and save it$")
	public void i_check_the_Pseudo_checkbox_for_a_room_and_save_it() {
		MystiqueRoomView.filterRoom();
		MystiqueRoomView.checkThePseudoBox();
	}

	@When("^I open the room feature again$")
	public void i_open_the_room_feature_again() {
		MystiqueRoomView.filterRoom();
		MystiqueRoomView.openRoomFeature();
	}

	@Then("^I should see the pseudo feature checked$")
	public void i_should_see_the_pseudo_feature_checked() {
		LOGGER.info("Validating Changes");

		WebDriver wd = BrowserDriver.getCurrentDriver();
		boolean isPseudoChkd = wd.findElements(By.xpath("//*[@id='layoutForm:pseudo']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size()>0;
		if (isPseudoChkd) {
			LOGGER.info("Sudo Test Passed - CHECK");
			wd.navigate().back();
			try {
				Thread.sleep(5000);
				new WebDriverWait(wd, 60).until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(@id,':editButton')])[1]")));
				//Assert.assertTrue("PASS, Confirm Dialog is present",wd.findElements(By.xpath("//*[contains(@id,':editButton')])[1]")).isDisplayed());
				int intTest = wd.findElements(By.xpath("(//*[contains(@id,':editButton')])[1]")).size();
				Assert.assertTrue("Failed, Edit button is not present",intTest > 0);
				
				//Assert.assertTrue("PASS, Edit button is present",((WebElement) wd.findElements(By.xpath("(//*[contains(@id,':editButton')])[1]"))).isDisplayed());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		} else {
			LOGGER.info("Sudo Test Failed - CHECK");
			wd.navigate().back();
			try {
				Thread.sleep(5000);
				new WebDriverWait(wd, 60).until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(@id,':editButton')])[1]")));
				int intTest = wd.findElements(By.xpath("(//*[contains(@id,':editButton')])[1]")).size();
				Assert.assertTrue("Failed, Edit button is not present",intTest > 0);
				
				//Assert.assertTrue("PASS, Edit button is present",((WebElement) wd.findElements(By.xpath("(//*[contains(@id,':editButton')])[1]"))).isDisplayed());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}


	//Uncheck
	@Given("^I UnCheck the Pseudo checkbox for a room and save it$")
	public void i_unCheck_the_Pseudo_checkbox_for_a_room_and_save_it() {
		MystiqueRoomView.filterRoom();
		MystiqueRoomView.unCheckThePseudoBox();

	}

	@When("^I open the room feature again Off$")
	public void i_open_the_room_feature_again_Off() {
		MystiqueRoomView.filterRoom();
		MystiqueRoomView.openRoomFeature();
	}

	@Then("^I should see the pseudo feature unchecked$")
	public void i_should_see_the_pseudo_feature_unchecked() {
		LOGGER.info("Validating Changes");

		WebDriver wd= BrowserDriver.getCurrentDriver();
		boolean isPseudoChkd = wd.findElements(By.xpath("//*[@id='layoutForm:pseudo']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size()>0;
		if (isPseudoChkd) {
			LOGGER.info("Sudo Test Failed - UNCHECK");
			wd.navigate().back();
			try {
				Thread.sleep(5000);
				new WebDriverWait(wd, 60).until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(@id,':editButton')])[1]")));
				int intTest = wd.findElements(By.xpath("(//*[contains(@id,':editButton')])[1]")).size();
				Assert.assertTrue("Failed, Edit button is not present",intTest > 0);
				
				//Assert.assertTrue("PASS, Edit button is present",((WebElement) wd.findElements(By.xpath("(//*[contains(@id,':editButton')])[1]"))).isDisplayed());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		} else {
			LOGGER.info("Sudo Test Passed - UNCHECK");
			wd.navigate().back();
			try {
				Thread.sleep(5000);
				new WebDriverWait(wd, 60).until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(@id,':editButton')])[1]")));
				int intTest = wd.findElements(By.xpath("(//*[contains(@id,':editButton')])[1]")).size();
				Assert.assertTrue("Failed, Edit button is not present",intTest > 0);
				
				//Assert.assertTrue("PASS, Edit button is present",((WebElement) wd.findElements(By.xpath("(//*[contains(@id,':editButton')])[1]"))).isDisplayed());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/


}
