package com.mystique.roomsteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueDashboardView;
import com.mystique.view.MystiqueRoomView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class RoomNavigationSteps {
	
	private static final Logger LOGGER = Logger.getLogger(RoomNavigationSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	@Given("^I click on the property drop down$")
	public void i_click_on_the_property_drop_down() {
		MystiqueDashboardView.selectPropertyDropDown();
	}

	@When("^I try to select ARIA property$")
	public void i_try_to_select_ARIA_property() {
		MystiqueDashboardView.selectARIAfromDropDown();
	}

	@Then("^I should select manage room tab$")
	public void i_should_select_manage_room_tab() {
		LOGGER.info("Room Tab selected");
		MystiqueRoomView.selectRoomTab();
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/


}
