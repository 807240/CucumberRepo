package com.mystique.roomsteps;

import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.MystiqueRoomContainer;
import com.mystique.utils.CommonUtils;
import com.mystique.view.MystiqueDashboardView;
import com.mystique.view.MystiqueRoomView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RoomDualPropertyMasterSecondaryMapping {

	private static final Logger LOGGER = Logger.getLogger(RoomDualPropertyMasterSecondaryMapping.class.getName());
	private static final MystiqueRoomContainer roomContainer = PageFactory.initElements(BrowserDriver.getCurrentDriver(), MystiqueRoomContainer.class);
	
	WebDriver wd = BrowserDriver.getCurrentDriver();
	public static String room_name="";
	static CommonUtils Util=new CommonUtils();
	
	
	//Change Room Status to Active
	@Given("^The room status is Disabled and Association type is NONE$")
	public void room_status_is_disabled_association_none() {
	
		MystiqueDashboardView.selectPropertyDropDown();
		MystiqueDashboardView.selectDellanofromDropDown();
		MystiqueRoomView.selectRoomTab();
		MystiqueRoomView.filterRoomByStatusAndAssociationType();
		MystiqueRoomView.clickOnEditLink();
	}

	
	@When("^I change the Room Status to Active$")
	public void change_status_to_active() {
		MystiqueRoomView.ChangeRoomStatusActive();
		
	}

	@Then("^I should see the first warning message$")
	public void i_should_see_the_first_warning_message() {
		LOGGER.info("Validating Wrning Message");

		
		boolean isfrstwarning = wd.findElements(By.xpath("//*[@id='layoutForm:confirmDialogVal']/div[1]/span")).size()>0;
		if (isfrstwarning) {
			LOGGER.info("First Warning Message is displayed-PASS");
			
		} else {
			LOGGER.info("First Warning Message is not displayed-FAIL");
			
		}
		
		try {
			Thread.sleep(3000);
			int intTest = wd.findElements(By.xpath("//*[@id='layoutForm:noButton']/span")).size();
			Assert.assertTrue("Failed, No button is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, No button is present",wd.findElement(By.xpath("//*[@id='layoutForm:noButton']/span")).isDisplayed());
			wd.findElement(By.xpath("//*[@id='layoutForm:noButton']/span")).click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
	}


	//Change Room Status to Inactive
		@When("^I change the Room Status to Inactive$")
		public void change_status_to_Inactive() {
			MystiqueRoomView.ChangeRoomStatusInactive();
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			
		}
		
		
	//Second Warning message for Status change to Active
		@When("^I change the Room Status to Active and save the default spread$")
		public void change_status_to_Active_and_save_rate_spread() {
			MystiqueRoomView.ChangeRoomStatusActive();
			wd.findElement(By.xpath("//*[@id='layoutForm:yesButton']/span")).click();
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			MystiqueRoomView.ClickNextRoomEdit();
			try {
				Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
			
		MystiqueRoomView.clickSaveRoomButton();
			
		}
		
		
		@When("^I change the Room Status to Inactive and save the default spread$")
		public void change_status_to_Inactive_and_save_rate_spread() {
			MystiqueRoomView.ChangeRoomStatusInactive();
			wd.findElement(By.xpath("//*[@id='layoutForm:yesButton']/span")).click();
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			MystiqueRoomView.ClickNextRoomEdit();
			try {
				Thread.sleep(10000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
			
		MystiqueRoomView.clickSaveRoomButton();
			
		}
		
		
		@Then("^I should see the second warning message$")
		public void i_should_see_the_second_warning_message() {
			LOGGER.info("Validating Warning Message");

			
			boolean isscndwarning = wd.findElements(By.xpath("//*[@id='layoutForm:reconfirmDialogVal']/div[2]")).size()>0;
			if (isscndwarning) {
				LOGGER.info("Second Warning Message is displayed-PASS");
				
			} else {
				LOGGER.info("Second Warning Message is not displayed-FAIL");
				
			}
			try {
				Thread.sleep(3000);
				int intTest = wd.findElements(By.xpath("//*[@id='layoutForm:renoButton']/span")).size();
				Assert.assertTrue("Failed, Reno button is not present",intTest > 0);
				
				//Assert.assertTrue("PASS, Reno button is present",wd.findElement(By.xpath("//*[@id='layoutForm:renoButton']/span")).isDisplayed());
				wd.findElement(By.xpath("//*[@id='layoutForm:renoButton']/span")).click();
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			
		}
	
		@When("^I save the room as Active$")
		public void save_room_as_active() {
			
			try {
				change_status_to_Active_and_save_rate_spread();
				int intTest = wd.findElements(By.xpath("//*[@id='layoutForm:reyesButton']/span")).size();
				Assert.assertTrue("Failed, Reyes Button is not present",intTest > 0);
				
				//Assert.assertTrue("PASS, Reyes Button is present",wd.findElement(By.xpath("//*[@id='layoutForm:reyesButton']/span")).isDisplayed());
				wd.findElement(By.xpath("//*[@id='layoutForm:reyesButton']/span")).click();
				Thread.sleep(10000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
		}
		
		@When("^I save the room as Inactive$")
		public void save_room_as_Inactive() {
			
			try {
				change_status_to_Inactive_and_save_rate_spread();
				wd.findElement(By.xpath("//*[@id='layoutForm:reyesButton']/span")).click();
				Util.waitTimeElementVisibility(roomContainer.clickAlertBox);
				int intTest = wd.findElements(By.id("layoutForm:yesButton")).size();
				Assert.assertTrue("Failed, Alert Box is not present",intTest > 0);
				
				//Assert.assertTrue("PASS, Alert Box is present", roomContainer.clickAlertBox.isDisplayed());
				roomContainer.clickAlertBox.click();
				Thread.sleep(10000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
		}
		
		@Then("^I should see the room in the native property is tagged as Secondary$")
		public void i_should_see_the_room_as_secondary() {
			Util.waitTimeElementVisibility(roomContainer.filterRoomInput);
			roomContainer.filterRoomInput.sendKeys(room_name);
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			Assert.assertEquals(wd.findElement(By.xpath("//*[@id='layoutForm:dataTable_data']/tr[1]/td[4]")).getText(),"SECONDARY");
			if(wd.findElement(By.xpath("//*[@id='layoutForm:dataTable_data']/tr[1]/td[4]")).getText()=="SECONDARY")
			{
				LOGGER.info("Native room is saved as Secondary-PASS");
				
			} else {
				LOGGER.info("Native room is not saved as Secondary-FAIL");
			}
		}
		
		
		@Then("^I should see the room in the sharing property is tagged as Master$")
		public void i_should_see_the_room_as_master_shared_property() {
			MystiqueDashboardView.selectPropertyDropDown();
			MystiqueDashboardView.selectMBfromDropDown();
			MystiqueRoomView.selectRoomTab();
			Util.waitTimeElementVisibility(roomContainer.filterRoomInput);
			roomContainer.filterRoomInput.sendKeys(room_name);
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			Assert.assertEquals(wd.findElement(By.xpath("//*[@id='layoutForm:dataTable_data']/tr[1]/td[4]")).getText(),"MASTER");
			if(wd.findElement(By.xpath("//*[@id='layoutForm:dataTable_data']/tr[1]/td[4]")).getText()=="MASTER")
			{
				LOGGER.info("Native room is saved as Secondary-PASS");
				
			} else {
				LOGGER.info("Native room is not saved as Secondary-FAIL");
			}
			

		}
		/*@After
	    public void tearDown(Scenario scenario) {

	        if (scenario.isFailed()) {
	            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
	            scenario.embed(screenshotBytes, "image/png");
	        }

	    }*/
}
