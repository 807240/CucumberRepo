package com.mystique.roomsteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueRoomView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EditRoomInfoSteps {

	private static final Logger LOGGER = Logger.getLogger(EditRoomInfoSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	@Given("^I filter room and hover on the edit link$")
	public void i_filter_room_and_hover_on_the_edit_Link() {
		MystiqueRoomView.filterRoom();
	}

	@When("^I try to click on edit link$")
	public void i_try_to_click_on_edit_link() {
		MystiqueRoomView.clickOnEditLink();
		MystiqueRoomView.clickOnActiveFlag();
		MystiqueRoomView.shortDescriptionMandatoryClear();
		MystiqueRoomView.clickNextOnRoomConfigPage();
		//MystiqueRoomView.popUpAlertAcceptMessage();
		//MystiqueRoomView.shortDescriptionMandatory();
		//MystiqueRoomView.longDescriptionMandatoryClear();
		//MystiqueRoomView.clickNextOnRoomConfigPage();
		//MystiqueRoomView.popUpAlertAcceptMessage();
		//MystiqueRoomView.longDescriptionMandatory();
		//MystiqueRoomView.agentSendToCustomerTextClear();
		//MystiqueRoomView.clickNextOnRoomConfigPage();
		//MystiqueRoomView.popUpAlertAcceptMessage();
		//MystiqueRoomView.agentSendToCustomerTextMandatory();
		//MystiqueRoomView.selectRoomTabAfterDeletion();
		//MystiqueRoomView.shortDescriptionMandatory();
		//MystiqueRoomView.populateRoomData();
		//MystiqueRoomView.clickNextOnRoomConfigPage();
		
	}

	@Then("^I should see the Room configuration page$")
	public void i_should_see_the_Room_configuration_Page() {
		//MystiqueRoomView.checkIFSeasonExists();
		//MystiqueRoomView.addSpread();
		
		//MystiqueRoomView.addDefaultRateSpread();
		//MystiqueRoomView.daysWithoutDayCoverage();
		MystiqueRoomView.clickSaveRoomButton();
		//MystiqueRoomView.popUpAlertDismiss();
		
		//MystiqueRoomView.amountValidation();
		//MystiqueRoomView.clickSaveRoomButton();
		//MystiqueRoomView.popUpAlertAcceptMessage();

		//MystiqueRoomView.dateRangeWithoutDayCoverage();
		//MystiqueRoomView.clickSaveRoomButton();
		//MystiqueRoomView.popUpAlertDismiss();
		
		//MystiqueRoomView.defaultRateSpreadData();
		//MystiqueRoomView.clickSubmitButton();
		
		LOGGER.info("I am seeing the Room Configuration for the room selected"); 
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/


}
