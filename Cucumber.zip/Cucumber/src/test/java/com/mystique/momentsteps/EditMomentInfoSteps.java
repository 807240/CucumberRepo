package com.mystique.momentsteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueComponentView;
import com.mystique.view.MystiqueMomentView;
import com.mystique.view.MystiqueRoomView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EditMomentInfoSteps {

	private static final Logger LOGGER = Logger.getLogger(EditMomentInfoSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	@Given("^I hover on the edit link and click on edit$")
	public void i_hover_on_the_edit_link_and_click_on_edit() {
		LOGGER.info("I am able to see the moment list page."); 
	}

	@When("^I edit the details of a moment$")
	public void i_edit_the_details_of_a_moment() {
		MystiqueMomentView.clickOnEditLink();
		
		MystiqueMomentView.clickOnEnableBestOffer();
		MystiqueMomentView.populateBookingWindow();
		MystiqueMomentView.populateCorporatesortorder();
		MystiqueMomentView.populateExecutionProcess();
		
	}

	@Then("^I should see the Moment list page after save$")
	public void i_should_see_the_moment_list_page_after_save() {
		MystiqueMomentView.clickSaveMomentButton();
		LOGGER.info("I am able to save the Component Configuration the selected one"); 
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/

}
