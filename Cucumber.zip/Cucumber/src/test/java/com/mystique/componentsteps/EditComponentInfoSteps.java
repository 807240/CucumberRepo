package com.mystique.componentsteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueComponentView;
import com.mystique.view.MystiqueRoomView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EditComponentInfoSteps {

	private static final Logger LOGGER = Logger.getLogger(EditComponentInfoSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	@Given("^I filter components and hover on the edit link$")
	public void i_filter_components_and_hover_on_the_edit_link() {
		MystiqueComponentView.filterComponent();
	}

	@When("^I try to click on edit link$")
	public void i_try_to_click_on_edit_link() {
		MystiqueComponentView.clickOnEditLink();
//		MystiqueComponentView.clickOnActiveFlag();
		MystiqueComponentView.populateLearnMoreDescription();
		MystiqueComponentView.populateShortDescription();
		MystiqueComponentView.clickOnAvailableIce();
		
	}

	@Then("^I should see the Component configuration page$")
	public void i_should_see_the_component_configuration_page() {
		MystiqueComponentView.clickSaveComponentButton();
		LOGGER.info("I am able to save the Component Configuration the selected one"); 
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
        }

    }*/

}
