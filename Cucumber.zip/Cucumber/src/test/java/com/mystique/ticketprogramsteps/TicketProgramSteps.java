package com.mystique.ticketprogramsteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueProgramView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TicketProgramSteps {
	private static final Logger LOGGER = Logger.getLogger(TicketProgramSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();
	
	
	// Create New Manage Ticket Program
	 @Given("^I click on the Manage Ticket Programs tab to provide data")
	  public void I_click_on_the_Manage_Ticket_Programs_tab_to_provide_data() {
		    MystiqueProgramView.clickManageTicketProgram();
			MystiqueProgramView.createNewTicketProgram();
			
	  }

	 @When("^I provide Invalid and then Valid data to create new ticket Program")
	 public void I_provide_Invalid_and_then_Valid_data_to_create_new_ticket_Program() {
		    MystiqueProgramView.provideTicketProgramValue();
	    	MystiqueProgramView.provideTicketProgramTag();
	    	MystiqueProgramView.ticketDescriptionMandatory();
	    	MystiqueProgramView.selectTicketSeasonType();
	    	MystiqueProgramView.selectTicketbookingStartDate();
	    	MystiqueProgramView.selectTicketbookingEndtDate();
	    	MystiqueProgramView.performanceStartDateInRestriction();
	    	MystiqueProgramView.performanceEndtDateInRestriction();
	 }
	 
	 @Then("^I complete providing data and click Save to save new ticket Program")
	 public void I_complete_providing_data_and_click_Save_to_save_new_ticket_Program() {
		    MystiqueProgramView.saveNewProgram();
		    LOGGER.info("I complete providing data and click Save to save new ticket Program"); 
	 }
	 
	 
	 // Edit Manage Ticket Program
	 
	 @Given("^I click on the edit  manage ticket Program link to provide data$")
	  public void I_click_on_the_edit_manage_ticket_Program_link_to_provide_data() {
			MystiqueProgramView.hoverOnProgramTab();
			MystiqueProgramView.clickManageTicketProgram();
			MystiqueProgramView.editManageTicketProgramLink();
	  }

	 @When("^I provide Invalid and then Valid data to edit manage ticket Program$")
	 public void I_provide_Invalid_and_then_Valid_data_to_edit_manage_ticket_Program() {
		    MystiqueProgramView.provideTicketProgramValueEdit();	
	 }
	 
	 @Then("^I complete providing data and Save edited manage ticket Program$")
	 public void I_complete_providing_data_and_Save_edited_manage_ticket_Program() {
			MystiqueProgramView.saveNewProgram();
		    LOGGER.info("I complete providing data and Save edited Program"); 
	 }
	 /*@After
	    public void tearDown(Scenario scenario) {

	        if (scenario.isFailed()) {
	            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
	            scenario.embed(screenshotBytes, "image/png");
	        }

	    }*/

}
