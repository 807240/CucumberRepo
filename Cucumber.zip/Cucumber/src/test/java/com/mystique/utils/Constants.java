package com.mystique.utils;


public interface Constants {

	String MYSTIQUE_SERVER_URL ="mystique.server.url";
	String MYSTIQUE_LOGIN_USER_ID ="mystique.login.user.id";
	String MYSTIQUE_LOGIN_PASSWORD ="mystique.login.password";
	//String FIREFOX_PATH = "C:\\Program Files\\Mozilla Firefox\\firefox";
	//String FIREFOX_PATH = "C:\\Program Files (x86)\\Mozilla Firefox\\firefox";
	String FIREFOX_PATH = "D:\\Development_Avecto\\mozilla firefox\\firefox";
	String ACCESS_OTHER = "http://10.255.151.142:8080/mystique/login.xhtml";

	//String CHANNEL_PATH = "properties/channel.properties";
	String CHANNEL_PATH = "channel.properties";
	String COMMON_PATH = "properties/common.properties";
	String RESTRICTION_PATH = "restriction.properties";
	String TICKET_PROGRAM = "ticketProgram.properties";
	String ROOM_PROGRAM = "roomProgram.properties";
	String ROOM_PATH = "room.properties";
	String RATE_PATH = "rate.properties";
	String COMPONENT_PATH = "component.properties";
	String MOMENT_PATH = "moment.properties";

	//MASTER DATA KEY STARTED
	String COMMON_OPERA_RATE_CATEGORY_COMP = "common.operaRateCategory.comp";
	String COMMON_OPERA_RATE_CATEGORY_CASH = "common.operaRateCategory.cash";
	String COMMON_MARKET_CODE_CTGX = "common.marketCode.ctgx";
	String COMMON_MARKET_CODE_CSLP = "common.marketCode.cslp";
	String COMMON_PACKAGE_COMPONENT = "common.package.component";
	
	//ROOM KEY STARTED
	String FILTER_ROOM_NAME = "room.typeFilter";
	String ROOM_SHORT_DESCRIPTION = "room.shortDescription";
	String ROOM_LONG_DESCRIPTION = "room.longDescription";
	String ROOM_RATE_FLOOR = "room.rateFloor";
	String ROOM_RATE_CEILING = "room.rateCeiling"; 
	String ROOM_EXTRA_GUEST_CHARGE = "room.extraGuestCharge"; 
	String ROOM_EXTRA_GUEST_CHARGE_THRESHOLD = "room.extraGuestChangeThreshold"; 
	String ROOM_RESORT_FEE = "room.resortFee";
	String ROOM_SEASON_START_DATE_0 = "room.seasonStartDate0";
	String ROOM_SEASON_START_DATE_1 = "room.seasonStartDate1";
	String ROOM_SEASON_END_DATE_0 = "room.seasonEndDate0";
	String ROOM_SEASON_END_DATE_1 = "room.seasonEndDate1";
	String ROOM_AMOUNT_VALUE_0 = "room.amountValue0"; 
	String ROOM_PERCENT_VALUE_0 = "room.percentValue0"; 
	String ROOM_PERCENT_VALUE_1 = "room.percentValue1"; 
	
	//COMPONENT KEY
	String FILTER_COMPONENT_NAME = "component.nameFilter";
	
	//RATE TABLE KEY STARTED
	String RATE_TABLE_CREATE_FROM_DATE = "rateTable.create.fromDate";
	String RATE_TABLE_CREATE_TO_DATE = "rateTable.create.toDate";
	String RATE_TABLE_EDIT_FROM_DATE = "rateTable.edit.fromDate";
	String RATE_TABLE_EDIT_TO_DATE = "rateTable.edit.toDate";
	String RATE_TABLE_CREATE_DESCRIPTION = "rateTable.create.description";
	String RATE_TABLE_CREATE_SHORT_DESCRIPTION = "rateTable.create.shortDescription";
	String RATE_TABLE_EDIT_DESCRIPTION = "rateTable.edit.description";
	String RATE_TABLE_EDIT_SHORT_DESCRIPTION = "rateTable.edit.shortDescription";
	String ENVIRONMENT = "environment";
	String DEV_SERVER_PATTERN = "vmmystqapp02d";
	String PROPERTIES = "properties/";
	String DEV_ENVIRONMENT = "dev";
	String QA_ENVIRONMENT = "qa";
	String COMMON = "common";
	String FILTER_RATE = "rateTable.filterName";
	
	
	//FOR DROPDOWN PURPOSE
	String CHANNEL_PROPERTY_XPATH = "//*[@id='layoutForm:operaPropertyCode_panel']/div/ul";
	String EXTERNAL_CHANNEL_KEY_XPATH="//*[@id='layoutForm:channel_panel']/div/ul";
	
}
