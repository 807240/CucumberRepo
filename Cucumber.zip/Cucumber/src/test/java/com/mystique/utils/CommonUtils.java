package com.mystique.utils;
import org.apache.commons.codec.binary.Base64;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Properties;

import mx4j.log.Logger;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mystique.application.BrowserDriver;

public class CommonUtils {

	WebDriver bd = BrowserDriver.getCurrentDriver();
	int count =0;
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MMM-dd-HH-mm-ss");	
	Calendar calendar = new GregorianCalendar();
	String dirname = sdf.format(calendar.getTime());

	public static User createValidUser(){
		User user = new User();
		user.withUserName(BrowserDriver.getCommomProperties().getProperty(Constants.MYSTIQUE_LOGIN_USER_ID)).
		withPassword(CryptoUtil.decrypt(BrowserDriver.getCommomProperties().getProperty(Constants.MYSTIQUE_LOGIN_PASSWORD)));
		return user;
	}

	public static User createInvalidUser(){
		User user = new User();
		user.withUserName("").withPassword("");
		return user;
	}
	/*
	 * Decryption of password
	 
	public static String decrypt(String encryptedText){
		byte[] decode=Base64.decodeBase64(encryptedText);
		String decryptedText = new String(decode);
		return decryptedText;
	}
*/
	/*
	 * Load key value from properties
	 */
	public static Properties getConfigPath(String path){
		Properties properties =null;
		Properties commonProperties =null;
		StringBuilder actualPropertyFilePath=new StringBuilder();
		String env=null;
		String pointedUrl=System.getProperty(Constants.ENVIRONMENT);
		try  {
			if(!path.contains(Constants.COMMON)){
				if(pointedUrl==null){
					commonProperties=new Properties();
					commonProperties.load(new FileInputStream(Constants.COMMON_PATH));
					pointedUrl=commonProperties.getProperty(Constants.MYSTIQUE_SERVER_URL);
				}

				if(pointedUrl.contains(Constants.DEV_SERVER_PATTERN)){
					env=Constants.DEV_ENVIRONMENT; 
				}else{
					env=Constants.QA_ENVIRONMENT;
				}

				actualPropertyFilePath.append(Constants.PROPERTIES).append(env).append("/").append(path);
	
			}else{
				actualPropertyFilePath.append(path);	
			}
			properties = new Properties();
			properties.load(new FileInputStream(actualPropertyFilePath.toString()));		
		} catch (IOException e) {
			e.printStackTrace();
		}
		return properties;
	}

	/*
	 * Captures screen shots of UI
	 */
	public void captureScreen() 
	{	
		String location = "./Screenshots/";  //location for images
		String name = Thread.currentThread().getStackTrace()[1].getMethodName();  
		String dirnamess=dirname;
		try {
			File scrFile = ((TakesScreenshot)bd).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(location+dirnamess+"/"+name+"_"+count+".jpg" ));
			count++;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * Check if a web element is visible to the browser else wait till 30 seconds   
	 */
	public void waitTimeElementVisibility(WebElement Elem)
	{
		new WebDriverWait(bd,30).until(ExpectedConditions.elementToBeClickable(Elem));
	}	
	
	/*
	 * Fetch from dropdown with value
	 */
	
	public static void fetchValueFromDropdown(String xpath, String dropDownValue ){
		WebElement select = BrowserDriver.getCurrentDriver().findElement(By.xpath(xpath));
		List<WebElement> options = select.findElements(By.tagName("li"));
		System.out.println ("Total number of list values is " + options.size());
		for (WebElement option : options) {		
			System.out.println ("List value is " + option.getAttribute("data-label").toString());
		    if(dropDownValue.equals(option.getAttribute("data-label").trim()))	
		    {
		        option.click();
		        break;
		    }
		    try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
		}
	}

}
