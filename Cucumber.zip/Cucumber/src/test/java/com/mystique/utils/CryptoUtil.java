package com.mystique.utils;

import org.apache.commons.codec.binary.Base64;

public final class CryptoUtil {
	
	private CryptoUtil(){	
		
	}
	private static Base64 base64 = new Base64();
	
	//final String bootstrapPassword = "test123";
	//bootstrapPassword
	
	public static String encrypt(String plainText){		
		byte[] plainTextByte = plainText.getBytes();
		byte[] encryptedByte = base64.encode(plainTextByte);
		String encryptedText  = new String(encryptedByte);
		
		return encryptedText;
	}
	
	public static String decrypt(String encryptedText){
		byte[] encryptedByte = encryptedText.getBytes();
		byte[] decryptedTextByte = base64.decode(encryptedByte);
		String decryptedText = new String(decryptedTextByte);
		
		return decryptedText;
	}

}