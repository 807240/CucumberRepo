package com.mystique.programsteps;

import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueProgramView;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AllProgramNavigationSteps {
	
	private static final Logger LOGGER = Logger.getLogger(AllProgramNavigationSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	@Given("^I click on the Drop Down to Select Campaign Administration and Property$")
	public void I_click_on_the_Drop_Down_to_Select_Campaign_Administration_and_Property() {
		MystiqueProgramView.selectCampaignAdmin();
		MystiqueProgramView.selectARIAfromDropDown();
	}

	@When("^I hover on Program and click on All Program$")
	public void I_hover_on_Program_and_click_on_All_Program() {
		MystiqueProgramView.hoverOnProgramTab();
		MystiqueProgramView.clickAllProgram();
	}
	@Then("^I should see All Program related tabs$")
	public void I_should_see_All_Program_related_tabs() {
		LOGGER.info("I am seeing all Program related tabs");

}
}
