package com.mystique.programsteps;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueProgramView;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;


public class SupressRateAndPrintRateSave {
	
		private static final Logger LOGGER = Logger.getLogger(SupressRateAndPrintRateSave.class.getName());
		static WebDriver wd=BrowserDriver.getCurrentDriver();

		@Given("^I click on Edit link for any program$")
		public void I_click_on_Edit_link_for_any_program() {

			MystiqueProgramView.editProgram();			
		}

		@When("^I click on edit link for any pricing rule$")
		public void I_click_on_edit_link_for_any_pricing_rule() {
			MystiqueProgramView.editPricingRule();
	
		}
		
		@Then("^I can check Supress Rate and Print Rate check boxes$")
		public void I_can_check_Supress_Rate_and_Print_Rate_check_boxes() {
			
			MystiqueProgramView.checkSupressRateAndPrintRate();
		}

}
