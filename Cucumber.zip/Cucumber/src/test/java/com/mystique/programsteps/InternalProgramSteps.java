package com.mystique.programsteps;


import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mystique.application.BrowserDriver;
import com.mystique.containers.MystiqueProgramContainer;
import com.mystique.utils.CommonUtils;
import com.mystique.utils.Constants;
import com.mystique.view.MystiqueProgramView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class InternalProgramSteps {

	private static final Logger LOGGER = Logger.getLogger(InternalProgramSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	public static final Properties roomProgram = CommonUtils.getConfigPath(Constants.ROOM_PROGRAM);
	public static final Properties common = CommonUtils.getConfigPath(Constants.COMMON_PATH);

	private static final MystiqueProgramContainer programContainer = PageFactory.initElements(BrowserDriver.getCurrentDriver(), MystiqueProgramContainer.class);
	public static final Properties channelProperties = CommonUtils.getConfigPath(Constants.CHANNEL_PATH);
	static String progName;
	static String PrgID;
	static int randomNum;
	static String programName;
	static String createPrgName;
	static CommonUtils Util=new CommonUtils();
	private static boolean value =false;
	static String TierCreditTo;
	static String TierCreditFrom;
	static JavascriptExecutor executor = (JavascriptExecutor)wd;
	public String programName()
	{ 
		do{
		randomNum = (int)(Math.random()*10000);				
		//PrgID=Integer.toString(randomNum);
	    PrgID= "6028";
		programName="Cucumber7_6028";
		WebElement select = BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:dataTable_data']/tr"));
		List<WebElement> options = select.findElements(By.tagName("td"));
        	if(options.size()>1)
        	{
        		value =false;		
        	}	
	
		}
		while(value);
		return programName;
	}
	

	/*
	 * Create Program with BAR checkbox ON and validate after save	
	 */
	@Given("^I create a program with BAR checkbox ON and save it$")
	public void I_create_a_program_with_BAR_checkbox_ON_and_save_it() {

		try{
			//Thread.sleep(10000);
			progName = programName();
			LOGGER.info("Program name in BAR checkbox ON: "+progName);
			//Thread.sleep(10000);
			MystiqueProgramView.createNewProgram();
			//Thread.sleep(10000);
			MystiqueProgramView.selectCategory();
		//	Thread.sleep(10000);
			Util.waitTimeElementVisibility(programContainer.BAROffer);

			executor.executeScript("arguments[0].scrollIntoView(true);", programContainer.BAROffer);
			executor.executeScript("arguments[0].click();", programContainer.BAROffer);
			executor.executeScript("arguments[0].click();", programContainer.activeFlag);
			
			//programContainer.BAROffer.click();
			//Thread.sleep(10000);
			TypeProgramDetails();
			Thread.sleep(100);
		}catch(InterruptedException e){
			e.printStackTrace();
		}
		LOGGER.info("Creating a Prg - Checking BAR Check Box ONLY and saving Program");
	}

	@When("^I open the created program feature again to validate BAR checked$")
	public void I_open_the_Program_feature_again_to_validate_BAR_checked() {

		try {
			Thread.sleep(10000);
			WebDriver wd=BrowserDriver.getCurrentDriver();
			//Util.waitTimeElementVisibility(wd.findElement(By.id("layoutForm:dataTable:Name:filter")));
			new WebDriverWait(BrowserDriver.getCurrentDriver(),40).until(ExpectedConditions.visibilityOfElementLocated(By.id("layoutForm:dataTable:Name:filter")));
			wd.findElement(By.id("layoutForm:dataTable:Name:filter")).click();
			wd.findElement(By.id("layoutForm:dataTable:Name:filter")).clear();
			Util.waitTimeElementVisibility(wd.findElement(By.id("layoutForm:dataTable:Name:filter")));
			wd.findElement(By.id("layoutForm:dataTable:Name:filter")).sendKeys(progName);
			//Assert.assertTrue("PASS, Filter Table is present",wd.findElement(By.id("layoutForm:dataTable:Name:filter")).isDisplayed());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		MystiqueProgramView.openProgramFeature();
		LOGGER.info("Opening Program Feature");
	}
	
	@Then("^I should see the BAR offer checked for the new program$")
	public void I_should_see_the_BAR_offer_checked_for_the_new_program() {
		LOGGER.info("Validating Changes");
		WebDriver wd= BrowserDriver.getCurrentDriver();
		boolean isBARChkd = wd.findElements(By.xpath("//*[@id='layoutForm:isBAR']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size()>0;
		boolean isPublicOfferChkd = wd.findElements(By.xpath("//*[@id='layoutForm:isPublic']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size()>0;
		Assert.assertNotEquals(wd.findElements(By.xpath("//*[@id='layoutForm:isBAR']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size(),0);
	//	Assert.assertNotEquals(wd.findElements(By.xpath("//*[@id='layoutForm:isPublic']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size(),0);
		if ( isBARChkd && !isPublicOfferChkd ) {
			LOGGER.info("Test Passed");
			wd.navigate().back();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		} else {
			LOGGER.info("Test Failed");
			wd.navigate().back();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	/* 
	 * Create Program with Public Offer checkbox ON and validate after save	 
	 */ 
	
	@Given("^I create a program with PublicOffer checkbox ON and save it$")
	public void I_create_a_program_with_PublicOffer_checkbox_ON_and_save_it() {
		try{
			LOGGER.info("Program name in PublicOffer checkbox ON: " + progName);
			I_open_the_Program_feature_again_to_validate_PublicOffer_checked();
			Thread.sleep(10000);
			Util.waitTimeElementVisibility(programContainer.BAROffer);
			//programContainer.BAROffer.click();
			executor.executeScript("arguments[0].click();",programContainer.BAROffer);
			//Thread.sleep(5000);
			Util.waitTimeElementVisibility(programContainer.OfferPage);
			//programContainer.OfferPage.click();
			executor.executeScript("arguments[0].click();",programContainer.OfferPage);
			Thread.sleep(10000);
			Util.waitTimeElementVisibility(programContainer.saveProgram);
			int intTest = wd.findElements(By.id("layoutForm:saveButton")).size();
			Assert.assertTrue("Failed, Save Program link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Save Program link is present",programContainer.saveProgram.isDisplayed());
			//programContainer.saveProgram.click();
			executor.executeScript("arguments[0].click();",programContainer.saveProgram);
			Thread.sleep(10000);
		}catch(InterruptedException e){
			e.printStackTrace();
		}
		LOGGER.info("Updating a Prg - Checking PUBLIC OFFER Check Box ONLY and saving Program");
	}

	@When("^I open the created program feature again to validate PublicOffer checked$")
	public void I_open_the_Program_feature_again_to_validate_PublicOffer_checked() {

		try {
			Thread.sleep(15000);
			WebDriver wd=BrowserDriver.getCurrentDriver();
			Thread.sleep(20000);
			Util.waitTimeElementVisibility(wd.findElement(By.id("layoutForm:dataTable:Name:filter")));
			wd.findElement(By.id("layoutForm:dataTable:Name:filter")).click();
			Thread.sleep(10000);
			Util.waitTimeElementVisibility(wd.findElement(By.id("layoutForm:dataTable:Name:filter")));
			wd.findElement(By.id("layoutForm:dataTable:Name:filter")).clear();
			Thread.sleep(10000);
			Util.waitTimeElementVisibility(wd.findElement(By.id("layoutForm:dataTable:Name:filter")));
			int intTest = wd.findElements(By.id("layoutForm:dataTable:Name:filter")).size();
			Assert.assertTrue("Failed, Filter table is not present",intTest > 0);
			//Assert.assertTrue("PASS, Filter table is present",wd.findElement(By.id("layoutForm:dataTable:Name:filter")).isDisplayed());
			wd.findElement(By.id("layoutForm:dataTable:Name:filter")).sendKeys(progName);
		
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		MystiqueProgramView.openProgramFeature();
		LOGGER.info("Opening Programing Feature");
	}

	@Then("^I should see the Public offer checked for the new program$")
	public void I_should_see_the_Public_offer_checked_for_the_new_program() {
		LOGGER.info("Validating Changes");

		WebDriver wd= BrowserDriver.getCurrentDriver();
		boolean isBARChkd = wd.findElements(By.xpath("//*[@id='layoutForm:isBAR']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size()>0;
		boolean isPublicOfferChkd = wd.findElements(By.xpath("//*[@id='layoutForm:isPublic']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size()>0;
		/*Assert.assertNotEquals(wd.findElements(By.xpath("//*[@id='layoutForm:isBAR']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size(),0);
		Assert.assertNotEquals(wd.findElements(By.xpath("//*[@id='layoutForm:isPublic']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size(),0);*/
		if ( !isBARChkd && isPublicOfferChkd ) {
			LOGGER.info("Test Passed");
			wd.navigate().back();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		} else {
			LOGGER.info("Test Failed");
			wd.navigate().back();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	/*
	 * 
	 * Create Program with both BAR Offer and Public Offer checkbox ON and validate after save	
	 * 
	 * */ 
	@Given("^I create a program with BAR and PublicOffer checkbox ON and save it$")
	public void I_create_a_program_with_BAR_and_PublicOffer_checkbox_ON_and_save_it() {

		try{
			LOGGER.info("Program name in both checkbox ON: "+progName);
			I_open_the_Program_feature_again_to_validate_PublicOffer_checked();
			Thread.sleep(10000);
			Util.waitTimeElementVisibility(programContainer.BAROffer);
			//programContainer.BAROffer.click();
			executor.executeScript("arguments[0].click();", programContainer.BAROffer);
			Thread.sleep(10000);
			Util.waitTimeElementVisibility(programContainer.saveProgram);
			
			int intTest = wd.findElements(By.id("layoutForm:saveButton")).size();
			Assert.assertTrue("Failed, Save Program link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Save Program link is present",programContainer.saveProgram.isDisplayed());
		//	programContainer.saveProgram.click();
			executor.executeScript("arguments[0].click();",programContainer.saveProgram);
			Thread.sleep(10000);
		}catch(InterruptedException e){
			e.printStackTrace();
		}
		LOGGER.info("Updating a Prg - Checking BAR & PUBLIC OFFER Check Box BOTH and saving Program");
	}

	@When("^I open the created program feature again to validate BAR and PublicOffer checked$")
	public void I_open_the_Program_feature_again_to_validate_BAR_and_PublicOffer_checked() {

		try {
			Thread.sleep(10000);
			WebDriver wd=BrowserDriver.getCurrentDriver();
			Util.waitTimeElementVisibility(wd.findElement(By.id("layoutForm:dataTable:Name:filter")));
			wd.findElement(By.id("layoutForm:dataTable:Name:filter")).click();
			Thread.sleep(10000);
			wd.findElement(By.id("layoutForm:dataTable:Name:filter")).clear();
			Thread.sleep(10000);
			Util.waitTimeElementVisibility(wd.findElement(By.id("layoutForm:dataTable:Name:filter")));
			//Assert.assertTrue("PASS, Filter Table is present",wd.findElement(By.id("layoutForm:dataTable:Name:filter")).isDisplayed());
			wd.findElement(By.id("layoutForm:dataTable:Name:filter")).sendKeys(progName);
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		MystiqueProgramView.openProgramFeature();
		LOGGER.info("Opening Programing Feature");
	}

	@Then("^I should see the BAR and Public offer checked for the new program$")
	public void I_should_see_the_BAR_and_Public_offer_checked_for_the_new_program() {
		LOGGER.info("Validating Changes");


		WebDriver wd= BrowserDriver.getCurrentDriver();
		boolean isBARChkd = wd.findElements(By.xpath("//*[@id='layoutForm:isBAR']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size()>0;
		boolean isPublicOfferChkd = wd.findElements(By.xpath("//*[@id='layoutForm:isPublic']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size()>0;
		Assert.assertNotEquals(wd.findElements(By.xpath("//*[@id='layoutForm:isPublic']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size(),0);
		if ( isBARChkd && isPublicOfferChkd ) {
			LOGGER.info("Test Passed");
			wd.navigate().back();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		} else {
			LOGGER.info("Test Failed");
			wd.navigate().back();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	/*
	 * 
	 * Create Program with both BAR Offer and Public Offer checkbox OFF and validate after save	
	 * 
	 * */ 
	@Given("^I create a program with BAR and PublicOffer checkbox OFF and save it$")
	public void I_create_a_program_with_BAR_and_PublicOffer_checkbox_OFF_and_save_it() {

		try{
			LOGGER.info("Program name in both checkbox OFF: "+progName);
			Thread.sleep(20000);
			I_open_the_Program_feature_again_to_validate_PublicOffer_checked();
			Util.waitTimeElementVisibility(programContainer.BAROffer);
			//programContainer.BAROffer.click();
			executor.executeScript("arguments[0].click();", programContainer.BAROffer);
			Thread.sleep(10000);
			Util.waitTimeElementVisibility(programContainer.OfferPage);
			//programContainer.OfferPage.click();
			executor.executeScript("arguments[0].click();",programContainer.OfferPage);
			Thread.sleep(10000);
			Util.waitTimeElementVisibility(programContainer.saveProgram);
			int intTest = wd.findElements(By.id("layoutForm:saveButton")).size();
			Assert.assertTrue("Failed, Save Program link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Save Program link is present",programContainer.saveProgram.isDisplayed());
			//programContainer.saveProgram.click();
			executor.executeScript("arguments[0].click();",programContainer.saveProgram);
			Thread.sleep(10000);
		}catch(InterruptedException e){
			e.printStackTrace();
		}
		LOGGER.info("Updating a Prg - Un-Checking BAR & PUBLIC OFFER Check Box BOTH and saving Program");

	}

	@When("^I open the created program feature again to validate BAR and PublicOffer unchecked$")
	public void I_open_the_Program_feature_again_to_validate_BAR_and_PublicOffer_unchecked() {

		try {
			Thread.sleep(15000);
			WebDriver wd=BrowserDriver.getCurrentDriver();
			Thread.sleep(15000);
			wd.findElement(By.id("layoutForm:dataTable:Name:filter")).click();
			Thread.sleep(10000);
			wd.findElement(By.id("layoutForm:dataTable:Name:filter")).clear();
			Thread.sleep(10000);
			Util.waitTimeElementVisibility(wd.findElement(By.id("layoutForm:dataTable:Name:filter")));
			wd.findElement(By.id("layoutForm:dataTable:Name:filter")).sendKeys(progName);
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		MystiqueProgramView.openProgramFeature();
		LOGGER.info("Opening Programing Feature");
	}

	@Then("^I should see the BAR and Public offer unchecked for the new program$")
	public void I_should_see_the_BAR_and_Public_offer_unchecked_for_the_new_program() {
		LOGGER.info("Validating Changes");


		WebDriver wd= BrowserDriver.getCurrentDriver();
		boolean isBARChkd = wd.findElements(By.xpath("//*[@id='layoutForm:isBAR']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size()>0;
		boolean isPublicOfferChkd = wd.findElements(By.xpath("//*[@id='layoutForm:isPublic']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size()>0;
		Assert.assertEquals(wd.findElements(By.xpath("//*[@id='layoutForm:isPublic']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size(),0);
		Assert.assertEquals(wd.findElements(By.xpath("//*[@id='layoutForm:isBAR']/div[2][@class='ui-chkbox-box ui-widget ui-corner-all ui-state-default ui-state-active']")).size(),0);
		if ( !(isBARChkd && isPublicOfferChkd)) {
			LOGGER.info("Test Passed");
			wd.navigate().back();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		} else {
			LOGGER.info("Test Failed");
			wd.navigate().back();
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}


	}

	/*
	 * 
	 *CreateDoubleDerivedProgramSteps
	 * 
	 */

	@Given("^I click on the Manage Programs tab to provide data for double derived program$")
	public void I_click_on_the_Manage_Programs_tab_to_provide_data_for_double_derived_program() {
		LOGGER.info("before createPricingProgram");
		String pricingPrgName = MystiqueProgramView.createPricingProgram();

		LOGGER.info("Creating derived program");
		MystiqueProgramView.createNewProgram();
		MystiqueProgramView.selectCategory();
		String randomNumber = String.valueOf(MystiqueProgramView.getRandomNumber());
		MystiqueProgramView.provideProgramValueForDoubleDerived("Cucumber8_"+randomNumber, randomNumber);

		MystiqueProgramView.provideOfferBasicSettingsValueForDoubleDerived();
		MystiqueProgramView.provideAccessSettingsValue();
		MystiqueProgramView.createNewPricingRule();
		MystiqueProgramView.valueForPricingRuleForDerivedProgram(pricingPrgName);
		MystiqueProgramView.saveCreatedNewPricingRule();

		MystiqueProgramView.providePromotionOrInclusionValueForDoubleDerived();
		MystiqueProgramView.provideDateRestrictionValueForDoubleDerived();
		//MystiqueProgramView.provideMinimumNoOfNightsValue();
		MystiqueProgramView.provideAdvanceBookingValue();
		MystiqueProgramView.provideSelectPlayerTierValue();

		MystiqueProgramView.provideNotesValueForDoubleDerived();
		MystiqueProgramView.provideSelectPaymentTypeValue();
		MystiqueProgramView.provideAssociateRoomsValue();
		MystiqueProgramView.provideAssociateRoomsSyncValue();
		MystiqueProgramView.saveNewProgram();

		LOGGER.info(String.format("Editing pricing program %s to UNCHECK Active flag", pricingPrgName));
		MystiqueProgramView.searchName(pricingPrgName);
		MystiqueProgramView.editProgram();
	}

	@When("^I provide Invalid and then Valid data to create double derived program$")
	public void I_provide_Invalid_and_then_Valid_data_to_create_double_derived_program() {
		MystiqueProgramView.inactiveAccessSettingsValue();
		MystiqueProgramView.saveNewProgram();

	}
	@Then("^I complete providing data and click Save to save double derived program$")
	public void I_complete_providing_data_and_click_Save_to_save_double_derived_program() {
		LOGGER.info("I complete providing data and click Save to save double derived program"); 
		LOGGER.info("Editing pricing program to CHECK Active flag");
		MystiqueProgramView.activeAccessSettingsValue();
		MystiqueProgramView.saveNewProgram();
		LOGGER.info("Test case passed");
	}


	/*
	 * 
	 *CreateNewProgramSteps
	 * 
	 */

	@Given("^I click on the Manage Programs tab to provide data$")
	public void I_click_on_the_Manage_Programs_tab_to_provide_data() {
	    createPrgName = MystiqueProgramView.createAndEditProgram();
		MystiqueProgramView.searchName(createPrgName );


	}
	@When("^I provide Invalid and then Valid data to create new Program$")
	public void I_provide_Invalid_and_then_Valid_data_to_create_new_Program() {
		LOGGER.info("I complete providing data and click Save to save new Program"); 


	}
	@Then("^I complete providing data and click Save to save new Program$")
	public void I_complete_providing_data_and_click_Save_to_save_new_Program() {
		LOGGER.info("PASS---I complete providing data and  Search to edit created Program"); 
	}

	/*
	 * 
	 *EditProgramSteps
	 * 
	 **/
	@Given("^I click on the edit Program link to provide data$")
	public void I_click_on_the_edit_Program_link_to_provide_data() {
		//String editPrgName=MystiqueProgramView.editCreatedProgram();
		MystiqueProgramView.editProgram();
		MystiqueProgramView.providePromotionOrInclusionValue();
		MystiqueProgramView.provideDateRestrictionValue();
		//MystiqueProgramView.provideMinimumNoOfNightsValue();
       

	}
	@When("^I provide Invalid and then Valid data to edit Program$")
	public void I_provide_Invalid_and_then_Valid_data_to_edit_Program() {
		MystiqueProgramView.provideAdvanceBookingValue();
		MystiqueProgramView.provideSelectPlayerTierValue();
		MystiqueProgramView.provideNotesValue();
		MystiqueProgramView.provideSelectPaymentTypeValue();
		//MystiqueProgramView.provideAssociateRoomsValue();	
		MystiqueProgramView.saveNewProgram();
	}
	@Then("^I complete providing data and Save edited Program$")
	public void I_complete_providing_data_and_Save_edited_Program() {
		LOGGER.info("PASS---I complete providing data and Save edited Program");

	} 
	
	/*
	 * Delete Pricing Rule
	 * 
	 */
	 @Given("^I click on the edit Program link to delete pricing Rule$")
	 public void I_click_on_the_edit_Program_link_to_delete_pricing_Rule(){
		 MystiqueProgramView.searchName(createPrgName );
		 MystiqueProgramView.editProgram();
	 }
	 @When("^I delete the Pricing Rule$")
	 public void I_delete_the_Pricing_Rule(){
		 MystiqueProgramView.deletePricingOptionLink();
	  }
     @Then("^I see the inactive status")
     public void I_see_the_inactive_status(){
    	 MystiqueProgramView.editPricingOptionLink();
    	 MystiqueProgramView.activeCheckPricing();
    	 MystiqueProgramView.saveCreatedNewPricingRule();
    	 MystiqueProgramView.saveNewProgram();
    	 LOGGER.info("PASS---I complete deleting the pricing rule and is marked as Inactive");
      }
     
	/*
	 * 
	 * Feature file: 16_search_program.feature
	 * Scenario: Search by Customer Values Fields From
	 * 
	 */
	@Given("^I search Programs using specific values From$")
	public void I_search_Programs_using_specific_values_From() {
		MystiqueProgramView.hoverOnProgramTab();
		MystiqueProgramView.clickManageProgram();
		MystiqueProgramView.clickOnSearchLink();

	}

	@When("^I provide value for Customer Value From field$")
	public void I_provide_value_for_Customer_Value_From_field() {
		MystiqueProgramView.inputCustomerValueFrom(progName);

	}

	@Then("^I see program names with lower Customer Value From field equal to or greater$")
	public void I_see_program_names_with_lower_Customer_Value_From_field_equal_to_or_greater() {
		LOGGER.info("Validating search result");


		WebDriver wd= BrowserDriver.getCurrentDriver();
		boolean isPrgPresent = wd.findElements(By.xpath("//*[contains(text(), '" + progName + "')]")).size()>0;
		boolean isNegPrgPresent = wd.findElements(By.xpath("//*[contains(text(), '" + progName + "_" +"')]")).size()>0;
		//Assert.assertNotEquals(wd.findElements(By.xpath("//*[contains(text(), '" + progName + "')]")).size(),0);
		//Assert.assertNotEquals(wd.findElements(By.xpath("//*[contains(text(), '" + progName + "_" +"')]")).size(),0);
		//Assert.assertTrue("Test Failed",isPrgPresent && !isNegPrgPresent);
		if ( isPrgPresent && !isNegPrgPresent ) {
			LOGGER.info("Test Failed");
		} else {
			LOGGER.info("Test Passed");
		}
	}

	/*
	 * 
	 * Feature file: 16_search_program.feature
	 * Scenario: Search by Customer Values Fields To
	 * 
	 */
	@Given("^I search Programs using specific values To$")
	public void I_search_Programs_using_specific_values_To() {
		MystiqueProgramView.clickOnSearchLink();

	}

	@When("^I provide value for Customer Value To field$")
	public void I_provide_value_for_Customer_Value_To_field() {
		MystiqueProgramView.inputCustomerValueTo(programName);
	}

	@Then("^I see program names with lower Customer Value To field equal to or greater$")
	public void I_see_program_names_with_lower_Customer_Value_To_field_equal_to_or_greater() {
		LOGGER.info("Validating search result");

		WebDriver wd = BrowserDriver.getCurrentDriver();
		boolean isPrgPresent = wd.findElements(By.xpath("//*[contains(text(),'" + progName + "')]")).size()>0;
		boolean isNegPrgPresent = wd.findElements(By.xpath("//*[contains(text(),'" + progName + "_"+"')]")).size()>0;
		//Assert.assertNotEquals(wd.findElements(By.xpath("//*[contains(text(),'" + progName + "')]")).size(),0);
		//Assert.assertNotEquals(wd.findElements(By.xpath("//*[contains(text(),'" + progName + "_"+"')]")).size(),0);
		Assert.assertTrue("Test Failed",isPrgPresent && !isNegPrgPresent);
		if ( isPrgPresent && !isNegPrgPresent ) {
			LOGGER.info("Test Failed");
		} else {
			LOGGER.info("Test Passed");
		}
	}

	/*
	 * 
	 * Feature file: 16_search_program.feature
	 * Scenario: Search by Customer Values Fields From and To
	 * 
	 */
	@Given("^I search Programs using specific values From and To$")
	public void I_search_Programs_using_specific_values_TonFrom() {
		MystiqueProgramView.clickOnSearchLink();

		LOGGER.info("Clicked on Search Program Successfully");
	}

	@When("^I provide value for Customer Value From and To field$")
	public void I_provide_value_for_Customer_Value_TonFrom_field() {	
		MystiqueProgramView.inputCustomerValueToFrom(programName);
		LOGGER.info("Providing Values for Search");
	}

	@Then("^I see program names with lower Customer Value From  and To field equal to or greater$")
	public void I_see_program_names_with_lower_Customer_Value_TonFrom_field_equal_to_or_greater() {
		LOGGER.info("Validating search result");


		WebDriver wd= BrowserDriver.getCurrentDriver();
		boolean isPrgPresent = wd.findElements(By.xpath("//*[contains(text(),'" + progName + "')]")).size()>0;
		boolean isNegPrgPresent = wd.findElements(By.xpath("//*[contains(text(),'" + progName + "_"+"')]")).size()>0;
		//Assert.assertNotEquals(wd.findElements(By.xpath("//*[contains(text(),'" + progName + "')]")).size(),0);
		//Assert.assertNotEquals( wd.findElements(By.xpath("//*[contains(text(),'" + progName + "_"+"')]")).size(),0);
		//Assert.assertTrue("Test Failed",isPrgPresent && !isNegPrgPresent);
		if ( isPrgPresent && !isNegPrgPresent ) {
			LOGGER.info("Test Failed");
		} else {
			LOGGER.info("Test Passed");
		}
	}
	
	@Given("^I try to create a new pricing rule$")
	public void I_try_to_create_a_new_pricing_rule() {
		MystiqueProgramView.editProgram();

		LOGGER.info("Clicked on Edit Program Successfully");
	}
	
	@When("^I provide comp nights greater than 0 and no routing instruction mapped$")
	public void I_provide_comp_nights_greater_than_0_and_no_routing_instruction_mapped() {	
		MystiqueProgramView.createNewRoutingInstruction();
		MystiqueProgramView.valueForRoutingInstruction();
		MystiqueProgramView.saveCreatedNewRoutingInstruction();
		LOGGER.info("Routing Instruction has been created and saved");
		MystiqueProgramView.createNewPricingRule();
		MystiqueProgramView.valueForPricingRule("09/01/2016","09/11/2016","percentage",MystiqueProgramView.getRandomNumber());
		MystiqueProgramView.changeCompNightsNonZero();
		MystiqueProgramView.saveCreatedNewPricingRule();
		
		
	}


	@When("^I provide comp nights greater than 0 and routing instruction mapped$")
	public void I_provide_comp_nights_greater_than_0_and_routing_instruction_mapped() {	
		MystiqueProgramView.createNewRoutingInstruction();
		MystiqueProgramView.valueForRoutingInstruction();
		MystiqueProgramView.saveCreatedNewRoutingInstruction();
		LOGGER.info("Routing Instruction has been created and saved");
		MystiqueProgramView.createNewPricingRule();
		MystiqueProgramView.valueForPricingRule("09/01/2016","09/11/2016","percentage",MystiqueProgramView.getRandomNumber());
		MystiqueProgramView.changeCompNightsNonZero();
		MystiqueProgramView.selectingRIforPricingRule();
		MystiqueProgramView.saveCreatedNewPricingRule();
	}
	
	@When("^I provide comp nights equal to 0 and no routing instruction mapped$")
	public void I_provide_comp_nights_equal_0_and_no_routing_instruction_mapped() {	
		MystiqueProgramView.createNewRoutingInstruction();
		MystiqueProgramView.valueForRoutingInstruction();
		MystiqueProgramView.saveCreatedNewRoutingInstruction();
		LOGGER.info("Routing Instruction has been created and saved");
		MystiqueProgramView.createNewPricingRule();
		MystiqueProgramView.valueForPricingRule("09/01/2016","09/11/2016","percentage",MystiqueProgramView.getRandomNumber());
		MystiqueProgramView.changeCompNightsZero();
		MystiqueProgramView.saveCreatedNewPricingRule();
	}
	
	@When("^I provide comp nights equal to 0 and routing instruction mapped$")
	public void I_provide_comp_nights_equal_0_and_routing_instruction_mapped() {	
		MystiqueProgramView.createNewRoutingInstruction();
		MystiqueProgramView.valueForRoutingInstruction();
		MystiqueProgramView.saveCreatedNewRoutingInstruction();
		LOGGER.info("Routing Instruction has been created and saved");
		MystiqueProgramView.createNewPricingRule();
		MystiqueProgramView.valueForPricingRule("09/01/2016","09/11/2016","percentage",MystiqueProgramView.getRandomNumber());
		MystiqueProgramView.changeCompNightsZero();
		MystiqueProgramView.selectingRIforPricingRule();
		MystiqueProgramView.saveCreatedNewPricingRule();
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	@Then("^I shouldn't be allowed to save the pricing rule$")
	public void I_shouldnt_be_allowed_to_save_the_pricing_rule() {
		LOGGER.info("Validating pricing rule save");

		WebDriver wd= BrowserDriver.getCurrentDriver();
		Util.waitTimeElementVisibility(wd.findElement(By.xpath("//*[@id='layoutForm:alertDialogVal']")));
		boolean isErrorPresent = wd.findElements(By.xpath("//*[@id='layoutForm:alertDialogVal']")).size()>0;
		
		if ( isErrorPresent ) 
		{
			LOGGER.info("The user is not allowed to save the pricing rule,PASS");
			Util.waitTimeElementVisibility(wd.findElement(By.xpath("//*[@id='layoutForm:alertOkButton']")));
			executor.executeScript("arguments[0].click();",wd.findElement(By.xpath("//*[@id='layoutForm:alertOkButton']")));
			
		} else {
			LOGGER.info("The user is allowed to save the pricing rule,FAIL");
		}
		MystiqueProgramView.hoverOnProgramTab();
		MystiqueProgramView.clickManageProgram();
	}
	
	@Then("^I should be allowed to save the pricing rule$")
	public void I_should_be_allowed_to_save_the_pricing_rule() {
		LOGGER.info("Validating pricing rule save");

		WebDriver wd= BrowserDriver.getCurrentDriver();
		Util.waitTimeElementVisibility(wd.findElement(By.xpath("//*[@id='layoutForm:priceGrid']/tbody/tr[1]/td")));
		boolean isParentPrgPage = wd.findElements(By.xpath("//*[@id='layoutForm:priceGrid']/tbody/tr[1]/td")).size()>0;
		
		if ( isParentPrgPage ) 
		{
			LOGGER.info("The user is allowed to save the pricing rule,PASS");
		} else {
			LOGGER.info("The user is not allowed to save the pricing rule,FAIL");
		}
		MystiqueProgramView.hoverOnProgramTab();
		MystiqueProgramView.clickManageProgram();
	}
	@Given("^I try to set correct data range in Tier credit Range$")
	public void I_try_to_set_correct_data_range_in_Tier_credit_Range(){
		MystiqueProgramView.openProgramFeature();
		LOGGER.info("Opening Program Feature");
		MystiqueProgramView.valiadteTierCreditRangeLabel();
		LOGGER.info("Tier Credit label exists");
		MystiqueProgramView.setDecimalSplCharTierCreditRange("65.03","425.326524");
		LOGGER.info("Unable to set Decimal Value");
		MystiqueProgramView.setDecimalSplCharTierCreditRange("7788$%","6894#$");
		LOGGER.info("Unable to set special Char Value");
		
		MystiqueProgramView.setTierCreditRange("65","200");
		LOGGER.info("Set Tier credit range with correct data");
	}
	
	@Given("^I try to navigate Progam manager and Edit data$")
	public void I_try_to_navigate_Progam_manager_and_Edit_data(){
		MystiqueProgramView.openProgramFeature();
		LOGGER.info("Opening Program Feature");
		MystiqueProgramView.valiadteTierCreditRangeLabel();
		LOGGER.info("Tier Credit label exists");
		
	}
	
	@Given("^I try to set valid Credit range value$")
	public void I_try_to_set_valid_Credit_range_value(){
		//MystiqueProgramView.openProgramFeature();
		LOGGER.info("Opening Program Feature");
		MystiqueProgramView.valiadteTierCreditRangeLabel();
		LOGGER.info("Tier Credit label exists");
		
	}
	@Given("^I try to navigate Progam manager and Edit data2$")
	public void I_try_to_navigate_Progam_manager_and_Edit_data2(){
		MystiqueProgramView.openProgramFeature();
		LOGGER.info("Opening Program Feature");
		MystiqueProgramView.valiadteTierCreditRangeLabel();
		LOGGER.info("Tier Credit label exists");
		
	}
	
	@Given("^I try to set Tier credit from value more than to value$")
	public void I_try_to_set_Tier_credit_from_value_more_than_to_value(){
		MystiqueProgramView.openProgramFeature();
		//LOGGER.info("Opening Program Feature");
		MystiqueProgramView.valiadteTierCreditRangeLabel();
		//LOGGER.info("Tier Credit label exists");
		MystiqueProgramView.setTierCreditRange("200","65");
		
	}
	
	@When("^I provide Tier credit range value with special character , decimal value$")
	public void I_provide_Tier_credit_range_value_with_special_character_decimal_value(){
		MystiqueProgramView.setDecimalSplCharTierCreditRange("65.03","425.326524");
		LOGGER.info("Unable to set Decimal Value");
		MystiqueProgramView.setDecimalSplCharTierCreditRange("7788$%","6894#$");
		LOGGER.info("Unable to set special Char Value");
		
		//MystiqueProgramView.setTierCreditRange("65","200");
		//LOGGER.info("Set Tier credit range with correct data");
	}
	
	@When("^I provide correct Tier credit range value and save the data$")
	public void I_provide_correct_Tier_credit_range_value_and_save_the_data(){
		
		TierCreditTo = "65";
		TierCreditFrom = "200";
		MystiqueProgramView.setTierCreditRange(TierCreditTo,TierCreditFrom);
		LOGGER.info("Set Tier credit range with correct data");
		MystiqueProgramView.saveProgram();
		LOGGER.info("Click on Save buttonr");
		MystiqueProgramView.validateProgramSaveMessage();
		
	}
	
	@Then("^I shouldn't be allowed to set rather interger value$")
	public void I_shouldnt_be_allowed_to_set_rather_interger_value (){
		
		MystiqueProgramView.setTierCreditRange("1236554789123","3236554789123");
		
		Assert.assertNotEquals(programContainer.TierCreditFromTextBox.getText(), "1236554789123");
		Assert.assertNotEquals(programContainer.TierCreditToTextBox.getText(), "3236554789123");
		LOGGER.info("Set Tier credit range more than 10 digit number");
		System.out.println("Passed scenario: 'Validate whether Tier Credit Range exist and allow only integer value in text box'");
	}
	
	@Then("^I should be verify whether the Tier credit range saved successfully$")
	public void I_should_be_verify_whether_the_Tier_credit_range_saved_successfully (){
		
		//MystiqueProgramView.saveProgram();
		//LOGGER.info("Click on Save buttonr");
		//MystiqueProgramView.validateProgramSaveMessage();
		MystiqueProgramView.openProgramFeature();
		LOGGER.info("Opening Program Feature");
		MystiqueProgramView.validateTierCreditRangeFieldValue(TierCreditTo,TierCreditFrom);
		LOGGER.info("Verify succesfully");
		MystiqueProgramView.setTierCreditRange("200","");
		LOGGER.info("Set Tier credit range with correct data with From data only");
		MystiqueProgramView.saveProgram();
		LOGGER.info("Click on Save buttonr");
		MystiqueProgramView.validateProgramSaveMessage();
		MystiqueProgramView.openProgramFeature();
		MystiqueProgramView.setTierCreditRange("","200");
		LOGGER.info("Set Tier credit range with correct data with To data only");
		MystiqueProgramView.saveProgram();
		LOGGER.info("Click on Save buttonr");
		MystiqueProgramView.validateProgramSaveMessage();
		
		System.out.println("Passed scenario: 'Validate Tier credit range data saved succesfully'");
	}
	@When("^I provide Tier credit from value more than Tier credit to value and saved it$")
	public void I_provide_Tier_credit_from_value_more_than_Tier_credit_to_value_and_saved_it(){
		
		MystiqueProgramView.saveProgram();
		LOGGER.info("Click on Save button");
	}
	
	@Then("^I shouldn't be allowed to save the Tier Credit range Value$")
	public void I_shouldnt_be_allowed_to_save_the_Tier_Credit_range_Value(){
		
		//MystiqueProgramView.setTierCreditRange("200","65");
		MystiqueProgramView.saveProgram();
		LOGGER.info("Click on Save button");
		MystiqueProgramView.validateTierCreditRangeMessage();
		LOGGER.info("validate Tier Credit Range Message");
		System.out.println("Passed scenario: 'Validate unable to save Tier credit range To data more than From data'");
	}
	
	public static void TypeProgramDetails(){

		LOGGER.info("Clearing Program Name");
		System.out.println(progName);
		try {
			programContainer.programName.clear();
			LOGGER.info("Cleared Program Name");
			Thread.sleep(100);
			LOGGER.info("Clearing Program Name");
			System.out.println(progName);
			Util.waitTimeElementVisibility(programContainer.programName);
			programContainer.programName.sendKeys(progName);
			//Thread.sleep(100);
			programContainer.userProgramId.clear();
			programContainer.userProgramId.sendKeys(PrgID);
			//Thread.sleep(5000);
			Util.waitTimeElementVisibility(programContainer.programTag1Input);
			programContainer.programTag1Input.clear();
			programContainer.programTag1Input.sendKeys("Tag1");
			//Thread.sleep(5000);
			Util.waitTimeElementVisibility(programContainer.tierOption);
			executor.executeScript("arguments[0].click();", programContainer.tierOption);
			//programContainer.tierOption.click();
			Util.waitTimeElementVisibility(programContainer.tierAdd);
			executor.executeScript("arguments[0].click();", programContainer.tierAdd);
			//programContainer.tierAdd.click();
			//Thread.sleep(3000);
			Util.waitTimeElementVisibility(programContainer.TierCreditFromTextBox);
			//programContainer.TierCreditFromTextBox.clear();
			Util.waitTimeElementVisibility(programContainer.TierCreditFromTextBox);
			programContainer.TierCreditFromTextBox.sendKeys(roomProgram.getProperty("program.customerValueFromInput"));
			//Thread.sleep(5000);
			Util.waitTimeElementVisibility(programContainer.TierCreditToTextBox);
			//programContainer.TierCreditToTextBox.clear();
			Util.waitTimeElementVisibility(programContainer.TierCreditToTextBox);
			programContainer.TierCreditToTextBox.sendKeys(roomProgram.getProperty("program.customerValueToInput"));
			//Thread.sleep(5000);
			Util.waitTimeElementVisibility(programContainer.operaRateCategory);
			programContainer.operaRateCategory.clear();
			Util.waitTimeElementVisibility(programContainer.operaRateCategory);
			programContainer.operaRateCategory.sendKeys(roomProgram.getProperty("program.operaRateCategory"));
			
			Thread.sleep(500);
			Util.waitTimeElementVisibility(programContainer.operaCodeDropDown);
			executor.executeScript("arguments[0].click();", programContainer.operaCodeDropDown);
			Thread.sleep(500);
			Util.waitTimeElementVisibility(programContainer.publicName);
			programContainer.publicName.clear();
			Util.waitTimeElementVisibility(programContainer.publicName);
			programContainer.publicName.sendKeys(roomProgram.getProperty("program.publicName"));
			//Thread.sleep(5000);
			Util.waitTimeElementVisibility(programContainer.description);
			programContainer.description.clear();
			Util.waitTimeElementVisibility(programContainer.description);
			programContainer.description.sendKeys(roomProgram.getProperty("program.description"));
			//Thread.sleep(5000);
			Util.waitTimeElementVisibility(programContainer.periodStartDate);
			programContainer.periodStartDate.clear();
			Util.waitTimeElementVisibility(programContainer.periodStartDate);
			programContainer.periodStartDate.sendKeys(roomProgram.getProperty("program.periodStartDate"));
			//Thread.sleep(5000);
			Util.waitTimeElementVisibility(programContainer.periodEndDate);
			programContainer.periodEndDate.clear();
			Util.waitTimeElementVisibility(programContainer.periodEndDate);
			programContainer.periodEndDate.sendKeys(roomProgram.getProperty("program.periodEndDate"));
			//Thread.sleep(5000);
			Util.waitTimeElementVisibility(programContainer.RestrictionStartDate);
			programContainer.RestrictionStartDate.clear();
			Util.waitTimeElementVisibility(programContainer.RestrictionStartDate);
			programContainer.RestrictionStartDate.sendKeys(roomProgram.getProperty("program.RestrictionStartDate"));
			//Thread.sleep(5000);
			Util.waitTimeElementVisibility(programContainer.RestrictionEndDate);
			programContainer.RestrictionEndDate.clear();
			Util.waitTimeElementVisibility(programContainer.RestrictionEndDate);
			programContainer.RestrictionEndDate.sendKeys(roomProgram.getProperty("program.RestrictionEndDate"));
			//Thread.sleep(5000);
			Util.waitTimeElementVisibility(programContainer.saveProgram);
			int intTest = wd.findElements(By.id("layoutForm:saveButton")).size();
			Assert.assertTrue("Failed, Save Program link is not present",intTest > 0);
			
			//Assert.assertTrue("PASS, Save Program link is present",programContainer.saveProgram.isDisplayed());
			executor.executeScript("arguments[0].click();", programContainer.saveProgram);
			//programContainer.saveProgram.click();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public static void createNewProgramIfRequired(){
		try{
			String programName = channelProperties.getProperty("channel.programIdNew");
			String programID = channelProperties.getProperty("channel.programsId");
			MystiqueProgramView.searchName(programName);
			WebElement select = BrowserDriver.getCurrentDriver().findElement(By.xpath("//*[@id='layoutForm:dataTable_data']/tr"));
			List<WebElement> options = select.findElements(By.tagName("td"));
	        if(options.size()==1)
	        {
	        	MystiqueProgramView.createNewProgram();
				//Thread.sleep(5000);
				MystiqueProgramView.selectCategory();
				//Thread.sleep(5000);
				progName=programName;
				PrgID=programID;
				Util.waitTimeElementVisibility(programContainer.clickActive);
				//programContainer.clickActive.click();
				executor.executeScript("arguments[0].click();",programContainer.clickActive); 
				
				//Thread.sleep(9000);
				Util.waitTimeElementVisibility(programContainer.BAROffer);
				//programContainer.BAROffer.click();
				executor.executeScript("arguments[0].click();",programContainer.BAROffer); 
				
				Thread.sleep(100);
				TypeProgramDetails();			
	        }	
		}catch(InterruptedException e){
			e.printStackTrace();
		}
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
            
        }

    }*/

}

