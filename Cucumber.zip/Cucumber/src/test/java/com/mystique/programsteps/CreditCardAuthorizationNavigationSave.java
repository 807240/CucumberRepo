package com.mystique.programsteps;

import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueProgramView;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreditCardAuthorizationNavigationSave {
	
	private static final Logger LOGGER = Logger.getLogger(CreditCardAuthorizationNavigationSave.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	@Given("^I am on the Credit Card authorization page and enter all the mandatory field$")
	public void I_am_on_the_Credit_Card_authorization_page_and_enter_all_the_mandatory_field(){
		MystiqueProgramView.check_ShowinICE_checkbox();
//		MystiqueProgramView.selecting_FormFields();
		MystiqueProgramView.providevalue_header_AuthorizationNote();
		MystiqueProgramView.providevalue_FaxNumber();
	}

	@When("^I click on save button credit card authorization page$")
	public void I_click_on_save_button_credit_card_authorization_page() {
		MystiqueProgramView.clickingSavebtn_cca();
		
	}
	@Then("^I should see that the credit card authorization details get saved$")
	public void I_should_see_that_the_credit_card_authorization_details_get_saved() {
		MystiqueProgramView.saveConfirmation_CreditCardAuthorization();

}
}
