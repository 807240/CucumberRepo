package com.mystique.programsteps;

import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueProgramView;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;

public class SegmentNavigationSteps {
	private static final Logger LOGGER = Logger.getLogger(SegmentNavigationSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	@Given("^I am on the Segment menu$")
	public void I_am_on_the_Segment_menu() {
		MystiqueProgramView.selectCampaignAdmin();
		MystiqueProgramView.selectARIAfromDropDown();
		
	}

	@When("^I click on the Manage Segment link$")
	public void I_click_on_the_Manage_Segment_link() {
		MystiqueProgramView.hoverOnSegmentTab();
		MystiqueProgramView.clickManageSegments();
		
	}
	
	@Then("^I should see Segment related tabs$")
	public void I_should_see_Segment_related_tabs() {
		LOGGER.info("I am seeing Segment related tabs"); 
		WebDriver wd= BrowserDriver.getCurrentDriver();
		int isSegmentTxtPresent = wd.findElements(By.xpath("//span[contains(text(),'Segment Library')]")).size();
		Assert.assertTrue("Failed, Segment page not displayed",isSegmentTxtPresent>0);
		
	}
}