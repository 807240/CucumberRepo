package com.mystique.programsteps;

import java.util.logging.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueProgramView;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class ProgramNavigationSteps {
	private static final Logger LOGGER = Logger.getLogger(ProgramNavigationSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	@Given("^I click on the Drop Down to Select Program$")
	public void I_click_on_the_Drop_Down_to_Select_Program() {
		MystiqueProgramView.selectCampaignAdmin();
		MystiqueProgramView.selectARIAfromDropDown();
	}

	@When("^I try to select Campaign Administration and Property$")
	public void I_try_to_select_Campaign_Administration_and_Property() {
		MystiqueProgramView.hoverOnProgramTab();
		MystiqueProgramView.clickManageProgram();
	}
	@Then("^I should see Program related tabs$")
	public void I_should_see_Program_related_tabs() {
		LOGGER.info("I am seeing Program related tabs"); 
	}
	/*@After
    public void tearDown(Scenario scenario) {

        if (scenario.isFailed()) {
            final byte[] screenshotBytes = ((TakesScreenshot) wd).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshotBytes, "image/png");
            System.out.println("I am here");
        }

    }*/

}
