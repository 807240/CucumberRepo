package com.mystique.programsteps;

import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueProgramView;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AllProgramSearchSteps {
	
	private static final Logger LOGGER = Logger.getLogger(AllProgramSearchSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();
	
	@Given("^I select any region for checking export functionality without selecting program and click on search button$")
	public void I_select_any_region_for_checking_export_functionality_without_selecting_program_and_click_on_search_button() {
		MystiqueProgramView.selectRegion_LasVegas();
		MystiqueProgramView.allprogram_search();
	}

	@When("^I click on export without selecting any program$")
	public void I_click_on_export_without_selecting_any_program() {
		MystiqueProgramView.allprogram_export();

	}
	@Then("^I should see that the alert dialog box asking to select any program$")
	public void I_should_see_that_the_alert_dialog_box_asking_to_select_any_program() {
		MystiqueProgramView.alertDialogBox();
	}
	
	@Given("^I select any property for checking export functionality without selecting program and click on search button$")
	public void I_select_any_property_for_checking_export_functionality_without_selecting_program_and_click_on_search_button() {
		MystiqueProgramView.selectRegion_LasVegas();
		MystiqueProgramView.selectProperty_LasVegas_Delano();
		MystiqueProgramView.allprogram_search();
	}

	@When("^I click on export selected programs link without selecting any program$")
	public void I_click_on_export_selected_programs_link_without_selecting_any_program() {
		MystiqueProgramView.allprogram_export();

	}
	@Then("^I should see that the alert box asking to select any program$")
	public void I_should_see_that_the_alert_box_asking_to_select_any_program() {
		MystiqueProgramView.alertDialogBox();
	

}

}
