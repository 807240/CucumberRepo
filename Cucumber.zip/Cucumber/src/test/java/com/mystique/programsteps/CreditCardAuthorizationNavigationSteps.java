package com.mystique.programsteps;

import java.util.logging.Logger;

import org.openqa.selenium.WebDriver;

import com.mystique.application.BrowserDriver;
import com.mystique.view.MystiqueProgramView;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreditCardAuthorizationNavigationSteps {
	
	private static final Logger LOGGER = Logger.getLogger(CreditCardAuthorizationNavigationSteps.class.getName());
	static WebDriver wd=BrowserDriver.getCurrentDriver();

	@Given("^I am on the property tab$")
	public void I_am_on_the_property_tab(){
		MystiqueProgramView.selectARIAfromDropDown();
	}

	@When("^I click on credit card authorization link$")
	public void I_click_on_credit_card_authorization_link() {
		MystiqueProgramView.hoverOnPropertyTab();
		MystiqueProgramView.clickOnCreditCardAuthorizationsTab();
	}
	@Then("^I should see that the credit card authorization related tabs$")
	public void I_should_see_that_the_credit_card_authorization_related_tabs() {
		LOGGER.info("I am seeing credit card authorization related tabs");

}
}
